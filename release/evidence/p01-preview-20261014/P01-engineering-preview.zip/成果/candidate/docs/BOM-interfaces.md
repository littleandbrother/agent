# P01 — BOM / net / pin / interface correspondence (source-bound reconstruction)

paper_id **P01**, source_identity `d23fb910ad86d4836a9b49444f8ffc792828f1769750dca09df63232b2e1682d`,
contract_sha256 `c5368171878e4c4d7f42fea314ce650acf7c0714c7d0ef2d0d61b15b1c891b11`.

All values are tagged **recovered** (verbatim in the paper), **rebuilt** (paper topology + explicit reconstruction) or
**assumption** (not published). Page/section locators are in `docs/source-map.json`.

## 1. Device identity conflicts (must not be silently resolved)

| Item | Source A | Source B | Adopted here | Status |
|---|---|---|---|---|
| MCU | Fig.3 block diagram: **STM32WB15CC** | Methods + SI Table S2 (U16): **nrf52832 module** | firmware built for **nRF52832-QFAA** (runtime-supported) with an explicit declaration | OPEN |
| CDC | Fig.3 / SI Table S2: **AD7156** | Methods: **AD7158** | **AD7156** (majority + vendor datasheet) | OPEN |
| Coupled inductor | SI Table S2: **LPR6235-123QMRC** labelled "Op Amp" | Fig.3 requires a coupled flyback inductor | treated as a flyback coupled inductor; **turns ratio not published** | OPEN |
| Storage cap | 220 µF (characterisation) / 440 µF = 2×220 µF (microsystem) | Fig.4e caption + Table S2 C3 = **100 µF** | three contexts kept separate; assembly shows the 220 µF envelope | OPEN |

> The device identity conflict is not closeable from the published material. The firmware is therefore built for the
> declared nRF52832-QFAA target and is **not** claimed to match the paper's confirmed MCU.

## 2. BOM (from SI Table S2 + Fig.3), source-bound reconstruction

| Ref | Part / value | Role | Source | Tag |
|---|---|---|---|---|
| Q1 | CMN3160M GaN HEMT, 600 V, Ron ≈ 45 Ω | SECE flyback switch | Table S2 / Fig.3 | recovered |
| L1 | 2.2 µH, 30 mA, DCR 0.65 Ω | buck / filter inductor | Table S2 | recovered |
| L2 | LPR6235-123QMRC coupled inductor | flyback energy extraction | Table S2 (label clipped) | recovered (label conflict) |
| C1 | 1 pF | peak-detect differentiator | Table S2 | recovered |
| C3 | 100 µF | storage (BOM variant) | Table S2 | recovered (conflict) |
| Csto | 220 µF (char.) / 440 µF (system) | storage capacitor | Methods / Fig.2c, Fig.4e | recovered |
| U1 | TPS3840 | cold-start / voltage supervisor, 4.0 V threshold | SI S2 / Methods | recovered |
| U2 | TPS62840 | 1.8 V buck DC-DC | Table S2 / SI S5 | recovered |
| U3 | CD4098B | monostable (SECE pulse, ~21 µs release window) | Fig.3 / SI S2 | recovered |
| U4 | SN74LVC1T45 | level shifter | Fig.3 | recovered |
| U5 | SN74AHC1G14 | Schmitt inverter (peak detector) | Table S2 | recovered |
| UFBR | schottky rectifier bridge (BAT46W-class modelled) | TENG rectification | Fig.3 | rebuilt |
| DZ | 6.2 V zener (AZ23C6V2-class) | storage clamp | SI Table S2 | recovered |
| Rdiv | GΩ divider 100:1 | TENG HV sense to comparator | Fig.3 / Methods | recovered (values not published) |
| CDC (U?) | AD7156 capacitance-to-digital converter | gas-sensor capacitance readout | Fig.3 / Table S2 (conflict) | recovered (conflict) |
| MCU (U16) | nRF52832 module | BLE MCU | SI Table S2 (conflict) | recovered (conflict) |
| RS1 | interdigitated gas sensor, 400 µm glass / 7 µm IDT / 5 mm² / 1.3 µm PDMS | VOC sensing | Fig.6b / Methods | recovered |

Package sizes quoted in Table S2 (0603/0805) are not reproduced here because no footprint library or placement file
was published (native PCB = BLOCKED).

## 3. Nets / interfaces (declared, not yet verified on hardware)

| Interface | Type | Declared behaviour | Source | Status |
|---|---|---|---|---|
| `teng_terminal_pos` / `teng_terminal_neg` | analog HV | TENG to rectifier; open-circuit peak ~720 V, 300–400 nC/cycle | p.4 | declared |
| `storage_rail` | power | 0–6.14 V; cold-start enable 4.0 V (TPS3840), SECE enable 4.2 V (assumed +0.2 V) | SI S2 / Methods | declared |
| `supply_1v8` | power | TPS62840 1.8 V to MCU/sensor | SI S5 | declared |
| `sensor_i2c` | digital | AD7156 on I²C (official TWI0 master); ch1 regs 0x01/0x02, ch2 0x03/0x04; 12-bit result in upper 12 bits, high byte first; RDY bit polled with timeout; 5 s sampling | AD7156 datasheet / Methods | built (target), unverified on HW |
| `mcu_manual_start` | control | MCU is **manually** powered on by a human | p.11 Fig.7a/e | declared (paper boundary) |
| flyback switch node | analog HV | Q1 drain swings to reflected TENG HV; derating vs 600 V not published | Fig.3 | OPEN (derating gate) |

## 4. Firmware interface — `project-fw-s132/` (nRF52832-QFAA + S132 7.2.0, declared reconstruction)

Rebuilt in the revision phase on the real `firmware-nrf52832-s132` target worker (SDK `17.1.0_ddde560`,
SoftDevice `S132-7.2.0`), adapted from the official Nordic `ble_app_uart` example plus official drivers.

- `project-fw-s132/main.c` — official SDK/BLE scaffolding: `nrf_sdh`, `ble_advertising`, `ble_conn_params`,
  `ble_nus`, `bsp_btn_ble`, `nrf_pwr_mgmt`; real `advertising_start()`, an official `app_timer` 1 ms system
  tick (`tick_timeout_handler`) and BLE event IRQs; **main loop = `idle_state_handle()` (log process + low-power
  wait), not an empty spin**.
- `project-fw-s132/ad7156_nrf.c/.h` — real AD7156 driver over the **official `nrf_drv_twi` master** (TWI0, IRQ
  `TWI0_TWIM_IRQn`): channel select via config reg `0x0F`; **channel 1 = data regs `0x01`(MSB)/`0x02`(LSB),
  channel 2 = `0x03`/`0x04`**; result = 12-bit value in the **upper 12 bits** of the 16-bit register
  (`>>4`, mask `0x0FFF`); `RDY` (status bit 3) polled with timeout; transfers driven by the official TWI event
  handler; NACK/timeout mapped to distinct error codes.
- `project-fw-s132/app_policy.c/.h` — deterministic FSM + async binding: every request/callback carries an
  `epoch` and `request_id`; a stale callback is rejected. Public negative cases (see `host-test-s132/`):
  sample before start, late sample after disconnect, stale/foreign request id, failed/queued send not counted as
  delivery, empty payload, time wraparound, buffer lifetime, cold-start gate.
- **Manual boundaries preserved**: `app_on_manual_start()` still gates everything; the peer (GUI) still initiates
  the connection; the device never self-starts and never auto-connects.
- **Pins are a NEW development-board assumption** (PCA10040): SCL 27 / SDA 26 / UART RTS 5, CTS 7, TX 6, RX 8.
  The original pin mapping was **not published**; this is not the original mapping (`pin_binding_verified=false`).
- **BLE UUID / GATT table and the exact frame channel/epoch semantics are not published** → declared
  reconstruction; the firmware uses the standard **Nordic UART Service (NUS)** scaffolding, which is *not* asserted
  as the paper's UUIDs.
- The MCU identity conflict (Fig.3 STM32WB15CC vs Methods/Table S2 nrf52832) remains **explicitly open**; this is a
  declared nRF52832 reconstruction.
- Build evidence: application ELF/HEX/BIN/MAP + SoftDevice HEX + combined HEX under `native/firmware-s132/`, with an
  independent memory/vector readback (`readback_passed=true`, `memory_fit=true`). Target build success is **not**
  evidence of radio, I²C device/bus, GPIO or power.

## 5. Peer receiver / GUI (SI S6), `receiver/`

- Behaviour recovered from SI S6: scan → connect → enable notifications → parse 2-byte LE CDC frame → convert to
  capacitance → live plot / CSV.
- `receiver/frame.py` — 2-byte little-endian 12-bit frame codec + a **declared** CDC→fF scale (the paper's AD7156
  input range is not published).
- `receiver/pipeline.py` — headless ingest/series/CSV with reject counting.
- `receiver/receiver_gui.py` — Tkinter GUI with a **simulated** backend (always available) and an optional `bleak`
  backend (unavailable in this headless session, marked not faked).
- `receiver/test_frame.py` — 25 host frame-decode/pipeline checks. Host tests are **not** radio or device evidence.

## 6. Bounded circuit model

- `project-spice/sece_storage.cir` is a **bounded local equivalent** of the storage/clamp/load stage only
  (pulsed harvested charge → schottky rectifier → 220 µF storage → 6.2 V zener → average load).
- It **does not** cover TENG electrostatics, SECE switching, the 600 V GaN/transformer stage, DC-DC start-up or the
  digital load. It is not a proof of the whole energy-harvesting system.
- `project-spice-source/direct_charge.cir` adds the **source-side link** that the storage model above lacked: the
  recovered 2-terminal CS-TENG physics (Cmax = 1 nF, sinusoid OCV, no fitting) driving an **ideal full-bridge
  rectifier** into 220 µF. Job `eng-9db41867521e453a` (independent readback `readback_passed=true`); 100 s storage
  voltage 1.3118 / 3.2749 / 5.4392 / 2.6499 V across the four peak/frequency cases. This is still a **bound**, not
  the SECE microsystem (see `docs/interface-chain.md` §5 and `delivery/source-link-evidence.json`).
