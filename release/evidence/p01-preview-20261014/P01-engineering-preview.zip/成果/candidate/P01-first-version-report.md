# P01 首版数字工程报告（round-3，同版交付指向已按公开只读事实修正）

- 任务：`task-P01-10bf452e702af71a1acf`（原 owner `pi-chat-b47a35e335bc68d4`，原 contract 未改）
- 目标：在选定的名义机械输入和声明初态下，完成积能、人工接通 MCU、建立连接、周期采样和 PC 解码；提交对应数字工程与验证证据。
- 版本性质：**首版（first version）**，非最终验收；`full_product_passed=false`，`physical=NOT_TESTED`。
- 本文件在 round-3 元数据核对轮被更新：当前结果以公开独立只读检查为准（`public-round3-facts-20261014/FINAL-INDEX.json`），
  更新前的文本保留为历史 `round3/history/P01-first-version-report-initial.md`（sha256 `804d2bec87d49612…`）。
- 本轮 `engineering_source_edits=0`、`solver_runs=0`、`target_builds=0`：只修交付指向，不改工程。

## 1. 本轮唯一变更：交付指向修正（不改工程）

冻结候选 `D-85f03a02…` 中 `public-interface-facts-20261014/native-project` 指向的是**上一版 PCB/原工程副本**
（`PCB1.epcb2 = 5fb5c2a743aa…`），而当前已保存 PCB 为 `77d8da54226a6453…`。
逐文件处置（新增/保留/退出当前清单）见 `round3/delivery-pointer-fix.md`；退出项仅在清单中移除，原文件仍留在工作区作历史。

当前清单采用 `public-round3-facts-20261014/` 下由只读检查端逐字节封存的事实：
`native-project/{…eprj3, pcb/PCB1.epcb2, sch/Schematic1/P1.esch2, sch/Schematic1/Schematic1.ecfg, eprj3-intro.md}`、
`schematic-readback.json`、`pcb-readback.json`、`drc-readback.json`、`native-readback.json`、
`native-parts-readback.csv`、`interfaces.json`、`manufacturing/export-receipt.json`、
`manufacturing/P01-round3-Gerber.zip`、`independent-reviews/*`、`FINAL-INDEX.json`。
本报告已逐字节核对：索引内 13 个文件与 7 个门证据文件的 SHA256 全部匹配索引声明。

保留项：`public-interface-facts-20261014/firmware-events.json`（sha256 `e4df51568484f480…`）——它被
`firmware_event_logic`、`board_firmware_interfaces`、`source_domain`、`power_load_chain` 四个门作为支撑源直接引用，必须继续在清单内。

## 2. 原生对象（当前已保存版本，逐字节一致）

| 对象 | 路径 | sha256（前 16） |
|------|------|-----------------|
| 原工程 | `public-round3-facts-20261014/native-project/BF-Literature-P01-Native-20261012.eprj3` | `7e325475627a40c4` |
| PCB | `public-round3-facts-20261014/native-project/pcb/PCB1.epcb2` | `77d8da54226a6453` |
| 原理图 | `public-round3-facts-20261014/native-project/sch/Schematic1/P1.esch2` | `7c88660f33e0c31e` |
| 原理图配置 | `public-round3-facts-20261014/native-project/sch/Schematic1/Schematic1.ecfg` | `f1024361204d7112` |

工程源与独立复核端钉住的输入逐字节一致：
`project-chain/chain_joint.cir 790c2ba9…`、`project-chain/interface-params.json e0561370…`、
`project-chain/load-timeline.json 6a959ca6…`、`project-fw-s132/main.c c421f94e…`、`sdk_config.h 849fbf07…`、
`ad7156_nrf.h 19f133d5…`、`ad7156_nrf.c 5849b691…`、`app_policy.c a942c830…`、`app_policy.h c05c98be…`、
`project-cad/teng_assembly.py a8aed3bb…`。**固件源码本轮未改动**（policy↔radio 差异只记录、不修）。

## 3. 八门状态（以公开独立只读检查为准）

| # | 门 | 状态 | 独立依据（`public-round3-facts-20261014/independent-reviews/`） |
|---|----|------|------------------|
| 1 | `source_domain` | UNEVALUABLE | `source_domain.json`（`47318e2c…`）：待定 TENG 端子标定/变电容、SECE 提取参数与变压器映射；绑定 `eng-9d45631d57148be4` |
| 2 | `schematic_bom_pins` | UNEVALUABLE | `schematic_bom_pins.json`（`fb95737f…`）：原理图↔PCB 器件/引脚/网络对应 **PASS**（39 器件、**172 引脚**、差异 0）；仍缺供应商/封装/厂家引脚全审计与 T1 绕组参数辨识 |
| 3 | `pcb_connectivity_drc` | **FAIL** | `pcb_connectivity_drc.json`（`4034af9b…`）：当前保存后原生 DRC `passed=false`，**52 Clearance Error + 50 Connection Error**（`drc-readback.json de8117f8…`） |
| 4 | `geometry_fit` | UNEVALUABLE | `geometry_fit.json`（`96f80d6e…`）：板框 **40.0 × 70.0 mm 一致**（PCB 与 CAD STEP 实体 `2092e13a…`），全部器件中心在板框内 **PASS**；缺原生器件 3D 高度、PCB→CAD 放置变换、安装孔对应，故不能判通过 |
| 5 | `firmware_event_logic` | **PASS** | `firmware_event_logic.json`（`1b25d198…`）：18 个反例通过，源为精确复用（绑定 `eng-6e2bc184592697d6`） |
| 6 | `board_firmware_interfaces` | UNEVALUABLE | `board_firmware_interfaces.json`（`2ff434e0…`）：SCL=GPIO27/SDA=GPIO26 **PASS**、LF 时钟选择（`LF_SRC=0`）**PASS**；PCA10040 UART/按键/LED 初始化对当前原生板未核 |
| 7 | `power_load_chain` | **FAIL** | `power_load_chain.json`（`4e37d83f…`）+ `joint-model-review.json`（`6c726665…`）：定量失败，见下节 |
| 8 | `delivery_version` | NOT_CHECKED（待最后独立检查） | 本报告 + 冻结候选 + `delivery/manifest.json` + 三个原生作业绑定；该门由只读检查端最后核对 |

`geometry_fit` 由上一轮的自评 FAIL 更正为独立端的 UNEVALUABLE（缺映射而非已证干涉）；`pcb_connectivity_drc`、
`power_load_chain` 维持 FAIL。判据是证据，不是本报告的措辞。

## 4. `power_load_chain`：定量失败与待修项

原生解 `eng-9d45631d57148be4`（`project_sha256 5f1ab8e1…`，产物 `project-trace.raw b0dd1678…` 165018 点）在
声明初态 220 µF / 4.2 V、人工开关 t≈0 闭合、实际无线时序（广播 187.5 ms = `APP_ADV_INTERVAL 300 × 0.625 ms`，
连接 100/200 ms 取最坏 100 ms，采样 5000 ms）下：

- 储能轨 4.2 V → 16.001 s 的 **0.352785 V**；
- **稳压 1.8 V 观测在 0.900196877 s 跌破标称**（冷启动需要轨压 ≥4.0 V，储能一旦低于即掉出稳压）；
- 采样/通知事件 4 次（t≈0.3 / 5.3 / 10.3 / 15.3 s），末次通知时轨压已远低于 MCU 最低工作电压；
- 能量账（`joint-model-review.json` 独立读回）：`storage_load_j=2.0503e-3`、`sece_into_storage_j=1.4803e-4`、
  `storage_leak_j=2.4480e-5`、`capacitor_delta_j=-1.9267e-3`、积分残差 `1.596e-11`（自洽）；
- 电荷账（`round3/chain-crosscheck.json`）：取能净注入 61.9 µC（3.9 µA 均值）对负载 899.6 µC（56.2 µA 均值），
  斜率反推负载 ≈58.2 µA 与模型 ≈56.5 µA 一致（比值 1.03），排除纯数值假象。

独立端列入的**待修项**（本阶段不修，进入下一轮）：
1. **初态开关伪影**：1 ns 人工开关过渡区间内强制负载仍在导通，产生非法负 MCU 轨（独立读回最小值
   −1.315962e6 V @ t=3.2e-10 s）。这是模型伪影，不是物理结论，必须在下一轮修正后再取数。
2. **未标定的提取支路**：平均包络模型缺少显式 U5/U6/Q1/T1 SECE 与 buck 链，取能仍为声明行为包络（`resolved=false`）。
3. **储能负载折算固定 4.2 V**：放电全程按固定 4.2 V 折算，放大了低轨区的工作占空假设。
4. **policy↔radio 不一致（仅记录、未改固件）**：`app_policy.c` 策略层 5000/3000 ms 与 `main.c` 实际配置
   187.5/100–200 ms 冲突，已在 `round3/chain-revision.md` 与独立复核中记为接口发现。

结论：在声明初态与人工接通边界下，**储能容值/取能规模与任务负载不匹配**，任务链不能在要求时间内支撑采样与通知；
必须改变取能标定或储能/连接参数之一，且先消除开关伪影。不得以本报告或任何文件门声称整机/物理通过。

## 5. 制造出口（只读官方 SDK 导出）

- 归档：`public-round3-facts-20261014/manufacturing/P01-round3-Gerber.zip`，91234 B，sha256 `f3dd8d25d7f13e2a…`；
- 出口回执：`public-round3-facts-20261014/manufacturing/export-receipt.json`，sha256 `67d8873c0b1a61df…`，
  记录 `native_files_sha256` 与当前已保存原生文件一致、`native_files_unchanged=true`、`design_source_edits=0`、`solver_runs=0`；
- 归档成员 14 项：`Gerber_{Top,Bottom}Layer`、Top/Bottom 丝印、Top/Bottom 阻焊、Top 焊膏、`BoardOutline(GKO)`、
  Document/DrillDrawing、`Drill_PTH_Through.DRL`、`Drill_PTH_Through_Via.DRL`、`FlyingProbeTesting.json`、`PCB下单必读.txt`；
- 归档身份来自当前 PCB（`77d8da54…`）。**导出成功不等于可制造**：同版 DRC 仍为 FAIL（52 间距 + 50 未布通），
  故该包目前只能作为“当前版制造出口”，不能作为可投产依据。

## 6. 同版绑定与可复现输入

- 冻结核心：`D-85f03a02…`（本轮首个冻结）→ 元数据绑定的最终设计见 `bf_design inspect`（本轮冻结的 `working_design`）。
- 三项原生作业**继续沿用、未重跑、未重建**：`eng-d6b2ca501db8e7fa`（cadquery，`cf4da368…`）、
  `eng-6e2bc184592697d6`（firmware-nrf52832-s132，`b5e0d9b9…`）、`eng-9d45631d57148be4`（spice，`5f1ab8e1…`）。
- 程序生成同版元数据：`native-report.json`、`delivery/manifest.json`（本轮由 `bf_design prepare_delivery` 重生成并冻结绑定）。
- 历史：`delivery/CURRENT-REVIEW.md`、`delivery/UNVERIFIED.md`（阶段旧报告）、`delivery/metadata-history/*`、
  `round3/history/*`、旧 `public-interface-facts-20261014` 文件（保留在工作区、不进入当前清单）。

## 7. 四项独立要求（不因本轮工作而改变）

| 要求 | 状态 |
|------|------|
| 自动接通 MCU | **未验证**：本任务只做人工接通；t≈0 的人工开关闭合是声明边界 |
| 零能量冷启动 | **未验证**：4.2 V 初态由 BF 声明并建账，非自供电建立 |
| 标定气体浓度 | **未验证**：不在本阶段范围 |
| 物理验证 | **NOT_TESTED**：全部为数字工程证据，无实测 |

## 8. 如实声明的范围与限制

- 本交付是**数字工程证据**：原生 CAD/SPICE/目标固件 + 原生原理图/PCB 回读 + 独立只读复核。不是整机通过，不是物理验证。
- PC 接收端 `receiver/`（帧解析、BLE 后端、GUI、边界测试）为宿主侧代码证据，未接真实射频。
- 器件参数、论文源域映射、TENG 标定与 SECE 提取仍为声明假设；`source_domain` 保持 UNEVALUABLE。
- 下一轮计划（已记入 `intent`）：先修开关伪影与取能标定/储能参数，再按 DRC 类别修 52+50，补齐高度/孔位映射与
  引脚↔GPIO↔时钟↔中断对账，最后才谈交付版本。
