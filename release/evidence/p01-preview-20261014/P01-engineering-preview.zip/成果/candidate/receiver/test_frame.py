"""Frame-decode and receive-pipeline tests for the P01 peer receiver.

Runs headless (no BLE radio, no GUI). A green run proves the host decoder and
pipeline logic against synthetic frames only; it is NOT target radio or device
evidence. Usage:  python3 test_frame.py
"""
from __future__ import annotations

import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from frame import FrameError, CapacitanceScale, decode_frame, encode_frame
from pipeline import ReceiverPipeline

PASS = 0
FAIL = 0
RESULTS = []


def check(name, cond):
    global PASS, FAIL
    RESULTS.append({"name": name, "ok": bool(cond)})
    if cond:
        PASS += 1
        print("PASS", name)
    else:
        FAIL += 1
        print("FAIL", name)


def expect_reject(name, fn):
    try:
        fn()
    except FrameError:
        check(name, True)
        return
    check(name, False)


def main():
    # --- decode: valid frames / byte order ---
    check("decode_valid_0x0ABC", decode_frame(bytes((0xBC, 0x0A))) == 0xABC)
    check("decode_min_0x000", decode_frame(b"\x00\x00") == 0)
    check("decode_max_0xFFF", decode_frame(b"\xff\x0f") == 0xFFF)
    check("decode_is_little_endian", decode_frame(bytes((0x23, 0x01))) == 0x123)

    # --- decode negative cases (rejection matrix) ---
    expect_reject("reject_length_1", lambda: decode_frame(b"\x01"))
    expect_reject("reject_length_3", lambda: decode_frame(b"\x01\x02\x03"))
    expect_reject("reject_length_0", lambda: decode_frame(b""))
    expect_reject("reject_reserved_bit12", lambda: decode_frame(bytes((0x00, 0x10))))
    expect_reject("reject_reserved_bit15", lambda: decode_frame(bytes((0x00, 0x80))))
    expect_reject("reject_none_payload", lambda: decode_frame(None))

    # --- encode round trip / range ---
    ok = all(decode_frame(encode_frame(r)) == r for r in range(0, RAW_MAX_PLUS1))
    check("encode_decode_roundtrip_all_4096", ok)
    check("encode_byte_order", encode_frame(0x123) == bytes((0x23, 0x01)))
    expect_reject("encode_reject_4096", lambda: encode_frame(4096))
    expect_reject("encode_reject_negative", lambda: encode_frame(-1))
    expect_reject("encode_reject_nonint", lambda: encode_frame("5"))

    # --- capacitance scale (declared reconstruction, not paper value) ---
    sc = CapacitanceScale(full_scale_fF=4000.0, codes=4096)
    check("scale_zero_is_zero", abs(sc.to_fF(0) - 0.0) < 1e-9)
    check("scale_full_scale", abs(sc.to_fF(4095) - 4095 * sc.fF_per_lsb) < 1e-9)
    check("scale_monotone", sc.to_fF(100) < sc.to_fF(200))

    # --- pipeline: ingest, rejects, csv round trip ---
    tmp = tempfile.mkdtemp(prefix="p01recv_")
    csv_path = os.path.join(tmp, "samples.csv")
    p = ReceiverPipeline(scale=sc, maxlen=4)
    p.ingest(0.0, bytes((0x00, 0x00)))
    raw, fF = p.ingest(0.5, bytes((0xBC, 0x0A)))
    check("pipeline_ingest_value", raw == 0xABC and abs(fF - sc.to_fF(0xABC)) < 1e-9)
    try:
        p.ingest(1.0, bytes((0x00, 0x10)))
        bad = False
    except FrameError:
        bad = True
    check("pipeline_counts_reject", bad and p.rejects == 1 and p.received == 3)
    check("pipeline_reject_not_in_series", len(p.samples) == 2)
    for i in range(6):                      # exercise the bounded buffer
        p.ingest(2.0 + i, bytes((i, 0x00)))
    check("pipeline_bounded_maxlen", len(p.samples) == 4)
    n = p.to_csv(csv_path)
    rows = ReceiverPipeline.read_csv(csv_path)
    check("pipeline_csv_row_count", n == len(rows) == 4)
    check("pipeline_csv_roundtrip_first", rows[0][1] == 2 and abs(rows[0][2] - sc.to_fF(2)) < 1e-3)
    expect_reject("pipeline_read_csv_bad_header",
                  lambda: (open(csv_path, "w").write("a,b,c\n"), ReceiverPipeline.read_csv(csv_path)))

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "frame-tests.json"), "w") as fh:
        json.dump({
            "schema": "p01-receiver-tests-v1",
            "physical_verified": False,
            "scope": "host frame codec + pipeline only; no BLE radio, no device",
            "pass": PASS, "fail": FAIL, "checks": RESULTS,
        }, fh, indent=2)

    print("\n%d passed, %d failed" % (PASS, FAIL))
    return 0 if FAIL == 0 else 1


RAW_MAX_PLUS1 = 4096
if __name__ == "__main__":
    raise SystemExit(main())
