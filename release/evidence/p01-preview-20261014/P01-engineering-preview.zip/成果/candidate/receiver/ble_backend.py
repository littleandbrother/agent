"""P01 peer receiver -- actually callable BLE path + connection-identity source.

Public finding ``P01-receiver-actual-path``: the GUI previously only exposed a
simulated backend whose ``frames()`` raised unconditionally, so there was no
real receive path. This module is that path:

    scan/filter -> connect -> start_notify(TX char) -> decode 2-byte LE frame
    -> stop_notify -> disconnect

Data protocol (must match the rebuilt S132 firmware, ``app_policy.c``):

    payload[0] = raw & 0xFF
    payload[1] = (raw >> 8) & 0x0F          (12-bit CDC code, high nibble 0)

Connection identity: every notification is tagged with the *subscription epoch*
captured when the handler was registered. A notification delivered after a
close/re-open cycle belongs to the dead connection and is counted as
``stale`` and dropped -- it must not be attributed to the new connection (same
discipline the firmware applies to its tx_epoch/tx_req_id completion tags).

SCOPE / HONESTY
---------------
* ``BleakTransport`` is the real radio path (optional dependency ``bleak``).
  It is real code, but in this headless session no peripheral is present, so a
  real over-the-air connection is NOT exercised. Mock (FakeTransport) results and
  real-radio results are recorded separately (delivery/UNVERIFIED.md).
* There is NO silent fallback: if ``bleak`` is missing, ``real_backend()`` raises
  ``BleUnavailable`` and the caller must choose the simulated backend explicitly.
* NUS UUIDs are a declared reconstruction (not published by the paper).
"""
from __future__ import annotations

import asyncio
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from frame import FRAME_LEN, FrameError, decode_frame

NUS_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_RX_CHAR_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_TX_CHAR_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"

DEFAULT_NAME_FILTER = "P01"


class BleError(RuntimeError):
    """Base class for receiver-link failures."""


class BleUnavailable(BleError):
    """The real BLE stack (``bleak``) is not importable in this environment."""


class BleTimeout(BleError):
    """Scan/connect/notification wait exceeded its bound."""


class BleProtocolError(BleError):
    """The peer sent a payload that is not a valid P01 CDC frame."""


def bleak_available() -> bool:
    try:
        import bleak  # noqa: F401
    except Exception:
        return False
    return True


def real_backend(*_args, **_kwargs):
    """Return a :class:`BleReceiver` over the real radio, or raise."""
    if not bleak_available():
        raise BleUnavailable(
            "the optional 'bleak' package is not importable; install it to use "
            "the real BLE path (the simulated backend must be selected explicitly)")
    transport = BleakTransport(*_args, **_kwargs)
    return BleReceiver(transport)


class NotificationQueue:
    """Epoch-tagged notification queue shared by the handler and the consumer."""

    def __init__(self, loop=None):
        self._loop = loop
        self._queue: asyncio.Queue = asyncio.Queue()
        self.active_epoch = 0
        self.stale = 0
        self.rejects = 0

    def begin_epoch(self, epoch: int):
        """Start a new subscription epoch and drop whatever the old one left queued.

        A notification that was queued (but not yet consumed) before a close/re-open
        cycle belongs to the dead connection; it must never be delivered as if it
        came from the new one. Public check
        ``queued_old_packet_is_not_attributed_to_new_connection``.
        """
        self.active_epoch = epoch
        drained = 0
        while True:
            try:
                self._queue.get_nowait()
                drained += 1
            except Exception:
                break
        self.stale += drained
        return drained

    def publish(self, epoch_at_subscribe: int, current_epoch: int, data: bytes, closed: bool):
        if closed or epoch_at_subscribe != current_epoch \
                or epoch_at_subscribe != self.active_epoch:
            self.stale += 1
            return
        self._put((epoch_at_subscribe, bytes(data)))

    def put_disconnect(self):
        self._put((None, None))

    def _put(self, item):
        """Thread-safe hand-off: some transports call back outside the loop thread."""
        loop = self._loop
        if loop is not None and loop.is_running():
            try:
                loop.call_soon_threadsafe(self._queue.put_nowait, item)
                return
            except RuntimeError:
                pass
        self._queue.put_nowait(item)

    async def get(self):
        """Return the next payload that belongs to the active epoch.

        Items tagged with any other epoch are dropped here as well, which closes the
        race where a handler publishes while a re-open is in progress.
        """
        while True:
            epoch, item = await self._queue.get()
            if epoch is None:                 # transport signalled a link loss
                return None
            if epoch == self.active_epoch:
                return item
            self.stale += 1


class BleReceiver:
    """Connection-identity aware receiver over an injectable transport.

    The transport only has to implement the four async lifecycle methods, which
    makes the protocol/identity logic testable without a radio.
    """

    def __init__(self, transport, char_uuid: str = NUS_TX_CHAR_UUID,
                 service_uuid: str = NUS_SERVICE_UUID, connect_timeout: float = 10.0,
                 notify_timeout: float = 10.0):
        self.transport = transport
        self.char_uuid = char_uuid
        self.service_uuid = service_uuid
        self.connect_timeout = connect_timeout
        self.notify_timeout = notify_timeout
        self.epoch = 0
        self.closed = True
        self.queue = NotificationQueue()
        self.connected_at = None
        self._link_lost_during_bringup = False
        # Installed before any connect so a link loss that happens during bring-up is
        # still reported (public check ``real_adapter_installs_initial_disconnect_callback``).
        self._install_disconnect_callback()

    def _install_disconnect_callback(self):
        """Bind the transport link-loss callback to the *current* subscription epoch.

        The transport adapter keeps one callback slot, so the callback itself carries
        the epoch it was installed for: a late report from a dead link cannot close a
        newer subscription (``old_disconnect_does_not_close_new_subscription``).
        """
        set_cb = getattr(self.transport, "set_disconnect_callback", None)
        if set_cb is None:
            return
        epoch_at_install = self.epoch

        def _on_transport_disconnect(*_args):
            self._on_disconnect(epoch_at_install)

        set_cb(_on_transport_disconnect)

    # ---- lifecycle ------------------------------------------------------
    async def open(self):
        """Connect and subscribe. A re-open always starts a new epoch."""
        self.closed = True
        self.epoch += 1                      # any callback of the old link is stale
        self._link_lost_during_bringup = False
        try:
            await asyncio.wait_for(self.transport.connect(), self.connect_timeout)
        except asyncio.TimeoutError as exc:
            raise BleTimeout("connect timed out after %.1fs" % self.connect_timeout) from exc
        except BleError:
            raise
        except Exception as exc:             # bleak raises its own error types
            raise BleError("connect failed: %s" % exc) from exc

        epoch_at_subscribe = self.epoch
        self.queue._loop = asyncio.get_running_loop()
        self.queue.begin_epoch(epoch_at_subscribe)
        handler = self._make_handler(epoch_at_subscribe)
        # A link drop must wake the consumer instead of letting it block forever.
        self._install_disconnect_callback()
        try:
            await asyncio.wait_for(
                self.transport.start_notify(self.char_uuid, handler), self.notify_timeout)
        except asyncio.TimeoutError as exc:
            self.epoch += 1                  # subscription never became live
            await self._quiet_close()
            raise BleTimeout("start_notify timed out after %.1fs" % self.notify_timeout) from exc
        except Exception as exc:
            self.epoch += 1
            await self._quiet_close()
            raise BleError("start_notify failed: %s" % exc) from exc

        if self._link_lost_during_bringup:
            # The transport reported a drop while we were subscribing, so this link
            # never became live: do not hand the consumer a healthy-looking stream.
            self.closed = True
            self.epoch += 1
            self.queue.put_disconnect()
            raise BleError("link was lost while subscribing")
        self.closed = False
        self.connected_at = time.monotonic()
        return self

    async def close(self):
        was_closed = self.closed
        self.closed = True
        self.epoch += 1                      # invalidate every in-flight handler
        if not was_closed:
            try:
                await self.transport.stop_notify(self.char_uuid)
            except Exception:
                pass
            try:
                await self.transport.disconnect()
            except Exception:
                pass
        # NOTE: close() deliberately does *not* push the disconnect sentinel -- a
        # receiver object is re-openable, so a consumer that spans one close/re-open
        # cycle must keep running (see test_ble_backend.test_identity). Ending a
        # subscription *and its consumer* is the adapter's job via wake().

    def wake(self):
        """Wake a consumer blocked on the queue without changing link state."""
        self.queue.put_disconnect()

    async def _quiet_close(self):
        try:
            await self.transport.disconnect()
        except Exception:
            pass

    # ---- notifications ---------------------------------------------------
    def _on_disconnect(self, epoch_at_install=None, *_args):
        """Transport-reported link loss: invalidate the epoch and wake consumers.

        ``epoch_at_install`` is the subscription epoch the callback was created for.
        A report from an older link is stale and must not touch the live connection.
        """
        if self.connected_at is None:
            # Reported between connect() and a live subscription: the subscription epoch
            # does not exist yet, so the epoch test below cannot judge this report.
            # Remember it so open() does not declare the link healthy afterwards.
            self._link_lost_during_bringup = True
        if epoch_at_install is not None and epoch_at_install != self.epoch:
            return
        self.closed = True
        self.epoch += 1
        self.queue.put_disconnect()

    def _make_handler(self, epoch_at_subscribe: int):
        def _on_notify(_sender, data):
            # Runs in the transport's notification thread/loop; identity is decided
            # against the epoch captured *now*, never the current connection's.
            self.queue.publish(epoch_at_subscribe, self.epoch, bytes(data), self.closed)
        return _on_notify

    # ---- consumer --------------------------------------------------------
    async def samples(self, max_samples=None, idle_timeout=None):
        """Yield ``(t_s, raw, payload)`` for accepted CDC notifications.

        * invalid payloads increment ``queue.rejects`` and are skipped, they do
          not abort the stream;
        * ``idle_timeout`` raises :class:`BleTimeout` instead of hanging;
        * a transport disconnect surfaces as :class:`BleError`.
        """
        t0 = self.connected_at or time.monotonic()
        n = 0
        while max_samples is None or n < max_samples:
            try:
                if idle_timeout is None:
                    payload = await self.queue.get()
                else:
                    payload = await asyncio.wait_for(self.queue.get(), idle_timeout)
            except asyncio.TimeoutError as exc:
                raise BleTimeout("no notification within %.1fs" % idle_timeout) from exc
            if payload is None:              # transport signalled disconnect
                raise BleError("disconnected while waiting for notifications")
            try:
                raw = decode_frame(payload)
            except FrameError:
                self.queue.rejects += 1
                continue
            n += 1
            yield (time.monotonic() - t0, raw, payload)


class BleakTransport:
    """Real radio transport over the optional ``bleak`` package."""

    def __init__(self, address=None, name_filter: str = DEFAULT_NAME_FILTER,
                 scan_timeout: float = 10.0, adapter: str = "hci0"):
        self.address = address
        self.name_filter = name_filter
        self.scan_timeout = scan_timeout
        self.adapter = adapter
        self.client = None
        self.device_desc = None
        self._disconnect_cb = None
        self._gen = 0

    def set_disconnect_callback(self, cb):
        self._disconnect_cb = cb

    @staticmethod
    def available():
        return bleak_available()

    async def scan(self):
        from bleak import BleakScanner
        found = []

        def _cb(device, adv):
            nm = adv.local_name or device.name or ""
            uu = [u.lower() for u in (adv.service_uuids or [])]
            if nm.startswith(self.name_filter) or NUS_SERVICE_UUID.lower() in uu:
                found.append((device.address, nm))

        scanner = BleakScanner(detection_callback=_cb, adapter=self.adapter)
        await scanner.start()
        try:
            await asyncio.sleep(self.scan_timeout)
        finally:
            await scanner.stop()
        return found

    async def connect(self):
        from bleak import BleakClient
        if self.address is None:
            peers = await self.scan()
            if not peers:
                raise BleTimeout("no %s* / NUS peripheral found in %.1fs"
                                 % (self.name_filter, self.scan_timeout))
            self.address = peers[0][0]
        self.device_desc = self.address
        # bleak reports a drop to the callback given *here* -- i.e. before the receiver
        # installs the callback for the subscription epoch it is about to create.
        # Resolve the receiver callback at fire time and ignore reports from a
        # superseded client generation, so a live link loss is not discarded as stale
        # (public check real_adapter_link_loss_invalidates_current_receiver) while a
        # dead link's late report still cannot close a newer subscription
        # (old_disconnect_does_not_close_new_subscription).
        self._gen += 1
        gen = self._gen

        def _on_client_disconnect(_client, _gen=gen):
            if _gen != self._gen:
                return
            cb_now = self._disconnect_cb
            if cb_now is not None:
                cb_now()

        self.client = BleakClient(
            self.address, adapter=self.adapter,
            disconnected_callback=_on_client_disconnect)
        await self.client.connect()

    async def start_notify(self, char_uuid, handler):
        await self.client.start_notify(char_uuid, handler)

    async def stop_notify(self, char_uuid):
        await self.client.stop_notify(char_uuid)

    async def disconnect(self):
        self._gen += 1                       # reports from the closed client are stale
        if self.client is not None:
            await self.client.disconnect()


class ThreadedBackendAdapter:
    """Bridge the async receiver to a synchronous consumer (tkinter/GUI, CSV replay).

    A tkinter mainloop cannot ``await``; this adapter runs the receiver in its own
    thread + event loop and exposes a thread-safe ``poll()`` for the GUI. Errors
    (including a dropped link) are captured and re-raised to the consumer instead
    of being swallowed. Tested with an injected transport; real-radio behaviour is
    still unverified.
    """

    def __init__(self, receiver_factory, sample_queue_size: int = 256):
        import queue as _queue
        import threading as _threading
        self._qmod, self._tmod = _queue, _threading
        self.receiver_factory = receiver_factory
        self.queue = _queue.Queue(maxsize=sample_queue_size)
        self.dropped = 0
        self.error = None
        self.started = False
        self._thread = None
        self._loop = None
        self._receiver = None

    # ---- control ---------------------------------------------------------
    def start(self):
        if self.started:
            return self
        self.started = True
        self._thread = self._tmod.Thread(target=self._run, name="p01-ble-rx", daemon=True)
        self._thread.start()
        # bounded wait for the link to come up
        for _ in range(200):
            if self._receiver is not None or self.error is not None:
                break
            time.sleep(0.01)
        return self

    def stop(self, timeout: float = 3.0):
        if self._loop is not None and self._receiver is not None:
            try:
                fut = asyncio.run_coroutine_threadsafe(self._receiver.close(), self._loop)
                fut.result(timeout=timeout)
            except Exception:
                pass
            # The worker may be parked in ``await queue.get()``; a graceful close does
            # not end the stream, so wake it explicitly (public check
            # stop_really_terminates_worker_waiting_for_notifications).
            try:
                self._loop.call_soon_threadsafe(self._receiver.wake)
            except Exception:
                pass
        if self._thread is not None:
            self._thread.join(timeout=timeout)
            if self._thread.is_alive():
                self.started = False
                raise BleError(
                    "receiver worker did not terminate within %.1fs (a link-loss or "
                    "close wake-up is missing)" % timeout)
            self._thread = None
        self.started = False

    # ---- consumer --------------------------------------------------------
    def poll(self, max_items: int = 64):
        out = []
        while len(out) < max_items:
            try:
                out.append(self.queue.get_nowait())
            except self._qmod.Empty:
                break
        if self.error is not None:
            err, self.error = self.error, None
            raise err
        return out

    @property
    def receiver(self):
        return self._receiver

    # ---- thread body -----------------------------------------------------
    def _run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            rx = self.receiver_factory()
            self._receiver = rx
            self._loop.run_until_complete(rx.open())

            async def pump():
                async for (t_s, raw, _payload) in rx.samples():
                    item = (t_s, raw)
                    try:
                        self.queue.put_nowait(item)
                    except self._qmod.Full:
                        self.dropped += 1
            self._loop.run_until_complete(pump())
        except Exception as exc:                     # noqa: BLE001 - surfaced via poll()
            self.error = exc if isinstance(exc, BleError) else BleError(str(exc))
        finally:
            try:
                if self._receiver is not None:
                    self._loop.run_until_complete(self._receiver.close())
            except Exception:
                pass
            self._loop.close()
