"""P01 peer-receiver frame codec.

Source-bound to SI S6: the notification payload is a **2-byte little-endian raw
CDC code** from the AD7156 (12-bit). The GUI scans, connects, enables
notifications, parses the 2-byte LE frame, converts to capacitance and plots /
saves it.

NOT published by the paper (declared reconstruction, see delivery/UNVERIFIED.md):
  * the BLE service/characteristic UUIDs (hardcoded in the original firmware),
  * the AD7156 input-range / CDC-to-farad slope used for the "fF" conversion.
Frame layout itself (2-byte LE, 12-bit) is recovered from SI S6.
"""
from __future__ import annotations

FRAME_LEN = 2
RAW_BITS = 12
RAW_MAX = (1 << RAW_BITS) - 1          # 4095


class FrameError(ValueError):
    """Raised when a notification payload is not a valid P01 CDC frame."""


def decode_frame(payload: bytes) -> int:
    """Decode a 2-byte little-endian frame into a 12-bit raw CDC code.

    Rejects: wrong length, reserved high nibble set (bits 12..15).
    """
    if payload is None:
        raise FrameError("payload is None")
    n = len(payload)
    if n != FRAME_LEN:
        raise FrameError("frame length %d != %d" % (n, FRAME_LEN))
    if payload[1] & 0xF0:
        raise FrameError("reserved high nibble set in byte1=0x%02X" % payload[1])
    return payload[0] | ((payload[1] & 0x0F) << 8)


def encode_frame(raw: int) -> bytes:
    """Encode a 12-bit raw CDC code into a 2-byte little-endian frame."""
    if not isinstance(raw, int):
        raise FrameError("raw code must be int, got %r" % type(raw).__name__)
    if raw < 0 or raw > RAW_MAX:
        raise FrameError("raw code %d out of range 0..%d" % (raw, RAW_MAX))
    return bytes((raw & 0xFF, (raw >> 8) & 0x0F))


class CapacitanceScale:
    """Declared CDC-code -> capacitance conversion.

    The paper states the GUI converts to fF but does NOT publish the AD7156
    input range or excitation, so the slope is an explicit, adjustable
    assumption. Default: 4 pF full scale over 4096 codes (~0.977 fF/LSB).
    """

    def __init__(self, full_scale_fF: float = 4000.0, codes: int = 4096):
        if codes <= 0:
            raise FrameError("codes must be > 0")
        self.full_scale_fF = float(full_scale_fF)
        self.codes = int(codes)
        self.fF_per_lsb = self.full_scale_fF / self.codes

    def to_fF(self, raw: int) -> float:
        if raw < 0 or raw > RAW_MAX:
            raise FrameError("raw code %d out of range" % raw)
        return raw * self.fF_per_lsb


SCALE = CapacitanceScale()            # module default; overridable by the GUI
