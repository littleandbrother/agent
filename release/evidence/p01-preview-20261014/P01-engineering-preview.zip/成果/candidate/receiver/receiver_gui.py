"""P01 peer receiver / GUI (SI S6 behaviour).

Behaviour recovered from SI S6: scan -> connect -> enable notifications ->
parse the 2-byte LE CDC frame -> convert to capacitance -> live plot / save CSV.

Backends:
  * SimulatedBackend : synthetic frames, no hardware -- must be selected
                       explicitly (never used as a silent fallback).
  * real BLE         : ``receiver/ble_backend.py`` scan -> connect -> notify ->
                       decode -> close, used by ``--ble`` (CLI) and by
                       ``--gui --ble`` through a worker-thread bridge.

DECLARED RECONSTRUCTION (see delivery/UNVERIFIED.md):
  * BLE service/characteristic UUIDs are NOT published by the paper. The default
    below uses the standard Nordic UART Service (NUS) UUIDs because the rebuilt
    firmware uses the official ble_app_uart/NUS scaffolding; this is NOT claimed
    as the paper's UUIDs.
  * The CDC-to-fF slope is a declared assumption (receiver/frame.py).
  * A real radio connection is NOT exercised here; only the simulated backend and
    the host codec are.

CLI:  python3 receiver_gui.py --selftest | --replay | --gui [--csv out.csv]
"""
from __future__ import annotations

import argparse
import math
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ble_backend as ble

from frame import CapacitanceScale, encode_frame
from pipeline import ReceiverPipeline

# Standard Nordic UART Service UUIDs (declared reconstruction default, not published by P01).
NUS_SERVICE_UUID = "6E400001-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_RX_CHAR_UUID = "6E400002-B5A3-F393-E0A9-E50E24DCCA9E"
NUS_TX_CHAR_UUID = "6E400003-B5A3-F393-E0A9-E50E24DCCA9E"


class SimulatedBackend:
    """Synthetic 2-byte LE frames; no radio, no device."""

    name = "simulated"

    def __init__(self, n=200, seed=20261008):
        self.rng = random.Random(seed)
        self.n = n
        self.i = 0

    def frames(self):
        while self.i < self.n:
            t_s = self.i * 5.0                                   # SI S6: 5 s sampling
            raw = int(2000 + 1500 * math.sin(self.i / 12.0) + self.rng.randint(-20, 20))
            raw = max(0, min(4095, raw))
            yield t_s, encode_frame(raw)
            self.i += 1


class RealBackend:
    """Real BLE path (raises ``BleUnavailable`` if ``bleak`` is missing).

    The receive logic lives in ``receiver/ble_backend.py``; this thin wrapper keeps
    the GUI naming and never falls back to simulated frames.
    """

    name = "ble"

    def __init__(self, address=None, name_filter=ble.DEFAULT_NAME_FILTER):
        self.address = address
        self.name_filter = name_filter
        self._receiver = None

    @staticmethod
    def available():
        return ble.bleak_available()

    def frames(self):                                            # pragma: no cover
        raise RuntimeError("use receiver/ble_backend.BleReceiver.samples(); "
                           "the real path is asynchronous")


def scan(seconds=5.0):
    """Scan for P01 / NUS peripherals through the real transport."""
    if not ble.bleak_available():
        print("scan unavailable: %s" % _unavailable_msg())
        return 1
    import asyncio
    tr = ble.BleakTransport(scan_timeout=seconds)
    peers = asyncio.run(tr.scan())
    print("found %d peer(s):" % len(peers))
    for addr, nm in peers:
        print("  %s  %s" % (addr, nm or "(no name)"))
    return 0 if peers else 2


def _unavailable_msg():
    return ("the optional 'bleak' package is not importable; install it for the "
            "real BLE path (simulated frames are NOT substituted)")


def run_ble(address=None, seconds=30.0, csv_path=None, name_filter=ble.DEFAULT_NAME_FILTER):
    """Actually callable receive path: connect, notify, decode, save, close."""
    if not ble.bleak_available():
        print("BLE mode unavailable: %s" % _unavailable_msg())
        return 3
    import asyncio

    p = ReceiverPipeline(scale=CapacitanceScale())

    async def _run():
        tr = ble.BleakTransport(address=address, name_filter=name_filter)
        rx = ble.BleReceiver(tr)
        await rx.open()
        try:
            deadline = asyncio.get_running_loop().time() + seconds
            async for t_s, raw, payload in rx.samples(idle_timeout=min(10.0, seconds)):
                p.ingest(t_s, payload)
                print("t=%.2fs raw=%d fF=%.2f" % (t_s, raw, p.samples[-1][2]))
                if asyncio.get_running_loop().time() >= deadline:
                    break
        finally:
            await rx.close()
        return rx

    rx = asyncio.run(_run())
    if csv_path:
        os.makedirs(os.path.dirname(os.path.abspath(csv_path)) or ".", exist_ok=True)
        p.to_csv(csv_path)
    print("backend=ble peer=%s received=%d rejects=%d stale=%d"
          % (getattr(rx.transport, "device_desc", address), p.received, p.rejects, rx.queue.stale))
    return 0


def run_selftest(csv_path=None):
    """Decode synthetic frames end-to-end without a GUI or radio."""
    p = ReceiverPipeline(scale=CapacitanceScale())
    for t_s, payload in SimulatedBackend(n=50).frames():
        p.ingest(t_s, payload)
    if csv_path:
        os.makedirs(os.path.dirname(os.path.abspath(csv_path)) or ".", exist_ok=True)
        p.to_csv(csv_path)
    print("backend=simulated received=%d rejects=%d samples=%d" % (p.received, p.rejects, len(p.samples)))
    if p.samples:
        print("first raw=%d fF=%.3f  last raw=%d fF=%.3f" % (
            p.samples[0][1], p.samples[0][2], p.samples[-1][1], p.samples[-1][2]))
    return p


def run_replay(csv_path):
    return run_selftest(csv_path)


def run_gui(csv_path=None, ble_address=None, name_filter=ble.DEFAULT_NAME_FILTER):  # pragma: no cover
    import tkinter as tk
    from collections import deque
    adapter = None
    if ble_address is not None:
        if not ble.bleak_available():
            print("BLE mode unavailable: %s" % _unavailable_msg())
            return 3
        adapter = ble.ThreadedBackendAdapter(
            lambda: ble.BleReceiver(ble.BleakTransport(address=ble_address or None,
                                                       name_filter=name_filter))).start()
        if adapter.receiver is None and adapter.error is not None:
            print("BLE link failed: %s" % adapter.error)
            return 4
        backend = None
    else:
        backend = SimulatedBackend(n=400)
    p = ReceiverPipeline(scale=CapacitanceScale())
    root = tk.Tk()
    root.title("P01 CDC receiver (%s)" % ("real BLE" if adapter else "simulated backend"))
    txt = tk.Text(root, height=4, width=64)
    txt.pack()
    canvas = tk.Canvas(root, width=640, height=240, bg="white")
    canvas.pack()
    series = deque(maxlen=200)

    stop = {"done": False}

    def pump():
        if adapter is not None:
            try:
                batch = adapter.poll()
                banner = ("backend=ble (real radio path)  n=%d\n%s\n%s" % (
                    len(p.samples), "UUIDs/slope are declared reconstruction, see delivery/UNVERIFIED.md",
                    "A real peripheral connection is still UNVERIFIED."))
            except ble.BleError as exc:
                txt.delete("1.0", "end")
                txt.insert("end", "BLE link error: %s" % exc)
                adapter.stop()
                return
            for t_s, raw in batch:
                series.append(p.ingest(t_s, encode_frame_raw(raw))[1])
            if not batch:
                pass
            fF = series[-1] if series else float("nan")
            txt.delete("1.0", "end")
            txt.insert("end", banner)
            _draw(canvas, series)
            root.after(50, pump)
            return
        try:
            t_s, payload = next(backend.gen)
        except StopIteration:
            return
        _, fF = p.ingest(t_s, payload)
        series.append(fF)
        txt.delete("1.0", "end")
        txt.insert("end", "backend=%s  n=%d  raw_fF=%.2f\n%s\n%s\n" % (
            backend.name, len(p.samples), fF,
            "WARNING: SIMULATED frames, not a real device.",
            "UUIDs/slope are declared reconstruction, see delivery/UNVERIFIED.md"))
        _draw(canvas, series)
        root.after(50, pump)

    backend.gen = backend.frames()
    pump()
    root.mainloop()


def encode_frame_raw(raw):
    """Pack a raw 12-bit code with the firmware's little-endian layout."""
    return encode_frame(raw)


def _draw(canvas, series):                                       # pragma: no cover
    canvas.delete("all")
    if len(series) > 1:
        lo, hi = min(series), max(series)
        rng = (hi - lo) or 1.0
        pts = []
        for i, v in enumerate(series):
            pts += [i * 640 / len(series), 230 - (v - lo) / rng * 220]
        canvas.create_line(*pts, fill="navy")


def main(argv=None):
    ap = argparse.ArgumentParser(description="P01 peer receiver (SI S6 behaviour)")
    ap.add_argument("--gui", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--replay", action="store_true")
    ap.add_argument("--scan", action="store_true", help="scan for P01/NUS peers (real radio)")
    ap.add_argument("--ble", nargs="?", const="", default=None,
                    help="real BLE receive path; optional address/name")
    ap.add_argument("--name-filter", default=ble.DEFAULT_NAME_FILTER)
    ap.add_argument("--seconds", type=float, default=30.0)
    ap.add_argument("--csv", default="")
    args = ap.parse_args(argv)
    if args.scan:
        return scan(min(args.seconds, 10.0))
    if args.ble is not None and not args.gui:
        return run_ble(address=(args.ble or None), seconds=args.seconds,
                       csv_path=(args.csv or None), name_filter=args.name_filter)
    if args.selftest or args.replay:
        run_selftest(args.csv or None)
        return 0
    if args.gui:
        return run_gui(args.csv or None, ble_address=args.ble,
                       name_filter=args.name_filter)
    print("backend availability: simulated=True ble=%s" % RealBackend.available())
    print("no mode selected; use --selftest, --replay or --gui")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
