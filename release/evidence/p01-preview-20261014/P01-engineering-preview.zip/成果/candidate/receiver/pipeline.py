"""Headless receive pipeline (no GUI, no radio) shared by the GUI and tests.

Ingests raw notification payloads, decodes the P01 2-byte LE CDC frame, keeps a
bounded time series and can persist it to CSV (SI S6 behaviour). A frame that
fails to decode is counted as a reject and does not enter the series.
"""
from __future__ import annotations

import csv
from typing import List, Optional, Tuple

from frame import FrameError, CapacitanceScale, decode_frame, RAW_MAX


class ReceiverPipeline:
    def __init__(self, scale: Optional[CapacitanceScale] = None, maxlen: int = 4096):
        self.scale = scale or CapacitanceScale()
        self.maxlen = int(maxlen)
        self.samples: List[Tuple[float, int, float]] = []   # (t_s, raw, fF)
        self.received = 0
        self.rejects = 0
        self.bad_frames: List[bytes] = []

    def ingest(self, t_s: float, payload: bytes) -> Tuple[int, float]:
        """Return (raw, fF); raise FrameError for a malformed frame."""
        self.received += 1
        try:
            raw = decode_frame(payload)
        except FrameError:
            self.rejects += 1
            self.bad_frames.append(bytes(payload) if payload else b"")
            raise
        fF = self.scale.to_fF(raw)
        self.samples.append((float(t_s), raw, fF))
        if len(self.samples) > self.maxlen:
            del self.samples[: len(self.samples) - self.maxlen]
        return raw, fF

    def reset(self) -> None:
        self.samples.clear()
        self.bad_frames.clear()
        self.received = 0
        self.rejects = 0

    def to_csv(self, path: str) -> int:
        with open(path, "w", newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["t_s", "raw_12bit", "capacitance_fF"])
            for t_s, raw, fF in self.samples:
                w.writerow(["%.6f" % t_s, raw, "%.4f" % fF])
        return len(self.samples)

    @staticmethod
    def read_csv(path: str):
        rows = []
        with open(path, newline="") as fh:
            r = csv.reader(fh)
            header = next(r)
            if header != ["t_s", "raw_12bit", "capacitance_fF"]:
                raise FrameError("unexpected CSV header: %r" % (header,))
            for row in r:
                rows.append((float(row[0]), int(row[1]), float(row[2])))
        return rows
