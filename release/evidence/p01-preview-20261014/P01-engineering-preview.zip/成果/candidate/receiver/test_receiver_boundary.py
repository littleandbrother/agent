"""Pi-owned regression for the four receiver-boundary defects reported in
campaign/reviews/P01/receiver-boundary-001/result.json.

These checks are written by the same participant that wrote the fix: they are a
regression guard, NOT independent verification. The public reviewer re-runs its
own copy against the frozen sources.

Covered (names mirror the public findings):
 1 real_adapter_installs_initial_disconnect_callback
 2 real_adapter_link_loss_invalidates_current_receiver
 3 old_disconnect_does_not_close_new_subscription
 4 queued_old_packet_is_not_attributed_to_new_connection
 5 malformed_packet_is_rejected_and_valid_twelve_bit_packet_survives
 6 stop_really_terminates_worker_waiting_for_notifications
"""
from __future__ import annotations

import asyncio
import os
import sys
import threading
import time
import types

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ble_backend as bb  # noqa: E402

CHECKS = []
FAILURES = []


def check(name, cond, detail=""):
    CHECKS.append((name, bool(cond), detail))
    if not cond:
        FAILURES.append((name, detail))


def run(coro):
    return asyncio.new_event_loop().run_until_complete(coro)


class FakeTransport:
    """Shaped like BleakTransport: one callback slot, epoch-agnostic firing."""

    def __init__(self):
        self.cb = None
        self.calls = []
        self.live = False

    def set_disconnect_callback(self, cb):
        self.cb = cb

    async def connect(self):
        self.calls.append("connect")
        self.live = True

    async def start_notify(self, char_uuid, handler):
        self.calls.append("start_notify")
        self.handler = handler

    async def stop_notify(self, char_uuid):
        self.calls.append("stop_notify")
        self.live = False

    async def disconnect(self):
        self.calls.append("disconnect")
        self.live = False

    def fire_disconnect(self):
        if self.cb:
            self.cb()


def frame(raw: int) -> bytes:
    return bytes([raw & 0xFF, (raw >> 8) & 0x0F])


def test_1_and_3_and_4():
    async def body():
        t = FakeTransport()
        rx = bb.BleReceiver(t)
        check("1 real_adapter_installs_initial_disconnect_callback",
              t.cb is not None, "callback installed before connect")
        await rx.open()
        old_epoch_cb = t.cb
        # queue a packet for the current (old) connection but do not consume it
        t.handler(None, frame(111))
        await asyncio.sleep(0.05)            # delivery is scheduled on the loop
        check("4a old packet queued under live epoch", rx.queue._queue.qsize() == 1,
              "qsize=%d" % rx.queue._queue.qsize())

        # old link reports a disconnect while a *new* subscription is coming up
        await rx.open()                      # epoch N+1, same transport
        old_epoch_cb()                       # late report of the dead link
        check("3 old_disconnect_does_not_close_new_subscription",
              rx.closed is False,
              "closed=%s epoch=%d" % (rx.closed, rx.epoch))

        # the packet queued before the re-open must not be delivered now
        gen = rx.samples(max_samples=1, idle_timeout=0.3)
        got = None
        try:
            got = await gen.__anext__()
        except Exception as exc:             # timeout is the correct outcome here
            got = ("timeout", type(exc).__name__)
        check("4 queued_old_packet_is_not_attributed_to_new_connection",
              isinstance(got, tuple) and got[0] == "timeout",
              "old packet must be dropped, got=%r" % (got,))

        # a *current* packet is still delivered (fresh generator: the timed-out one
        # is already exhausted)
        t.handler(None, frame(222))
        got2 = await rx.samples(max_samples=1, idle_timeout=1.0).__anext__()
        check("4b current packet delivered", got2[1] == 222, "raw=%s" % got2[1])
        await rx.close()

    run(body())


def test_2_link_loss_invalidates():
    async def body():
        t = FakeTransport()
        rx = bb.BleReceiver(t)
        await rx.open()
        t.fire_disconnect()
        check("2 real_adapter_link_loss_invalidates_current_receiver",
              rx.closed is True, "closed=%s" % rx.closed)
        err = None
        try:
            async for _ in rx.samples(max_samples=1, idle_timeout=0.2):
                pass
        except Exception as exc:  # BleError expected
            err = type(exc).__name__
        check("2b blocked consumer wakes on link loss", err is not None, "err=%s" % err)

    run(body())


def test_5_malformed_and_valid():
    async def body():
        t = FakeTransport()
        rx = bb.BleReceiver(t)
        await rx.open()
        t.handler(None, bytes([0xAB]))       # 1 byte -> malformed
        t.handler(None, frame(4095))          # valid 12-bit
        out = []
        async for item in rx.samples(max_samples=1, idle_timeout=1.0):
            out.append(item)
        check("5 malformed_packet_is_rejected_and_valid_twelve_bit_packet_survives",
              rx.queue.rejects == 1 and out and out[0][1] == 4095,
              "rejects=%d out=%r" % (rx.queue.rejects, out))
        await rx.close()

    run(body())


def test_6_stop_terminates_worker():
    t = FakeTransport()
    adapter = bb.ThreadedBackendAdapter(lambda: bb.BleReceiver(t))
    adapter.start()
    time.sleep(0.1)
    check("6a worker reports started", adapter.receiver is not None)
    err = None
    try:
        adapter.stop(timeout=2.0)
    except Exception as exc:
        err = exc
    alive = [th for th in threading.enumerate() if th.name == "p01-ble-rx"]
    check("6 stop_really_terminates_worker_waiting_for_notifications",
          not alive and err is None,
          "alive=%d err=%r" % (len(alive), err))


def test_1b_bleak_client_gets_constructor_callback():
    """The real transport must hand bleak a disconnected_callback at construction."""
    seen = {}

    class FakeClient:
        def __init__(self, address, adapter=None, disconnected_callback=None, **kw):
            seen["cb"] = disconnected_callback
            seen["address"] = address

        async def connect(self):
            pass

    fake_bleak = types.ModuleType("bleak")
    fake_bleak.BleakClient = FakeClient
    saved = sys.modules.get("bleak")
    sys.modules["bleak"] = fake_bleak
    try:
        tr = bb.BleakTransport(address="AA:BB:CC:DD:EE:FF")
        fired = []
        tr.set_disconnect_callback(lambda *a: fired.append(True))
        run(tr.connect())
    finally:
        if saved is None:
            sys.modules.pop("bleak", None)
        else:
            sys.modules["bleak"] = saved
    present = seen.get("cb") is not None
    check("1b BleakClient constructed with disconnected_callback", present,
          "callback=%r" % (seen.get("cb"),))
    if present:
        seen["cb"](None)
        check("1c constructor callback reaches the receiver hook", fired == [True])


def test_2c_real_adapter_link_loss():
    """Public check ``real_adapter_link_loss_invalidates_current_receiver``.

    Exercises the *real adapter* path (ThreadedBackendAdapter over BleakTransport with
    a stand-in ``bleak`` module). bleak reports a drop to the callback the transport
    handed to ``BleakClient`` at construction -- i.e. a callback that exists *before*
    the subscription epoch does -- so a live link loss must still reach the current
    receiver instead of being discarded as stale.
    """
    seen = {}

    class FakeClient:
        def __init__(self, address, adapter=None, disconnected_callback=None, **kw):
            seen["cb"] = disconnected_callback
            self._cb = disconnected_callback
            seen["address"] = address

        async def connect(self):
            pass

        async def start_notify(self, char_uuid, handler):
            seen["handler"] = handler

        async def stop_notify(self, char_uuid):
            pass

        async def disconnect(self):
            pass

        def fire(self):                      # bleak: "the peer went away"
            if self._cb is not None:
                self._cb(self)

    fake_bleak = types.ModuleType("bleak")
    fake_bleak.BleakClient = FakeClient
    saved = sys.modules.get("bleak")
    sys.modules["bleak"] = fake_bleak
    try:
        transport = bb.BleakTransport(address="AA:BB:CC:DD:EE:FF")
        adapter = bb.ThreadedBackendAdapter(lambda: bb.BleReceiver(transport))
        adapter.start()
        time.sleep(0.2)
        client = transport.client
        check("2c0 real adapter brought the link up",
              client is not None and adapter.receiver is not None,
              "client=%r rx=%r" % (client, adapter.receiver))
        check("2c1 BleakClient got a ctor disconnect callback",
              seen.get("cb") is not None, "cb=%r" % (seen.get("cb"),))
        client.fire()                        # the *live* peer drops
        time.sleep(0.15)
        rx = adapter.receiver
        check("2c real_adapter_link_loss_invalidates_current_receiver",
              rx is not None and rx.closed is True,
              "closed=%s" % (None if rx is None else rx.closed))
        err = None
        for _ in range(60):
            try:
                adapter.poll()
            except Exception as exc:         # surfaced to the consumer, not swallowed
                err = type(exc).__name__
                break
            time.sleep(0.02)
        check("2c2 adapter surfaces the link loss to the consumer",
              err is not None, "err=%s" % err)
        try:
            adapter.stop(timeout=2.0)
        except Exception:
            pass
    finally:
        if saved is None:
            sys.modules.pop("bleak", None)
        else:
            sys.modules["bleak"] = saved


def main():
    test_1_and_3_and_4()
    test_2_link_loss_invalidates()
    test_2c_real_adapter_link_loss()
    test_5_malformed_and_valid()
    test_6_stop_terminates_worker()
    test_1b_bleak_client_gets_constructor_callback()
    for name, ok, detail in CHECKS:
        print("%-4s %s  %s" % ("PASS" if ok else "FAIL", name, detail))
    print("checks=%d failed=%d" % (len(CHECKS), len(FAILURES)))
    return 1 if FAILURES else 0


if __name__ == "__main__":
    sys.exit(main())
