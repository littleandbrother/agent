"""Host tests for the P01 receiver BLE path (no radio involved).

Covers: the 2-byte LE / 12-bit CDC protocol exactly as the rebuilt S132 firmware
packs it (``app_policy.c``), connection-identity handling of late notifications
across a reconnect, bounded failure on disconnect / silence, and the explicit
(never silent) unavailability of the real radio stack.

Run: python3 receiver/test_ble_backend.py
"""
from __future__ import annotations

import asyncio
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ble_backend as bb
import frame as fr

FAILURES = []
CHECKS = []


def check(name, cond, detail=""):
    CHECKS.append((name, bool(cond), detail))
    if not cond:
        FAILURES.append((name, detail))
    print("%-52s %s %s" % (name, "PASS" if cond else "FAIL", detail))


class FakeTransport:
    """Injected transport: records lifecycle calls, can inject notifications."""

    def __init__(self):
        self.calls = []
        self.handler = None
        self.live = False
        self.fail_connect = None

    async def connect(self):
        self.calls.append("connect")
        if self.fail_connect:
            raise self.fail_connect
        self.live = True

    async def start_notify(self, char_uuid, handler):
        self.calls.append("start_notify:%s" % char_uuid[-12:])
        self.handler = handler

    async def stop_notify(self, char_uuid):
        self.calls.append("stop_notify")

    async def disconnect(self):
        self.calls.append("disconnect")
        self.live = False

    def set_disconnect_callback(self, cb):
        self.disconnect_cb = cb

    def fire_disconnect(self):
        """Simulate the radio reporting a dropped link."""
        self.live = False
        if getattr(self, "disconnect_cb", None):
            self.disconnect_cb()

    def notify(self, data: bytes, epoch_handler=None):
        """Deliver a notification through the handler registered at subscribe time."""
        h = epoch_handler or self.handler
        if h is None:
            raise AssertionError("no handler registered")
        h(None, bytearray(data))


def run(coro):
    return asyncio.run(coro)


# --- 1. protocol identity with the firmware ---------------------------------
def test_protocol_vectors():
    # canonical packing produced by app_policy.c: payload[0]=raw&0xFF, payload[1]=(raw>>8)&0x0F
    vectors = [(0, b"\x00\x00"), (1, b"\x01\x00"), (0x0FFF, b"\xff\x0f"),
               (0x0800, b"\x00\x08"), (0x0123, b"\x23\x01")]
    ok = True
    for raw, payload in vectors:
        ok &= fr.encode_frame(raw) == payload
        ok &= fr.decode_frame(payload) == raw
    check("protocol: firmware packing round-trips", ok)
    # big-endian / full-16-bit misreadings must be rejected or differ (guards a receiver regression)
    check("protocol: high nibble of byte1 rejected",
          raises(fr.decode_frame, b"\x00\x10") and raises(fr.decode_frame, b"\x00\xF0"))
    check("protocol: wrong length rejected",
          raises(fr.decode_frame, b"\x00") and raises(fr.decode_frame, b"\x00\x00\x00"))
    check("protocol: BE reading is not silently accepted",
          fr.decode_frame(b"\x23\x01") != int.from_bytes(b"\x23\x01", "big"))


def raises(fn, *a, **k):
    try:
        fn(*a, **k)
    except Exception:
        return True
    return False


# --- 2. end-to-end over an injected transport -------------------------------
async def _e2e():
    t = FakeTransport()
    rx = bb.BleReceiver(t)
    await rx.open()
    got = []
    agen = rx.samples(max_samples=3, idle_timeout=1.0)
    async def pump():
        async for s in agen:
            got.append(s)
    task = asyncio.ensure_future(pump())
    await asyncio.sleep(0)
    for raw in (0x0001, 0x0800, 0x0FFF):
        t.notify(fr.encode_frame(raw))
        await asyncio.sleep(0)
    await asyncio.wait_for(task, 2.0)
    await rx.close()
    return t, got


def test_e2e():
    t, got = run(_e2e())
    raws = [g[1] for g in got]
    check("e2e: three notifications decoded in order", raws == [0x0001, 0x0800, 0x0FFF], str(raws))
    check("e2e: lifecycle order connect->notify->stop->disconnect",
          t.calls[0] == "connect"
          and t.calls[1].startswith("start_notify:") and t.calls[1].endswith(bb.NUS_TX_CHAR_UUID[-12:])
          and t.calls[-2:] == ["stop_notify", "disconnect"],
          str(t.calls))


# --- 3. bad payloads are rejected without killing the stream -----------------
async def _rejects():
    t = FakeTransport()
    rx = bb.BleReceiver(t)
    await rx.open()
    out = []
    async def pump():
        async for s in rx.samples(max_samples=2, idle_timeout=1.0):
            out.append(s)
    task = asyncio.ensure_future(pump())
    await asyncio.sleep(0)
    t.notify(b"\x11")                    # short frame
    t.notify(b"\x00\x10")                # reserved nibble set
    await asyncio.sleep(0)
    t.notify(fr.encode_frame(0x0ABC))    # first good sample
    t.notify(b"\xaa\xbb\xcc")            # oversized frame
    await asyncio.sleep(0)
    t.notify(fr.encode_frame(0x0DEF))    # second good sample
    await asyncio.wait_for(task, 2.0)
    await rx.close()
    return rx, out


def test_rejects():
    rx, out = run(_rejects())
    check("rejects: invalid payloads counted, stream survives",
          [o[1] for o in out] == [0x0ABC, 0x0DEF] and rx.queue.rejects == 3,
          "raws=%s rejects=%d" % ([o[1] for o in out], rx.queue.rejects))


# --- 4. connection identity across a reconnect -------------------------------
async def _identity():
    t = FakeTransport()
    rx = bb.BleReceiver(t)
    await rx.open()
    old_handler = t.handler
    out = []
    async def pump():
        # One sample is all connection #2 is allowed to yield here: the payload that
        # connection #1 left queued is discarded on re-open (see test_identity).
        async for s in rx.samples(max_samples=1, idle_timeout=1.0):
            out.append(s)
    task = asyncio.ensure_future(pump())
    await asyncio.sleep(0)
    t.notify(fr.encode_frame(0x0100))            # belongs to connection #1
    # link drop -> reopen: connection #2, new subscription
    await rx.close()
    await rx.open()
    # a late notification of the DEAD connection (old handler) must not be accepted
    t.notify(fr.encode_frame(0x0BAD), epoch_handler=old_handler)
    await asyncio.sleep(0)
    t.notify(fr.encode_frame(0x0200))            # genuine #2 sample (positive case)
    await asyncio.wait_for(task, 2.0)
    await rx.close()
    return rx, out


def test_identity():
    rx, out = run(_identity())
    raws = [o[1] for o in out]
    check("identity: late notification of dead link dropped",
          rx.queue.stale >= 1 and 0x0BAD not in raws, "stale=%d raws=%s" % (rx.queue.stale, raws))
    # A sample queued under connection #1 is dropped as well: it was captured against
    # the dead link's t0 and must not be attributed to connection #2
    # (public check queued_old_packet_is_not_attributed_to_new_connection).
    check("identity: first genuine sample of the new link accepted",
          raws == [0x0200], str(raws))
    check("identity: epoch advanced on reopen", rx.epoch >= 3, "epoch=%d" % rx.epoch)


# --- 5. bounded failure: silence, disconnect, connect error -------------------
async def _silence():
    t = FakeTransport()
    rx = bb.BleReceiver(t, notify_timeout=0.2)
    await rx.open()
    try:
        async for _ in rx.samples(idle_timeout=0.2):
            pass
    except bb.BleTimeout:
        return rx, "BleTimeout"
    except Exception as e:                       # noqa: BLE001
        return rx, type(e).__name__
    finally:
        await rx.close()
    return rx, "no-exception"


async def _disconnect():
    t = FakeTransport()
    rx = bb.BleReceiver(t)
    await rx.open()

    async def drop():
        await asyncio.sleep(0.05)
        t.fire_disconnect()

    asyncio.ensure_future(drop())
    try:
        async for _ in rx.samples(max_samples=5, idle_timeout=2.0):
            pass
    except bb.BleError as e:
        await rx.close()
        return type(e).__name__, rx.epoch, rx.closed
    await rx.close()
    return "no-exception", rx.epoch, rx.closed


async def _connect_fail():
    t = FakeTransport()
    t.fail_connect = OSError("adapter down")
    rx = bb.BleReceiver(t)
    try:
        await rx.open()
    except bb.BleError as e:
        return type(e).__name__ + ":" + str(e)
    return "no-exception"


def test_bounded_failures():
    _, r1 = run(_silence())
    check("failure: silence raises BleTimeout (no hang)", r1 == "BleTimeout", r1)
    r2 = run(_disconnect())[0]
    check("failure: disconnect surfaces BleError", r2 == "BleError", r2)
    _, epoch_after, closed_after = run(_disconnect())
    check("failure: link loss invalidates epoch and marks closed",
          epoch_after >= 2 and closed_after is True,
          "epoch=%d closed=%s" % (epoch_after, closed_after))
    r3 = run(_connect_fail())
    check("failure: transport connect error wrapped, epoch left clean",
          r3.startswith("BleError:connect failed"), r3)


def test_threaded_adapter():
    """The GUI bridge must deliver samples and surface a dropped link as an error."""
    t = FakeTransport()
    ad = bb.ThreadedBackendAdapter(lambda: bb.BleReceiver(t))
    ad.start()
    for _ in range(300):
        if getattr(t, "handler", None) is not None:
            break
        time.sleep(0.01)
    check("adapter: link came up in the worker thread", getattr(t, "handler", None) is not None)
    for raw in (0x0F00, 0x0777):
        t.notify(fr.encode_frame(raw))
    got = []
    for _ in range(300):
        got = ad.poll()
        if len(got) >= 2:
            break
        time.sleep(0.01)
    check("adapter: samples reach the synchronous consumer",
          [g[1] for g in got] == [0x0F00, 0x0777], str([g[1] for g in got]))
    t.fire_disconnect()
    err = None
    for _ in range(300):
        try:
            ad.poll()
        except bb.BleError as e:
            err = e
            break
        time.sleep(0.01)
    check("adapter: dropped link surfaces as BleError (not silence)", err is not None, str(err))
    ad.stop()
    check("adapter: stop() joins the worker", not ad.started)


def test_real_stack_availability():
    # The real path must never be reached by silent fallback: report availability.
    avail = bb.bleak_available()
    if avail:
        rx = bb.real_backend()
        check("radio: bleak importable, real backend constructed",
              isinstance(rx, bb.BleReceiver) and isinstance(rx.transport, bb.BleakTransport))
    else:
        ok = raises(bb.BleUnavailable.__init__, "") if False else False
        try:
            bb.real_backend()
            ok = False
        except bb.BleUnavailable:
            ok = True
        check("radio: bleak missing -> BleUnavailable (no silent fallback)", ok)
    print("RADIO NOTE: bleak_available=%s; no real peripheral/connection was "
          "exercised in this session" % avail)
    return avail


def main():
    print("P01 receiver BLE-path host tests (no radio)")
    print("-" * 72)
    test_protocol_vectors()
    test_e2e()
    test_rejects()
    test_identity()
    test_bounded_failures()
    test_threaded_adapter()
    test_real_stack_availability()
    print("-" * 72)
    print("checks=%d failed=%d" % (len(CHECKS), len(FAILURES)))
    for n, d in FAILURES:
        print("FAILED: %s %s" % (n, d))
    return 1 if FAILURES else 0


if __name__ == "__main__":
    raise SystemExit(main())
