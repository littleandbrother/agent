/* app_policy.c - P01 application core state machine (target-independent).
 *
 * Fixes the public counterexamples from
 * campaign/reviews/P01/fault-check-001/result.json:
 *   (1) sample_before_start_rejected
 *   (2) late_sample_after_disconnect_rejected
 *   (3) failed_send_not_counted_as_delivery
 * and from campaign/reviews/P01/fault-check-002/result.json:
 *   (4) completion_without_sample_request_rejected  (no request -> NO_REQUEST)
 *   (5) duplicate_sample_completion_rejected        (1 outstanding request)
 *   (6) declared_five_second_sample_cadence         (strict 5 s request cadence)
 *   (7) actual_bridge_rejects_old_connection_completion (queued-tag identity)
 * and from campaign/reviews/P01/fault-check-003/result.json:
 *   (8) first_current_completion_after_reconnect_delivers_current_packet
 *   (9) foreign_connection_cannot_retire_current_packet  (HVN conn_handle gate)
 *  (10) delayed_notification_does_not_wedge_sampling      (no latched request)
 * plus independent negatives for queue-full, retry, empty data and buffer
 * lifetime. See host-test-s132/host_test.c for the matrix.
 *
 * No target driver is referenced here.
 */
#include "app_policy.h"

/* Wrap-safe elapsed time: true for unsigned counters wrapping at 2^32. */
static int32_t elapsed_ms(uint32_t now, uint32_t t0)
{
    return (int32_t)(now - t0);
}

/* ---- queued NUS send tag FIFO -------------------------------------------
 * The identity of a transmission is latched at QUEUE time. A completion
 * callback therefore resolves against the tag it actually belongs to, not
 * against the live connection, which may already have advanced. Bounded and
 * drop-oldest so a lost completion can never wedge the FIFO. */
static void txq_push(app_ctx_t *c, uint8_t kind, uint16_t epoch, uint16_t req_id)
{
    if (c->txq_count == APP_TXQ_DEPTH) {           /* drop oldest */
        c->txq_head = (uint8_t)((c->txq_head + 1u) % APP_TXQ_DEPTH);
        c->txq_count--;
    }
    c->txq_epoch[c->txq_tail] = epoch;
    c->txq_req[c->txq_tail]   = req_id;
    c->txq_kind[c->txq_tail]  = kind;
    c->txq_tail = (uint8_t)((c->txq_tail + 1u) % APP_TXQ_DEPTH);
    c->txq_count++;
}

static int txq_pop(app_ctx_t *c, uint8_t *kind, uint16_t *epoch, uint16_t *req_id)
{
    if (c->txq_count == 0) { return 0; }
    *kind    = c->txq_kind[c->txq_head];
    *epoch   = c->txq_epoch[c->txq_head];
    *req_id  = c->txq_req[c->txq_head];
    c->txq_head = (uint8_t)((c->txq_head + 1u) % APP_TXQ_DEPTH);
    c->txq_count--;
    return 1;
}

/* Drop every queued tag that does not belong to the CURRENT connection epoch.
 * Called whenever the epoch advances (connect/disconnect). Without this, an old
 * connection's tag stays at the FIFO head and the first completion of the NEW
 * connection is resolved against it and rejected - i.e. the new connection's
 * first real completion would be swallowed. */
static void txq_drop_stale(app_ctx_t *c)
{
    uint8_t  n = c->txq_count, i;
    uint8_t  head = c->txq_head;
    uint16_t keep = c->conn_epoch;

    c->txq_count = 0;
    c->txq_head  = 0;
    c->txq_tail  = 0;
    for (i = 0; i < n; i++) {
        uint8_t idx = (uint8_t)((head + i) % APP_TXQ_DEPTH);
        if (c->txq_epoch[idx] != keep) { continue; }
        c->txq_epoch[c->txq_tail] = c->txq_epoch[idx];
        c->txq_req[c->txq_tail]   = c->txq_req[idx];
        c->txq_kind[c->txq_tail]  = c->txq_kind[idx];
        c->txq_tail = (uint8_t)((c->txq_tail + 1u) % APP_TXQ_DEPTH);
        c->txq_count++;
    }
}

void app_init(app_ctx_t *c, const app_cfg_t *cfg)
{
    (void)cfg;
    if (c == 0) { return; }
    c->started = 0;
    c->connected = 0;
    c->rail_ok = 0;
    c->fault = 0;
    c->awaiting_sample = 0;
    c->sample_pending = 0;
    c->tx_in_flight = 0;
    c->conn_epoch = 0;
    c->req_epoch = 0;
    c->tx_epoch = 0;
    c->tx_req_id = 0;
    c->next_req_id = 0;
    c->last_raw = 0;
    c->payload[0] = 0;
    c->payload[1] = 0;
    c->payload_len = 0;
    c->t_next_sample = 0;
    c->t_last_sample_ms = 0;
    c->t_next_adv = 0;
    c->txq_head = 0;
    c->txq_tail = 0;
    c->txq_count = 0;
    c->samples = 0;
    c->samples_rejected = 0;
    c->notifications = 0;
    c->notify_attempts = 0;
    c->notify_stale = 0;
    c->send_failures = 0;
    c->retries = 0;
    c->faults = 0;
}

app_res_t app_on_rail(app_ctx_t *c, const app_cfg_t *cfg, uint32_t rail_mv)
{
    if (c == 0) { return APP_REJ_NOT_STARTED; }
    if (rail_mv < cfg->cold_start_mv) {
        /* Rail below cold-start: force idle and invalidate any binding. */
        c->rail_ok = 0;
        c->started = 0;
        c->connected = 0;
        c->awaiting_sample = 0;
        c->sample_pending = 0;
        c->tx_in_flight = 0;
        c->conn_epoch++;
        return APP_REJ_NOT_STARTED;
    }
    c->rail_ok = 1;
    return APP_ACC;
}

app_res_t app_on_manual_start(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms)
{
    (void)cfg;
    if (c == 0) { return APP_REJ_NOT_STARTED; }
    if (c->fault) { return APP_FAULT; }
    if (!c->rail_ok) { return APP_REJ_NOT_STARTED; }
    c->started = 1;
    c->t_next_adv = now_ms;
    return APP_ACC;
}

app_res_t app_on_connected(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms)
{
    if (c == 0) { return APP_REJ_NOT_STARTED; }
    if (!c->started) { return APP_REJ_NOT_STARTED; }
    c->conn_epoch++;               /* bind all future async work to this epoch */
    c->connected = 1;
    c->awaiting_sample = 0;
    c->sample_pending = 0;
    c->tx_in_flight = 0;
    txq_drop_stale(c);             /* nothing from a previous epoch may block */
    /* first sample is due immediately after connect (1 request per period) */
    c->t_next_sample = now_ms;
    (void)cfg;
    return APP_ACC;
}

app_res_t app_on_disconnected(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms)
{
    if (c == 0) { return APP_REJ_NOT_CONNECTED; }
    c->connected = 0;
    c->conn_epoch++;               /* invalidates every in-flight request       */
    c->awaiting_sample = 0;
    c->sample_pending = 0;
    c->tx_in_flight = 0;
    txq_drop_stale(c);             /* old connection's tags must not block the next */
    c->t_next_adv = now_ms;
    (void)cfg;
    return APP_ACC;
}

app_act_t app_tick(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms)
{
    if (c == 0 || c->fault) { return APP_ACT_NONE; }

    if (c->started && !c->connected) {
        if (elapsed_ms(now_ms, c->t_next_adv) >= (int32_t)cfg->adv_period_ms) {
            c->t_next_adv = now_ms;
            return APP_ACT_START_ADV;
        }
        return APP_ACT_NONE;
    }

    if (c->connected) {
        /* Exactly one outstanding sample request, issued once per declared
         * period measured from the previous REQUEST (not from its result). */
        if (!c->awaiting_sample && elapsed_ms(now_ms, c->t_next_sample) >= 0) {
            c->awaiting_sample = 1;
            c->req_epoch = c->conn_epoch;   /* bind request to the live epoch */
            c->t_last_sample_ms = now_ms;
            return APP_ACT_START_SAMPLE;
        }
        /* Deliver a pending sample (buffer lifetime guarded by tx_in_flight). */
        if (c->sample_pending && !c->tx_in_flight) {
            if (c->payload_len == 0) {       /* empty-data guard: never sent */
                c->sample_pending = 0;
                c->send_failures++;
                return APP_ACT_NONE;
            }
            c->tx_in_flight = 1;
            c->tx_epoch = c->conn_epoch;     /* bind send to the live epoch */
            c->next_req_id++;
            c->tx_req_id = c->next_req_id;
            /* latched now: the completion resolves against THIS tag */
            txq_push(c, APP_TXK_SENSOR, c->tx_epoch, c->tx_req_id);
            return APP_ACT_NOTIFY;
        }
    }
    return APP_ACT_NONE;
}

app_res_t app_on_sample_result(app_ctx_t *c, const app_cfg_t *cfg,
                               uint16_t req_epoch, app_err_t err,
                               uint16_t reg16, uint32_t now_ms)
{
    if (c == 0) { return APP_REJ_NOT_STARTED; }

    /* Once latched, a fault dominates: no further completion is accepted. */
    if (c->fault) { return APP_FAULT; }

    /* Order gates: not-started, then stale epoch, then not-connected. A late
     * sample carrying a dead connection's epoch is reported as STALE even
     * though the link is also down, so the cause stays attributable. */
    if (!c->started)   { c->samples_rejected++; return APP_REJ_NOT_STARTED; }
    if (req_epoch != c->conn_epoch) { c->samples_rejected++; return APP_REJ_STALE_EPOCH; }
    if (!c->connected) { c->samples_rejected++; return APP_REJ_NOT_CONNECTED; }

    /* Buffer lifetime: never overwrite payload while a send is outstanding.
     * This request is rejected, but the pending flag MUST be cleared: leaving
     * awaiting_sample latched would wedge sampling behind a slow or lost
     * notification (the request would never be re-issued). The next tick, once
     * the buffer is free or the period elapses, re-issues the request. */
    if (c->tx_in_flight) {
        c->awaiting_sample = 0;
        c->samples_rejected++;
        return APP_REJ_TX_IN_FLIGHT;
    }

    /* No request outstanding: duplicate / forged / replayed completion. */
    if (!c->awaiting_sample) { c->samples_rejected++; return APP_REJ_NO_REQUEST; }

    c->awaiting_sample = 0;

    if (err != APP_OK) {
        c->faults++;
        c->retries++;
        if (c->retries > (uint32_t)cfg->max_retries) { c->fault = 1; return APP_FAULT; }
        /* retry is due immediately on the next tick (wrap-safe) */
        c->t_next_sample = now_ms;
        return APP_RETRY;
    }

    /* AD7156: 12-bit result in the UPPER 12 bits; four LSBs are zero. */
    c->last_raw = app_ad7156_to_raw12(reg16);
    c->payload[0] = (uint8_t)(c->last_raw & 0x00FF);
    c->payload[1] = (uint8_t)((c->last_raw >> 8) & 0x000F);
    c->payload_len = 2;
    c->samples++;
    c->sample_pending = 1;
    /* next request exactly one declared period after THIS request */
    c->t_next_sample = c->t_last_sample_ms + cfg->sample_period_ms;
    return APP_ACC;
}

app_res_t app_on_notify_result(app_ctx_t *c, const app_cfg_t *cfg,
                               uint16_t tx_epoch, uint16_t req_id, app_err_t err)
{
    if (c == 0) { return APP_REJ_STALE_EPOCH; }

    /* A late callback from an older connection must not pollute the new one. */
    if (tx_epoch != c->conn_epoch) { c->notify_stale++; return APP_REJ_STALE_EPOCH; }
    if (req_id != c->tx_req_id || !c->tx_in_flight) {
        c->notify_stale++;
        return APP_REJ_BAD_REQUEST_ID;
    }

    c->notify_attempts++;
    c->tx_in_flight = 0;

    /* Keep the queued-tag FIFO consistent when the completion is delivered
     * through this direct identity path instead of app_on_notify_complete().
     * Only the tag whose identity matches is retired. */
    if (c->txq_count > 0 && c->txq_kind[c->txq_head] == APP_TXK_SENSOR &&
        c->txq_epoch[c->txq_head] == tx_epoch && c->txq_req[c->txq_head] == req_id) {
        c->txq_head = (uint8_t)((c->txq_head + 1u) % APP_TXQ_DEPTH);
        c->txq_count--;
    }

    if (err == APP_OK) {
        c->notifications++;          /* success counter only on real success */
        c->sample_pending = 0;
        return APP_ACC;
    }

    /* Failure: never increments notifications. */
    c->send_failures++;
    if (err == APP_E_BUSBUSY) {      /* link queue full: requeue for retry */
        return APP_RETRY;
    }
    if (err == APP_E_EMPTY) {
        return APP_REJ_EMPTY;
    }
    if (c->send_failures > (uint32_t)cfg->max_retries) { c->fault = 1; return APP_FAULT; }
    return APP_RETRY;
}

app_res_t app_on_notify_complete(app_ctx_t *c, const app_cfg_t *cfg,
                                 uint16_t src_conn_handle,
                                 uint16_t live_conn_handle, app_err_t err)
{
    uint8_t  kind = 0;
    uint16_t epoch = 0, req_id = 0;

    if (c == 0) { return APP_REJ_STALE_EPOCH; }

    /* A completion belongs to the connection it arrived on. A completion from
     * a foreign (different or already-dead) link is attributed as stale and
     * retires NOTHING; only the live connection may advance its own send. */
    if (src_conn_handle != live_conn_handle || !c->connected) {
        c->notify_stale++;
        return APP_REJ_STALE_EPOCH;
    }

    if (!txq_pop(c, &kind, &epoch, &req_id)) {
        /* completion with nothing queued: attribute and ignore */
        c->notify_stale++;
        return APP_REJ_BAD_REQUEST_ID;
    }
    if (kind == APP_TXK_OTHER) {
        /* UART echo traffic: must not touch the sensor counters */
        return APP_ACC;
    }
    /* sensor send: validate against the identity captured at queue time */
    return app_on_notify_result(c, cfg, epoch, req_id, err);
}

void app_note_other_send(app_ctx_t *c)
{
    if (c == 0) { return; }
    txq_push(c, APP_TXK_OTHER, 0, 0);
}

const uint8_t *app_payload(const app_ctx_t *c) { return c ? c->payload : 0; }
uint8_t app_payload_len(const app_ctx_t *c) { return c ? c->payload_len : 0; }
