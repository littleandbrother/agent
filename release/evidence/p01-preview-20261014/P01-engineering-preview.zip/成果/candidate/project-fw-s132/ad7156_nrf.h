/* ad7156_nrf.h - AD7156 capacitance-to-digital converter driver on the
 * official Nordic nrf_drv_twi (TWIM) master.
 *
 * Register semantics taken from the vendor driver in apparatus-reference
 * (Analog Devices AD7156 no-OS driver) and the vendor datasheet:
 *   - slave address 0x48 (7-bit)
 *   - STATUS 0x00: RDY1=bit0, RDY2=bit1 (ACTIVE LOW: 0 == conversion
 *     finished / data valid, 1 == busy; a data-register read clears it)
 *   - CH1 data 0x01(high)/0x02(low); CH2 data 0x03(high)/0x04(low)
 *   - 12-bit result occupies the UPPER 12 bits of the 16-bit register pair;
 *     the four LSBs are zero. High byte precedes low byte on the bus.
 *   - CHIP_ID 0x17 reads 0x88.
 *
 * Pin mapping (SCL/SDA) is a NEW dev-board assumption (PCA10040 Arduino
 * header) because the paper did not publish pins; see main.c and
 * delivery/UNVERIFIED.md. It is NOT the (unpublished) original mapping.
 */
#ifndef AD7156_NRF_H
#define AD7156_NRF_H

#include <stdint.h>
#include "app_policy.h"

#define AD7156_I2C_ADDR     0x48
#define AD7156_REG_STATUS   0x00
#define AD7156_REG_CH1_DATA_H 0x01
#define AD7156_REG_CH1_DATA_L 0x02
#define AD7156_REG_CH2_DATA_H 0x03
#define AD7156_REG_CH2_DATA_L 0x04
#define AD7156_REG_CHIP_ID  0x17
#define AD7156_ID_VALUE     0x88
#define AD7156_STATUS_RDY1  0x01
#define AD7156_STATUS_RDY2  0x02

/* Dev-board pin assumption (PCA10040 Arduino header). */
#define AD7156_TWI_SCL_PIN  27
#define AD7156_TWI_SDA_PIN  26
#define AD7156_RDY_TIMEOUT_MS 200

/* Initialise TWIM0 and verify CHIP_ID. Returns APP_OK or an app_err_t. */
int ad7156_init(void);

/* Read the STATUS register (0x00). */
int ad7156_read_status(uint8_t *status);

/* Burst-read the 16-bit channel data pair; reg16 = (high<<8)|low.
 * channel is 1 (regs 0x01/0x02) or 2 (regs 0x03/0x04). */
int ad7156_read_channel(uint8_t channel, uint16_t *reg16);

/* Poll RDY for the channel up to timeout, then read the data pair.
 * RDY1/RDY2 are active low, so ready == (status & mask) == 0.
 * Returns APP_E_NOTRDY if the conversion never finishes in budget, and
 * preserves APP_E_TIMEOUT vs APP_E_NACK from the bus layer. */
int ad7156_read_sample(uint8_t channel, uint16_t *reg16);

#endif /* AD7156_NRF_H */
