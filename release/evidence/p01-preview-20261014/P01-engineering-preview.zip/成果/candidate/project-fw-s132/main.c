/**
 * P01 nRF52832 + S132 application (ported from the official Nordic
 * ble_app_uart example, SDK 17.1.0 / S132 7.2.0).
 *
 * This is the adapted application: it keeps the official UART-BLE (NUS)
 * scaffolding and sdk_config, and adds a REAL I2C AD7156 acquisition path on
 * the official nrf_drv_twi master plus the async epoch/request-id policy in
 * app_policy.c. There are no UNIMPLEMENTED stubs for radio or I2C.
 *
 * Preserved paper boundaries:
 *   - the MCU is powered/started by a human (manual-start; no auto power-on);
 *   - the BLE connection is initiated by a human (advertising is automatic,
 *     connection is not);
 *   - the author identity conflict (Fig.3 STM32WB15CC vs Methods nrf52832) is
 *     NOT resolved: this is an explicitly declared nRF52832 reconstruction.
 *
 * NOT verified here: real radio range, real I2C device/bus, real power, real
 * GPIO. A successful target build is not hardware evidence.
 */
#include <stdint.h>
#include <string.h>
#include <stdbool.h>
#include "nordic_common.h"
#include "nrf.h"
#include "app_error.h"
#include "ble.h"
#include "ble_hci.h"
#include "ble_srv_common.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "nrf_sdh.h"
#include "nrf_sdh_soc.h"
#include "nrf_sdh_ble.h"
#include "nrf_ble_gatt.h"
#include "nrf_ble_qwr.h"
#include "app_timer.h"
#include "ble_nus.h"
#include "app_uart.h"
#include "app_util_platform.h"
#include "bsp_btn_ble.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_delay.h"

#if defined (UART_PRESENT)
#include "nrf_uart.h"
#endif
#if defined (UARTE_PRESENT)
#include "nrf_uarte.h"
#endif

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "app_policy.h"
#include "ad7156_nrf.h"

#define DEVICE_NAME                     "P01_TENG_NODE"

/* Bounded retry for NUS/UART-queue congestion; avoids unbounded spins inside
 * SoftDevice callbacks. */
#define NUS_ECHO_MAX_RETRY              16
/* UUID type for the Nordic UART Service (vendor specific), required by the
 * official ble_nus example scaffolding. */
#define NUS_SERVICE_UUID_TYPE           BLE_UUID_TYPE_VENDOR_BEGIN
#define APP_ADV_INTERVAL                300
#define APP_ADV_DURATION                0                /* advertise forever */
#define MIN_CONN_INTERVAL               MSEC_TO_UNITS(100, UNIT_1_25_MS)
#define MAX_CONN_INTERVAL               MSEC_TO_UNITS(200, UNIT_1_25_MS)
#define SLAVE_LATENCY                   0
#define CONN_SUP_TIMEOUT                MSEC_TO_UNITS(4000, UNIT_10_MS)
#define FIRST_CONN_PARAMS_UPDATE_DELAY  APP_TIMER_TICKS(5000)
#define NEXT_CONN_PARAMS_UPDATE_DELAY   APP_TIMER_TICKS(30000)
#define MAX_CONN_PARAMS_UPDATE_COUNT    3
#define DEAD_BEEF                       0xDEADBEEF
#define UART_TX_BUF_SIZE                256
#define UART_RX_BUF_SIZE                256
#define APP_BLE_CONN_CFG_TAG            1
#define APP_BLE_OBSERVER_PRIO           3

BLE_NUS_DEF(m_nus, NRF_SDH_BLE_TOTAL_LINK_COUNT);
NRF_BLE_GATT_DEF(m_gatt);
NRF_BLE_QWR_DEF(m_qwr);
BLE_ADVERTISING_DEF(m_advertising);
APP_TIMER_DEF(m_tick_timer_id);

static uint16_t   m_conn_handle          = BLE_CONN_HANDLE_INVALID;
static uint16_t   m_ble_nus_max_data_len = BLE_GATT_ATT_MTU_DEFAULT - 3;
static ble_uuid_t m_adv_uuids[]          = { {BLE_UUID_NUS_SERVICE, NUS_SERVICE_UUID_TYPE} };

/* --- application core ------------------------------------------------- */
static app_ctx_t  m_app;
static const app_cfg_t m_cfg = {
    .sample_period_ms = 5000,
    .adv_period_ms    = 5000,
    .conn_param_period_ms = 3000,
    .cold_start_mv    = 4000,
    .i2c_addr         = AD7156_I2C_ADDR,
    .max_retries      = 3,
    .sample_channel   = 2,
    .sensor_ready_bit = AD7156_STATUS_RDY2
};

/* 1 kHz timebase driven by an app_timer (official timer module). */
static volatile uint32_t m_ms = 0;

static void app_exec_action(app_act_t a);

/**@brief 1 ms application timebase. */
static void tick_timeout_handler(void *p_context)
{
    (void)p_context;
    m_ms++;
}

void assert_nrf_callback(uint16_t line_num, const uint8_t *p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

static void timers_init(void)
{
    ret_code_t err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    /* real timebase */
    err_code = app_timer_create(&m_tick_timer_id, APP_TIMER_MODE_REPEATED, tick_timeout_handler);
    APP_ERROR_CHECK(err_code);
    err_code = app_timer_start(m_tick_timer_id, APP_TIMER_TICKS(1), NULL);
    APP_ERROR_CHECK(err_code);
}

static void gap_params_init(void)
{
    uint32_t                err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);
    err_code = sd_ble_gap_device_name_set(&sec_mode, (const uint8_t *)DEVICE_NAME, strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));
    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;
    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);
}

static void nrf_qwr_error_handler(uint32_t nrf_error) { APP_ERROR_HANDLER(nrf_error); }

static void nus_data_handler(ble_nus_evt_t *p_evt)
{
    if (p_evt->type == BLE_NUS_EVT_RX_DATA) {
        uint32_t err_code;
        for (uint32_t i = 0; i < p_evt->params.rx_data.length; i++) {
            uint16_t tries = 0;
            do {
                err_code = app_uart_put(p_evt->params.rx_data.p_data[i]);
                if ((err_code != NRF_SUCCESS) && (err_code != NRF_ERROR_BUSY)) {
                    APP_ERROR_CHECK(err_code);
                }
                tries++;
            } while ((err_code == NRF_ERROR_BUSY) && (tries < NUS_ECHO_MAX_RETRY));
        }
        if (p_evt->params.rx_data.length > 0 &&
            p_evt->params.rx_data.p_data[p_evt->params.rx_data.length - 1] == '\r') {
            uint16_t tries = 0;
            while ((app_uart_put('\n') == NRF_ERROR_BUSY) && (tries < NUS_ECHO_MAX_RETRY)) { tries++; }
        }
    }
}

static void services_init(void)
{
    uint32_t           err_code;
    ble_nus_init_t     nus_init;
    nrf_ble_qwr_init_t qwr_init = {0};

    qwr_init.error_handler = nrf_qwr_error_handler;
    err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
    APP_ERROR_CHECK(err_code);

    memset(&nus_init, 0, sizeof(nus_init));
    nus_init.data_handler = nus_data_handler;
    err_code = ble_nus_init(&m_nus, &nus_init);
    APP_ERROR_CHECK(err_code);
}

static void on_conn_params_evt(ble_conn_params_evt_t *p_evt)
{
    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED) {
        uint32_t err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}

static void conn_params_error_handler(uint32_t nrf_error) { APP_ERROR_HANDLER(nrf_error); }

static void conn_params_init(void)
{
    uint32_t               err_code;
    ble_conn_params_init_t cp_init;
    memset(&cp_init, 0, sizeof(cp_init));
    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;
    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}

static void sleep_mode_enter(void)
{
    uint32_t err_code = bsp_indication_set(BSP_INDICATE_IDLE);
    APP_ERROR_CHECK(err_code);
    err_code = bsp_btn_ble_sleep_mode_prepare();
    APP_ERROR_CHECK(err_code);
    err_code = sd_power_system_off();
    APP_ERROR_CHECK(err_code);
}

static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
    uint32_t err_code;
    switch (ble_adv_evt) {
        case BLE_ADV_EVT_FAST:
            err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
            APP_ERROR_CHECK(err_code);
            break;
        case BLE_ADV_EVT_IDLE:
            sleep_mode_enter();
            break;
        default:
            break;
    }
}

static void ble_evt_handler(ble_evt_t const *p_ble_evt, void *p_context)
{
    uint32_t err_code;
    (void)p_context;

    switch (p_ble_evt->header.evt_id) {
        case BLE_GAP_EVT_CONNECTED:
            NRF_LOG_INFO("Connected");
            err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
            APP_ERROR_CHECK(err_code);
            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
            err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, m_conn_handle);
            APP_ERROR_CHECK(err_code);
            /* human-initiated connection: bind a new epoch */
            (void)app_on_connected(&m_app, &m_cfg, m_ms);
            break;

        case BLE_GAP_EVT_DISCONNECTED:
            NRF_LOG_INFO("Disconnected");
            m_conn_handle = BLE_CONN_HANDLE_INVALID;
            /* invalidate every in-flight sample/notify (late-callback guard) */
            (void)app_on_disconnected(&m_app, &m_cfg, m_ms);
            break;

        case BLE_GATTS_EVT_HVN_TX_COMPLETE:
        {
            /* A completion callback carries NO send identity from the
             * SoftDevice. The decision uses BOTH the tag latched when the
             * payload was QUEUED (app_on_notify_complete pops that tag, never
             * the live m_app.tx_epoch / m_app.tx_req_id) AND the connection the
             * event actually arrived on: a completion from a foreign/dead
             * conn_handle can never retire THIS connection's outstanding send.
             * One event may report `count` completed notifications, so every
             * one of them is consumed. */
            uint16_t src = p_ble_evt->evt.gatts_evt.conn_handle;
            uint16_t n   = p_ble_evt->evt.gatts_evt.params.hvn_tx_complete.count;
            for (uint16_t k = 0; k < n; k++) {
                (void)app_on_notify_complete(&m_app, &m_cfg, src, m_conn_handle, APP_OK);
            }
        } break;

        case BLE_GAP_EVT_PHY_UPDATE_REQUEST:
        {
            ble_gap_phys_t const phys = { .rx_phys = BLE_GAP_PHY_AUTO, .tx_phys = BLE_GAP_PHY_AUTO };
            err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
            APP_ERROR_CHECK(err_code);
        } break;

        case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
            err_code = sd_ble_gap_sec_params_reply(m_conn_handle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTS_EVT_SYS_ATTR_MISSING:
            err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTC_EVT_TIMEOUT:
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GATTS_EVT_TIMEOUT:
            err_code = sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle,
                                             BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            APP_ERROR_CHECK(err_code);
            break;

        default:
            break;
    }
}

static void ble_stack_init(void)
{
    ret_code_t err_code;
    err_code = nrf_sdh_enable_request();
    APP_ERROR_CHECK(err_code);

    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);
    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}

void gatt_evt_handler(nrf_ble_gatt_t *p_gatt, nrf_ble_gatt_evt_t const *p_evt)
{
    if ((m_conn_handle == p_evt->conn_handle) && (p_evt->evt_id == NRF_BLE_GATT_EVT_ATT_MTU_UPDATED)) {
        m_ble_nus_max_data_len = p_evt->params.att_mtu_effective - 3;
    }
    (void)p_gatt;
}

void gatt_init(void)
{
    ret_code_t err_code = nrf_ble_gatt_init(&m_gatt, gatt_evt_handler);
    APP_ERROR_CHECK(err_code);
    err_code = nrf_ble_gatt_att_mtu_periph_set(&m_gatt, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
    APP_ERROR_CHECK(err_code);
}

void bsp_event_handler(bsp_event_t event)
{
    uint32_t err_code;
    switch (event) {
        case BSP_EVENT_SLEEP:
            sleep_mode_enter();
            break;
        case BSP_EVENT_DISCONNECT:
            err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            if (err_code != NRF_ERROR_INVALID_STATE) { APP_ERROR_CHECK(err_code); }
            break;
        case BSP_EVENT_WHITELIST_OFF:
            if (m_conn_handle == BLE_CONN_HANDLE_INVALID) {
                err_code = ble_advertising_restart_without_whitelist(&m_advertising);
                if (err_code != NRF_ERROR_INVALID_STATE) { APP_ERROR_CHECK(err_code); }
            }
            break;
        default:
            break;
    }
}

void uart_event_handle(app_uart_evt_t *p_event)
{
    static uint8_t data_array[256];
    static uint8_t index = 0;
    uint32_t       err_code;

    switch (p_event->evt_type) {
        case APP_UART_DATA_READY:
            UNUSED_VARIABLE(app_uart_get(&data_array[index]));
            index++;
            if ((data_array[index - 1] == '\n') || (data_array[index - 1] == '\r') ||
                (index >= m_ble_nus_max_data_len)) {
                if (index > 1) {
                    uint16_t tries = 0;
                    do {
                        uint16_t length = (uint16_t)index;
                        err_code = ble_nus_data_send(&m_nus, data_array, &length, m_conn_handle);
                        if ((err_code != NRF_ERROR_INVALID_STATE) &&
                            (err_code != NRF_ERROR_RESOURCES) &&
                            (err_code != NRF_ERROR_NOT_FOUND)) {
                            APP_ERROR_CHECK(err_code);
                        }
                        tries++;   /* bounded wait: never spin forever in a callback */
                    } while ((err_code == NRF_ERROR_RESOURCES) && (tries < NUS_ECHO_MAX_RETRY));
                    if (err_code == NRF_SUCCESS) {
                        /* UART echo uses the same NUS TX characteristic but is
                         * tagged OTHER, so its completion cannot complete or
                         * miscount a sensor notification. */
                        app_note_other_send(&m_app);
                    }
                }
                index = 0;
            }
            break;
        case APP_UART_COMMUNICATION_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_communication);
            break;
        case APP_UART_FIFO_ERROR:
            APP_ERROR_HANDLER(p_event->data.error_code);
            break;
        default:
            break;
    }
}

static void uart_init(void)
{
    uint32_t err_code;
    app_uart_comm_params_t const comm_params = {
        .rx_pin_no    = RX_PIN_NUMBER,
        .tx_pin_no    = TX_PIN_NUMBER,
        .rts_pin_no   = RTS_PIN_NUMBER,
        .cts_pin_no   = CTS_PIN_NUMBER,
        .flow_control = APP_UART_FLOW_CONTROL_DISABLED,
        .use_parity   = false,
#if defined (UART_PRESENT)
        .baud_rate    = NRF_UART_BAUDRATE_115200
#else
        .baud_rate    = NRF_UARTE_BAUDRATE_115200
#endif
    };

    APP_UART_FIFO_INIT(&comm_params, UART_RX_BUF_SIZE, UART_TX_BUF_SIZE,
                       uart_event_handle, APP_IRQ_PRIORITY_LOWEST, err_code);
    APP_ERROR_CHECK(err_code);
}

static void advertising_init(void)
{
    uint32_t               err_code;
    ble_advertising_init_t init;
    memset(&init, 0, sizeof(init));
    init.advdata.name_type          = BLE_ADVDATA_FULL_NAME;
    init.advdata.include_appearance = false;
    init.advdata.flags              = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;
    init.srdata.uuids_complete.uuid_cnt = sizeof(m_adv_uuids) / sizeof(m_adv_uuids[0]);
    init.srdata.uuids_complete.p_uuids  = m_adv_uuids;
    init.config.ble_adv_fast_enabled  = true;
    init.config.ble_adv_fast_interval = APP_ADV_INTERVAL;
    init.config.ble_adv_fast_timeout  = APP_ADV_DURATION;
    init.evt_handler = on_adv_evt;
    err_code = ble_advertising_init(&m_advertising, &init);
    APP_ERROR_CHECK(err_code);
    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);
}

static void buttons_leds_init(bool *p_erase_bonds)
{
    bsp_event_t startup_event;
    uint32_t err_code = bsp_init(BSP_INIT_LEDS | BSP_INIT_BUTTONS, bsp_event_handler);
    APP_ERROR_CHECK(err_code);
    err_code = bsp_btn_ble_init(NULL, &startup_event);
    APP_ERROR_CHECK(err_code);
    *p_erase_bonds = (startup_event == BSP_EVENT_CLEAR_BONDING_DATA);
}

static void log_init(void)
{
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);
    NRF_LOG_DEFAULT_BACKENDS_INIT();
}

static void power_management_init(void)
{
    ret_code_t err_code = nrf_pwr_mgmt_init();
    APP_ERROR_CHECK(err_code);
}

static void idle_state_handle(void)
{
    if (NRF_LOG_PROCESS() == false) {
        nrf_pwr_mgmt_run();
    }
}

static void advertising_start(void)
{
    uint32_t err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
    APP_ERROR_CHECK(err_code);
}

/**@brief Execute one application action (drain loop in main). */
static void app_exec_action(app_act_t a)
{
    switch (a) {
        case APP_ACT_START_ADV:
            advertising_start();
            break;

        case APP_ACT_START_SAMPLE: {
            uint16_t reg16 = 0;
            int err = ad7156_read_sample(m_cfg.sample_channel, &reg16);
            app_err_t e = (err == APP_OK) ? APP_OK : (app_err_t)err;
            (void)app_on_sample_result(&m_app, &m_cfg, m_app.req_epoch, e, reg16, m_ms);
        } break;

        case APP_ACT_NOTIFY: {
            uint16_t len = app_payload_len(&m_app);
            uint8_t  buf[2];
            memcpy(buf, app_payload(&m_app), len);
            uint32_t rc = ble_nus_data_send(&m_nus, buf, &len, m_conn_handle);
            if (rc == NRF_ERROR_RESOURCES) {
                /* consume the tag pushed for this attempt; not a delivery */
                (void)app_on_notify_complete(&m_app, &m_cfg, m_conn_handle, m_conn_handle, APP_E_BUSBUSY);
            } else if (rc != NRF_SUCCESS) {
                (void)app_on_notify_complete(&m_app, &m_cfg, m_conn_handle, m_conn_handle, APP_E_NACK);
            }
            /* NRF_SUCCESS: completion is signalled by BLE_GATTS_EVT_HVN_TX_COMPLETE */
        } break;

        default:
            break;
    }
}

int main(void)
{
    bool erase_bonds;

    uart_init();
    log_init();
    timers_init();
    buttons_leds_init(&erase_bonds);
    if (erase_bonds) { NRF_LOG_INFO("Bonds erased!"); }
    power_management_init();
    ble_stack_init();
    gap_params_init();
    gatt_init();
    services_init();
    advertising_init();
    conn_params_init();

    app_init(&m_app, &m_cfg);

    /* Real I2C bring-up + chip-id check (reports a typed error, no stub). */
    {
        int i2c_err = ad7156_init();
        if (i2c_err != APP_OK) {
            NRF_LOG_WARNING("AD7156 init failed: %d", i2c_err);
        }
    }

    /* Storage-rail observation. The value below is an ASSUMPTION: the paper's
     * TPS3840 cold-start gate is already asserted at manual power-on. Not an
     * ADC measurement. */
    (void)app_on_rail(&m_app, &m_cfg, 4140);

    /* Paper-preserved manual boundary: the MCU was powered on by a human.
     * The BLE *connection* is still human-initiated from the peer. */
    (void)app_on_manual_start(&m_app, &m_cfg, m_ms);

    advertising_start();

    for (;;) {
        /* low-power wait for events (WFE) instead of a busy loop */
        idle_state_handle();

        /* drain the policy actions produced by timers/BLE events */
        for (int guard = 0; guard < 4; guard++) {
            app_act_t a = app_tick(&m_app, &m_cfg, m_ms);
            if (a == APP_ACT_NONE) { break; }
            app_exec_action(a);
        }
    }
}
