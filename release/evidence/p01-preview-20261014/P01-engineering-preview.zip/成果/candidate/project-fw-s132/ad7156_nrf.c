/* ad7156_nrf.c - AD7156 driver bound to the official nrf_drv_twi/TWIM master.
 *
 * Real I2C transactions with explicit timeout and failure handling. No
 * unimplemented stubs: every function performs an actual TWI transfer and
 * reports NACK/timeout distinctly. Not hardware-qualified (no real device or
 * bus has been exercised); see delivery/UNVERIFIED.md.
 */
#include "ad7156_nrf.h"

#include <stddef.h>
#include <stdint.h>
#include "nrf_drv_twi.h"
#include "nrf_delay.h"
#include "app_error.h"
#include "app_util_platform.h"

static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(0);

static volatile uint8_t  m_xfer_done;
static volatile uint8_t  m_xfer_err;

static const nrf_drv_twi_config_t m_twi_cfg = {
    .scl                = AD7156_TWI_SCL_PIN,
    .sda                = AD7156_TWI_SDA_PIN,
    .frequency          = NRF_DRV_TWI_FREQ_100K,
    .interrupt_priority = APP_IRQ_PRIORITY_LOWEST,
    .clear_bus_init     = false,
    .hold_bus_uninit    = false
};

static void twi_evt_handler(nrf_drv_twi_evt_t const *p_event, void *p_context)
{
    (void)p_context;
    if (p_event->type == NRF_DRV_TWI_EVT_DONE) {
        m_xfer_err = 0;
    } else {
        m_xfer_err = 1;
    }
    m_xfer_done = 1;
}

static int twi_wait(void)
{
    uint32_t waited = 0;
    while (!m_xfer_done && waited < AD7156_RDY_TIMEOUT_MS) {
        nrf_delay_ms(1);
        waited++;
    }
    if (!m_xfer_done)      { return APP_E_TIMEOUT; }
    if (m_xfer_err)        { return APP_E_NACK; }
    return APP_OK;
}

static int twi_read_regs(uint8_t reg, uint8_t *out, uint8_t len)
{
    ret_code_t rc;
    m_xfer_done = 0; m_xfer_err = 0;
    rc = nrf_drv_twi_tx(&m_twi, AD7156_I2C_ADDR, &reg, 1, true); /* no stop */
    if (rc != NRF_SUCCESS) { return APP_E_NACK; }
    if (twi_wait() != APP_OK) { return m_xfer_done ? APP_E_NACK : APP_E_TIMEOUT; }

    m_xfer_done = 0; m_xfer_err = 0;
    rc = nrf_drv_twi_rx(&m_twi, AD7156_I2C_ADDR, out, len);
    if (rc != NRF_SUCCESS) { return APP_E_NACK; }
    return twi_wait();
}

int ad7156_init(void)
{
    ret_code_t rc;
    uint8_t id = 0;
    int err;

    rc = nrf_drv_twi_init(&m_twi, &m_twi_cfg, twi_evt_handler, NULL);
    if (rc != NRF_SUCCESS) { return APP_E_NACK; }
    nrf_drv_twi_enable(&m_twi);

    err = twi_read_regs(AD7156_REG_CHIP_ID, &id, 1);
    if (err != APP_OK) { return err; }
    if (id != AD7156_ID_VALUE) { return APP_E_NOTRDY; }
    return APP_OK;
}

int ad7156_read_status(uint8_t *status)
{
    if (status == NULL) { return APP_E_NACK; }
    return twi_read_regs(AD7156_REG_STATUS, status, 1);
}

int ad7156_read_channel(uint8_t channel, uint16_t *reg16)
{
    uint8_t base, rx[2];
    int err;
    if (reg16 == NULL) { return APP_E_NACK; }
    if (channel == 1)      { base = AD7156_REG_CH1_DATA_H; }
    else if (channel == 2) { base = AD7156_REG_CH2_DATA_H; }
    else                   { return APP_E_NACK; }

    err = twi_read_regs(base, rx, 2);   /* high byte first, then low byte */
    if (err != APP_OK) { return err; }
    *reg16 = (uint16_t)(((uint16_t)rx[0] << 8) | rx[1]);
    return APP_OK;
}

int ad7156_read_sample(uint8_t channel, uint16_t *reg16)
{
    uint8_t  mask;
    uint32_t waited = 0;

    if (channel == 1)      { mask = AD7156_STATUS_RDY1; }
    else if (channel == 2) { mask = AD7156_STATUS_RDY2; }
    else                   { return APP_E_NACK; }

    while (waited < AD7156_RDY_TIMEOUT_MS) {
        uint8_t status = 0;
        int err = ad7156_read_status(&status);
        /* Bus timeout and NACK must keep their own identity; only a real
         * completed read is allowed to fall through to the ready test. */
        if (err != APP_OK) { return err; }
        /* RDY1/RDY2 are ACTIVE LOW (datasheet p16): 0 == conversion finished
         * and data register valid; 1 == conversion in progress / busy. */
        if ((status & mask) == 0) {
            return ad7156_read_channel(channel, reg16);
        }
        nrf_delay_ms(1);
        waited++;
    }
    return APP_E_NOTRDY;   /* conversion did not finish within the RDY budget */
}
