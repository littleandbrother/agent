/* app_policy.h - P01 seismic/TENG node application core (interface + state machine).
 *
 * Target-independent C. Compiled BOTH by the host functional-negative test
 * (host-test/host_test.c) and by the nRF52832 / S132 target project
 * (project-fw-s132/main.c). The same core is used so that the host rejection
 * matrix and the target build exercise identical logic.
 *
 * Boundary: this file makes NO claim about real I2C, radio, GPIO or power.
 * It is pure policy over events; the target binds real drivers in main.c.
 */
#ifndef APP_POLICY_H
#define APP_POLICY_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------- error taxonomy ------------------------- */
typedef enum {
    APP_OK          = 0,   /* operation completed                              */
    APP_E_NACK      = 1,   /* I2C/notify NACK                                  */
    APP_E_TIMEOUT   = 2,   /* RDY / send timeout                               */
    APP_E_NOTRDY    = 3,   /* AD7156 data not ready (RDY deasserted)           */
    APP_E_BUSBUSY   = 4,   /* link/queue full -> retry, never counted as sent  */
    APP_E_EMPTY     = 5,   /* empty payload                                    */
    APP_E_UNIMPLEMENTED = 6
} app_err_t;

/* ------------------------- actions ------------------------- */
typedef enum {
    APP_ACT_NONE = 0,
    APP_ACT_START_ADV,
    APP_ACT_START_SAMPLE,   /* issue an I2C read for the bound epoch          */
    APP_ACT_NOTIFY          /* send the pending payload for the bound epoch   */
} app_act_t;

/* ------------------------- decision results -------------------------
 * Distinct reject reasons so a negative case can be attributed, not merely
 * observed to "not count". */
typedef enum {
    APP_ACC = 0,
    APP_REJ_NOT_STARTED,
    APP_REJ_NOT_CONNECTED,
    APP_REJ_STALE_EPOCH,
    APP_REJ_BAD_REQUEST_ID,
    APP_REJ_EMPTY,
    APP_REJ_TX_IN_FLIGHT,
    APP_RETRY,
    APP_FAULT,
    APP_REJ_NO_REQUEST      /* completion with no outstanding sample request */
} app_res_t;

/* Kind of queued NUS transmission. Only SENSOR transmissions affect the
 * sensor notification counters; UART echo traffic is tagged OTHER so an echo
 * completion can never complete a sensor send. */
typedef enum {
    APP_TXK_SENSOR = 1,
    APP_TXK_OTHER  = 2
} app_tx_kind_t;

#define APP_TXQ_DEPTH 8

/* ------------------------- configuration ------------------------- */
typedef struct {
    uint32_t sample_period_ms;    /* 5000 ms sensor cadence                  */
    uint32_t adv_period_ms;       /* advertising duty                        */
    uint32_t conn_param_period_ms;
    uint32_t cold_start_mv;       /* storage rail cold-start gate (4000 mV)  */
    uint16_t i2c_addr;            /* AD7156 0x48                             */
    uint8_t  max_retries;
    uint8_t  sample_channel;      /* AD7156 channel 1 or 2                   */
    uint8_t  sensor_ready_bit;    /* STATUS bit (RDY1=0x01 / RDY2=0x02)      */
} app_cfg_t;

/* ------------------------- context ------------------------- */
typedef struct {
    /* manual start / connection gates */
    uint8_t  started;             /* set by the human manual-start action    */
    uint8_t  connected;           /* set on human-initiated BLE connection   */
    uint8_t  rail_ok;             /* storage rail >= cold_start              */
    uint8_t  fault;               /* latched after retries exceeded          */
    uint8_t  awaiting_sample;     /* sample request outstanding              */
    uint8_t  sample_pending;      /* sample obtained, not yet delivered      */
    uint8_t  tx_in_flight;        /* notify outstanding (buffer lifetime)    */

    /* epoch / request id binding */
    uint16_t conn_epoch;          /* bumped on every connect/disconnect      */
    uint16_t req_epoch;           /* epoch bound to the outstanding sample   */
    uint16_t tx_epoch;            /* epoch bound to the outstanding notify   */
    uint16_t tx_req_id;           /* request id bound to outstanding notify  */
    uint16_t next_req_id;

    /* payload (2-byte little-endian 12-bit raw) */
    uint16_t last_raw;            /* last valid 12-bit raw                   */
    uint8_t  payload[2];
    uint8_t  payload_len;

    uint32_t t_next_sample;       /* earliest time the next sample is due     */
    uint32_t t_last_sample_ms;    /* time the last sample quest was issued   */
    uint32_t t_next_adv;

    /* FIFO of queued NUS send tags. The identity (epoch, request id) is
     * captured when a payload is queued, NOT read back at completion time,
     * so a late callback cannot impersonate the current connection's send. */
    uint16_t txq_epoch[APP_TXQ_DEPTH];
    uint16_t txq_req[APP_TXQ_DEPTH];
    uint8_t  txq_kind[APP_TXQ_DEPTH];
    uint8_t  txq_head;
    uint8_t  txq_tail;
    uint8_t  txq_count;

    /* counters */
    uint32_t samples;             /* accepted samples                        */
    uint32_t samples_rejected;    /* rejected sample results                 */
    uint32_t notifications;       /* SUCCESSFUL deliveries only              */
    uint32_t notify_attempts;     /* accepted send attempts                  */
    uint32_t notify_stale;        /* late/foreign callbacks ignored          */
    uint32_t send_failures;
    uint32_t retries;
    uint32_t faults;
} app_ctx_t;

/* ------------------------- API ------------------------- */
void      app_init(app_ctx_t *c, const app_cfg_t *cfg);

/* storage rail observation (0 mV .. ). Below cold-start forces idle. */
app_res_t app_on_rail(app_ctx_t *c, const app_cfg_t *cfg, uint32_t rail_mv);

/* human manual start (paper-preserved boundary: MCU is powered/started by hand) */
app_res_t app_on_manual_start(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms);

/* human-initiated BLE connection / disconnect */
app_res_t app_on_connected(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms);
app_res_t app_on_disconnected(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms);

/* periodic driver: returns the next action, consuming it (never repeats) */
app_act_t app_tick(app_ctx_t *c, const app_cfg_t *cfg, uint32_t now_ms);

/* async sample result; req_epoch must equal the epoch at request time */
app_res_t app_on_sample_result(app_ctx_t *c, const app_cfg_t *cfg,
                               uint16_t req_epoch, app_err_t err,
                               uint16_t reg16, uint32_t now_ms);

/* async notify completion; must carry the epoch + request id of the send */
app_res_t app_on_notify_result(app_ctx_t *c, const app_cfg_t *cfg,
                               uint16_t tx_epoch, uint16_t req_id, app_err_t err);

/* Resolve the OLDEST queued NUS completion against the identity captured when
 * that payload was queued (never against the live m_app.tx_* fields). Used by
 * the BLE event bridge for BLE_GATTS_EVT_HVN_TX_COMPLETE.
 *
 * src_conn_handle is the connection the completion arrived on; live_conn_handle
 * is the currently connected handle. A completion from a foreign/dead link
 * (src != live, or the link is down) must NEVER retire this connection's
 * outstanding send, so it is rejected as stale. The caller loops this `count`
 * times for one HVN event carrying multiple completions. */
app_res_t app_on_notify_complete(app_ctx_t *c, const app_cfg_t *cfg,
                                 uint16_t src_conn_handle,
                                 uint16_t live_conn_handle, app_err_t err);

/* Record a non-sensor (UART echo) NUS transmission so its completion is
 * consumed without touching the sensor counters. */
void      app_note_other_send(app_ctx_t *c);

const uint8_t *app_payload(const app_ctx_t *c);
uint8_t        app_payload_len(const app_ctx_t *c);

/* AD7156 12-bit result is in the UPPER 12 bits of the 16-bit register pair;
 * the four LSBs are zero. */
static inline uint16_t app_ad7156_to_raw12(uint16_t reg16)
{
    return (uint16_t)((reg16 >> 4) & 0x0FFF);
}

#ifdef __cplusplus
}
#endif
#endif /* APP_POLICY_H */
