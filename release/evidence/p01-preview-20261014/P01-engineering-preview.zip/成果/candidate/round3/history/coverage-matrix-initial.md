# P01 首版数字工程覆盖矩阵（round-3）

状态为**独立验收证据的当前状态**，不是自我判定。门定义来自 `contract.json`（八门）与
任务书的四项独立要求。`check-2e1437a3d49109c5e4fa` 为最近一次独立检查。

| # | 门 | 状态 | 支撑证据（本轮/沿用） | 未满足项 |
|---|----|------|------------------------|----------|
| 1 | `source_domain` 真实源模型适用条件 | UNEVALUABLE | 论文源域：接触分离、标称 1 cm 行程、开路峰值 ~720 V（`docs/BOM-interfaces.md`）；链式 TENG 等效采用 361.5 V 峰值/5 Hz/1 nF（`project-chain/interface-params.json` 声明假设） | 缺少论文源参数的可定位原始正文映射；链式等效与论文源之间的标定未建立 |
| 2 | `schematic_bom_pins` 原理图/BOM/器件引脚 | UNEVALUABLE | 原生原理图回读 `public-interface-facts-20261014/schematic-readback.json`、`native-project/…/P1.esch2`；BOM 见 `docs/BOM-interfaces.md` | 引脚↔网络↔封装逐项对账表未完成；GaN 600 V 降额门仍未关闭 |
| 3 | `pcb_connectivity_drc` 原生 PCB 连接/布局/DRC | **FAIL** | 保存→重载后原生 DRC `eda-a2d9dc1fee2d2338212c`：`passed=false`，**52** 项 Clearance Error（SMD Pad-Track 5、TH Pad-Track 17、Hole-Track 12、Region-SMD Pad 7、Region-Track 2、Region-Slot 8、Hole-Hole 1）与 **50** 项 Connection Error（未布通网络：storage_rail 12、supply_1v8 9、teng_terminal_pos/xtal_hf_b/teng_rect/sece_trigger/sece_secondary/sensor_*/ant_rf/swd_*/mcu_dec2 各 2–3） | 间距违规与未布通网络都未修复；本轮按要求停止布线 |
| 4 | `geometry_fit` 真实板卡与结构装配 | **FAIL** | CAD 原生作业复用 `eng-d6b2ca501db8e7fa`（STEP 实体/尺寸读回）；板框与安装孔工作 `eda-2cdc44644631943db3fe` | 原生器件位置与机械包络/安装点的干涉未消除；无实测装配 |
| 5 | `firmware_event_logic` 固件事件状态反例 | PASS | 目标构建作业复用 `eng-6e2bc184592697d6`（nRF52832-QFAA + S132 7.2.0，HEX/ELF/MAP）；反例运行见 `public-interface-facts-20261014/firmware-events.json` | —（状态自旧版沿用） |
| 6 | `board_firmware_interfaces` 板级引脚/总线/固件接口 | UNEVALUABLE | 固件侧引脚/外设初始化（`project-fw-s132/*`）与 PCB 网络名（`public-interface-facts-20261014/pcb-readback.json`） | 焊盘↔GPIO↔时钟↔中断入口的一一对应证据未完成，这正是第 3 门未布通的同一批网络 |
| 7 | `power_load_chain` 供能—储能—任务完整链 | **FAIL** | 本轮新解 `eng-9d45631d57148be4`：220 µF/4.2 V 声明初态在 100 ms 连接间隔下于 9.20 s 跌破 2.0 V、10.00 s 跌破 1.8 V、16 s 末仅 0.353 V；取能均值 3.9 µA vs 负载 56.2 µA（`round3/chain-revision.md`） | 储能/取能规模或连接间隔参数之一必须改变；取能支路为行为包络，未标定 |
| 8 | `delivery_version` 同版本文件与实际作业绑定 | NOT_CHECKED（待本轮独立复查） | 本目录报告 + 冻结候选 + `delivery/manifest.json` + 3 个原生作业绑定 | 需独立复查端确认同版绑定；旧绑定（含 `firmware_event_logic` 旧证据）因 `STALE_NATIVE_BINDING`/`STALE_REVIEW_INPUT` 被拒，保留为历史 |

## 四项独立要求（不因本轮工作而改变）

| 要求 | 状态 |
|------|------|
| 自动接通 MCU | **未验证**（本任务只做人工接通；人工开关在 t≈0 闭合是声明边界） |
| 零能量冷启动 | **未验证**（初态 4.2 V 由 BF 声明并建账，非自供电建立） |
| 标定气体浓度 | **未验证**（不在本阶段范围） |
| 物理验证 | **NOT_TESTED**（无实测；全部为数字工程证据） |

## 本轮范围外但已知的缺口

- PC 接收程序 `receiver/`（帧解析、BLE 后端、GUI、边界测试）为宿主侧代码证据，未接真实射频。
- 原生 PCB 保存/重载已完成（`eda-33fea4bd540fcc4b3b8b` → `eda-52c052c49b62fa93d2c7`），
  最终制造导出与独立检查由只读检查端准备。
