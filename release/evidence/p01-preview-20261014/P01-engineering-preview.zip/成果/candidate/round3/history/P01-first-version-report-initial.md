# P01 数字工程首版交付报告（round-3, 第一版）

| 项 | 值 |
|----|----|
| 任务 | `task-P01-10bf452e702af71a1acf`（原 owner `pi-chat-b47a35e335bc68d4`，原 contract 未改） |
| 目标（原 contract） | 在选定的名义机械输入和声明初态下，完成积能、人工接通 MCU、建立连接、周期采样和 PC 解码；提交对应数字工程与验证证据 |
| 独立验收 | 八门 = `source_domain, schematic_bom_pins, pcb_connectivity_drc, geometry_fit, firmware_event_logic, board_firmware_interfaces, power_load_chain, delivery_version` |
| 人工边界（冻结） | 人工接通 MCU 开关 `Sman`，`Vman PWL(0 0 1n 1)`，动作能量 0 J（理想开关，不引入未声明辅助能量） |
| 物理验证 | **NOT_TESTED**（本交付全部为数字工程证据） |
| 整机结论 | **未通过**：`full_product_passed=false`，`digital_engineering_status=REPAIR_REQUIRED` |

## 1. 选定的名义机械输入与声明初态

| 参数 | 值 | 来源/条件 |
|------|----|-----------|
| 接触分离行程 `d_max` | 10 mm | 论文实验驱动条件，非设计指定行程（声明） |
| 机械频率 | 5 Hz | `disp(t) = 0.5·d_max·(1−cos 2πft)` |
| TENG 等效开路峰值 | 361.8 V，`C_teng = 1 nF` | 链式接口等效（声明假设，非论文源标定） |
| 整流 | 2 二极管 + 返回路径，`C_bus = 100 nF` | 声明建模选择（非从冻结原理图读出） |
| 取能级 | 行为包络 `I = 5e-5·max(v_rect − v_rail, 0)`，`resolved=false` | 声明假设，5 项未决（见 `interface-params.json`） |
| 储能 | `C_store = 220 µF`，初态 **4.2 V**（uic），`R_leak = 4.2 MΩ` | 220 µF 为表征包络值；440/100 µF 变体未使用 |
| 稳压 | `1.8·min(1, V/4.0)`（冷启动参考 4.0 V） | 声明假设 |
| 时间窗 | 0–16.001 s，t=0 为**人工接通**动作，1 ms 基 | 覆盖 4 次采样/通知事件 |

## 2. 本轮做了什么

1. **链式负载按固件真实无线时序重建**：广播 187.5 ms、连接间隔 100–200 ms（取最坏 100 ms）——
   与 policy 层 5000/3000 ms 的差异被公开记录，固件源码**未修改**。
2. **修掉两个真实模型缺陷**（由作业 `eng-8eaa2b61c4e55606` 的 −48.9 V 非物理解暴露）：
   PWL 被线性插值成斜坡、1.8 V→储能轨折算因子缺失。修正后新解 `eng-9d45631d57148be4`。
3. **复用未变的成功作业**：CAD `eng-d6b2ca501db8e7fa`、S132 固件 `eng-6e2bc184592697d6`。
4. **原生 PCB**：移动 D2 与天线 → 自动布线/短接 → 保存 → 重载文档 → 原生 `pcb drc`（权威回执保存于重载之后）。
5. 本阶段**不 submit、不继续布线、不做第四轮打磨**，等待独立复查。

## 3. 真实结果（含 FAIL / UNEVALUABLE）

| 门 | 状态 | 关键数值/事实 |
|----|------|----------------|
| `power_load_chain` | **FAIL** | 220 µF/4.2 V 在 100 ms 连接间隔下：< 3.0 V @5.00 s，< 2.0 V @9.20 s，< 1.8 V @10.00 s；第 3 次采样/通知（15.3 s）轨压仅 **0.53 V**，末点 **0.353 V**。窗口电荷：负载 899.6 µC vs 取能净注入 **61.9 µC（3.9 µA 均值 vs 需求 56.2 µA）**。轨斜率反推负载 58.2 µA vs 模型 56.5 µA（比值 1.03）——模型自洽，结论是真实短缺 |
| `pcb_connectivity_drc` | **FAIL** | 保存→重载后原生 DRC `eda-a2d9dc1fee2d2338212c`：`passed=false`，**52** Clearance Error（SMD Pad–Track 5、TH Pad–Track 17、Hole–Track 12、Region–SMD Pad 7、Region–Track 2、Region–Slot 8、Hole–Hole 1）+ **50** Connection Error（未布通：storage_rail 12、supply_1v8 9、teng_terminal_pos/xtal_hf_b/teng_rect/sece_trigger/sece_secondary/sensor_*/ant_rf/swd_*/mcu_dec2 各 2–3），**未修复如实保留** |
| `geometry_fit` | **FAIL** | CAD 作业复用（STEP 实体/尺寸读回）；原生器件位置与机械包络/安装点的干涉未消除，无实测装配 |
| `source_domain` | UNEVALUABLE | 缺论文源参数的可定位原始正文映射；链式 TENG 等效未与论文源标定；GaN 600 V 降额门未关闭 |
| `schematic_bom_pins` | UNEVALUABLE | 原生原理图/BOM 回读已有，引脚↔网络↔封装逐项对账未完成 |
| `board_firmware_interfaces` | UNEVALUABLE | 固件侧初始化与 PCB 网络名已有，焊盘↔GPIO↔时钟↔中断入口一一对应证据未完成 |
| `firmware_event_logic` | PASS | 目标构建复用 `eng-6e2bc184592697d6`（nRF52832-QFAA + S132 7.2.0，ELF/HEX/BIN/MAP）+ 反例事件序列 |
| `delivery_version` | NOT_CHECKED | 本报告 + 冻结候选 + 同版清单 + 3 个作业绑定，待独立复查确认 |

## 4. 四项独立要求（仍未验证）

自动接通 MCU、零能量冷启动、标定气体浓度、物理验证 —— 全部**未验证**；本交付不以此自授通过。

## 5. 已知未决/边界（不隐藏）

- 取能支路是行为包络（`resolved=false`）：母线仅比轨压高约 10 mV，"取能≈0"同时依赖该参数与 220 µF 取值；
- 载荷折算 `K = 0.4`、负载电流分类值（boot/advertising/connect/ADC/notify）均为声明；
- t=1e-11 s 首点 `v(mcu_rail)=−1.32 MV` 为开关闭合前的数值启动伪影（下一存储点恢复），**记为待修项**；
- PC 接收程序 `receiver/`（帧、BLE 后端、GUI、边界测试）为宿主侧代码证据，未接真实射频；
- 固件"policy 周期 vs radio 真实周期"的差异仍未在源码层对齐（本轮只建模真实值）。

## 6. 同版绑定

- 冻结候选：见交付 `delivery/manifest.json` 与 `native-report.json`（由 `bf_design prepare_delivery` 生成）；
- 所选原生作业：`eng-d6b2ca501db8e7fa`（CAD，未变复用）、`eng-6e2bc184592697d6`（S132 固件，未变复用）、
  `eng-9d45631d57148be4`（链式 SPICE，本轮新解）；
- 修订与覆盖明细：`round3/chain-revision.md`、`round3/coverage-matrix.md`、`round3/chain-crosscheck.json`；
- 旧阶段文档（`delivery/CURRENT-REVIEW.md`、`delivery/UNVERIFIED.md`）保留为历史。
