#!/usr/bin/env python3
"""P01 round-3 chain load timeline generator (replayable step).

Design decision (Pi, round 3):
  The round-2 cross-domain interface check FAILED two bindings because the
  *policy* periods (app_policy.c cfg: adv_period_ms=5000, conn_param_period_ms=3000)
  differ from the *actual radio* configuration in project-fw-s132/main.c:
      APP_ADV_INTERVAL 300 x 0.625 ms = 187.5 ms
      MIN_CONN_INTERVAL = MSEC_TO_UNITS(100,1.25) -> 100 ms
      MAX_CONN_INTERVAL = MSEC_TO_UNITS(200,1.25) -> 200 ms
      sample_period_ms  = 5000 (MATCHES the policy)
  Round 3 therefore writes the difference into the chain-model parameter layer:
  the load timeline follows the ACTUAL radio configuration (conservative bound:
  the 100 ms minimum connection interval is used, i.e. worst-case keep-alive
  energy). The declared event identity (4x sample+notify, 2-byte payload 5b0a,
  16001 x 1 ms ticks) is unchanged and still comes from the recorded firmware
  event replay.

Sources of each number:
  actual firmware source : project-fw-s132/main.c (sha in the run receipt)
  declared event replay  : public-interface-facts-20261014/firmware-events.json
  declared current values: assumption (no measured current profile exists)

Outputs: project-chain/load-timeline.json , project-chain/chain_joint.cir
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "project-chain")

# ---- actual firmware facts (project-fw-s132/main.c) ----
ADV_PERIOD_MS = 187.5          # APP_ADV_INTERVAL 300 x 0.625 ms
CONN_PERIOD_MS = 100.0         # MIN_CONN_INTERVAL (conservative / worst case)
SAMPLE_PERIOD_MS = 5000        # cfg.sample_period_ms and radio-independent
TICKS = 16001                  # 1 ms base, 16.001 s
T_STOP = 16.001

# ---- declared event times (recorded firmware event replay) ----
SAMPLE_EVENTS_S = [0.300, 5.300, 10.300, 15.300]
PEER_CONNECT_S = 0.300         # declared manual peer action (human initiates)
FIRST_ADV_S = 0.010            # first advertising event after boot/init

# ---- declared current amplitudes (assumption, origin=assumption) ----
I_IDLE_A = 4e-6        # system idle
I_CDC_IDLE_A = 2e-6    # AD7156 conversion idle
I_BOOT_A = 2.6e-3
BOOT_MS = 6
I_ADV_A = 3.0e-3
ADV_MS = 1.0
I_CONN_A = 5.0e-3
CONN_MS = 2.0
I_CDC_CONV_A = 180e-6
CDC_CONV_MS = 12.0
I_NOTIFY_A = 6.0e-3
NOTIFY_MS = 1.0

# referral of the 1.8 V-domain current to the storage rail
K = (1.8 / 4.2) / 0.85

segs = []
def seg(t0, t1, i, name):
    if t1 > t0:
        segs.append({"name": name, "t0_s": round(t0, 9), "t1_s": round(t1, 9),
                     "current_1v8_a": i, "current_storage_rail_a": i * K})

# boot at the manual admission instant (power-on only; re-connections do not reboot)
seg(0.0, BOOT_MS / 1000.0, I_BOOT_A, "boot %.1fmA (power-on only)" % (I_BOOT_A * 1e3))
# advertising events at the ACTUAL 187.5 ms interval until the peer connects
t = FIRST_ADV_S
while t + ADV_MS / 1000.0 <= PEER_CONNECT_S:
    seg(t, t + ADV_MS / 1000.0, I_ADV_A, "advertising %.1fmA (187.5ms interval)" % (I_ADV_A * 1e3))
    t += ADV_PERIOD_MS / 1000.0
# connected keep-alive at the ACTUAL (minimum) connection interval
t = PEER_CONNECT_S
while t + CONN_MS / 1000.0 <= T_STOP:
    seg(t, t + CONN_MS / 1000.0, I_CONN_A, "connection event %.1fmA" % (I_CONN_A * 1e3))
    t += CONN_PERIOD_MS / 1000.0
# per-sample CDC conversion (before the sample) + 2-byte notify
for ts in SAMPLE_EVENTS_S:
    seg(ts - CDC_CONV_MS / 1000.0, ts, I_CDC_CONV_A, "cdc_convert 180uA")
    seg(ts, ts + NOTIFY_MS / 1000.0, I_NOTIFY_A, "notify %.1fmA 2-byte" % (I_NOTIFY_A * 1e3))

# base idle present over the whole window
parts = [(0.0, T_STOP, I_IDLE_A, "base idle 4uA")] + [(s["t0_s"], s["t1_s"], s["current_1v8_a"], s["name"]) for s in segs]

def curve(t):
    return I_IDLE_A + I_CDC_IDLE_A + sum(p[2] for p in parts if p[0] <= t < p[1])

# breakpoints are distinct and strictly increasing
bps = sorted({0.0, T_STOP} | {p[0] for p in parts} | {p[1] for p in parts})
assert all(bps[i] < bps[i + 1] for i in range(len(bps) - 1))
charge = 0.0
vals = []
for i in range(len(bps) - 1):
    v = curve(0.5 * (bps[i] + bps[i + 1]))
    vals.append(v)
    charge += (bps[i + 1] - bps[i]) * v

# ngspice/LTspice PWL interpolates LINEARLY between consecutive points, so a
# piecewise-constant load must be written as a staircase: at every breakpoint tau
# emit (tau - eps, previous value) and (tau, new value). The 1 us edge makes the
# interpolation error (pulse height x 1 us) negligible.
EPS = 1e-6
pwl = []
for i, v in enumerate(vals):
    tau = bps[i]
    if i > 0:
        assert tau - EPS > pwl[-1][0], (tau, pwl[-1][0])
        pwl.append([round(tau - EPS, 9), vals[i - 1] * K])
    pwl.append([round(tau, 9), v * K])
pwl.append([round(T_STOP, 9), vals[-1] * K])
assert all(pwl[i][0] < pwl[i + 1][0] for i in range(len(pwl) - 1))

doc = {
    "schema_version": "bf-p01-load-timeline-v2",
    "revision_note": "round-3: follows the ACTUAL radio configuration in project-fw-s132/main.c "
                     "(adv 187.5 ms, connection 100 ms worst case, sample 5000 ms) instead of the "
                     "policy-only periods; the policy/radio mismatch is reported, not hidden.",
    "source_events": "public-interface-facts-20261014/firmware-events.json",
    "source_actual_timing": "project-fw-s132/main.c",
    "units": "SI",
    "timebase": {"tick_ms": 1, "ticks": TICKS, "t_start_s": 0.0, "t_stop_s": T_STOP, "edge_guard_s": 1e-6,
                 "pwl_form": "staircase: (tau-1us, previous value) then (tau, new value); ngspice PWL interpolates "
                             "linearly between points, so a flat segment needs its own pair of points"},
    "load_node": "mcu_rail (1.8 V domain) -> referred to storage_rail",
    "referral": {"formula": "I_store = I_1V8*(1.8/4.2)/0.85", "factor": K},
    "actual_radio_timing": {
        "advertising_period_ms": ADV_PERIOD_MS,
        "advertising_period_source": "project-fw-s132/main.c APP_ADV_INTERVAL 300 x 0.625 ms",
        "connection_period_ms_used": CONN_PERIOD_MS,
        "connection_period_range_ms": [100.0, 200.0],
        "connection_period_source": "project-fw-s132/main.c MIN/MAX_CONN_INTERVAL, SLAVE_LATENCY 0",
        "connection_period_choice": "minimum interval = worst-case keep-alive energy (conservative bound)",
        "sample_period_ms": SAMPLE_PERIOD_MS,
        "sample_period_source": "project-fw-s132/main.c cfg.sample_period_ms = 5000",
        "policy_vs_radio_mismatch": {
            "policy_adv_period_ms": 5000,
            "policy_conn_param_period_ms": 3000,
            "policy_source": "project-fw-s132/app_policy.c app_cfg m_cfg",
            "status": "UNRESOLVED — the policy duty-cycle parameters disagree with the radio "
                      "configuration; recorded as an interface finding, firmware NOT modified"
        }
    },
    "events_covered": {
        "sample_and_notify_2byte_s": SAMPLE_EVENTS_S,
        "count": len(SAMPLE_EVENTS_S),
        "payload_hex": "5b0a",
        "decoded_raw12": 2651,
        "peer_connect_s": PEER_CONNECT_S,
        "advertising_events_s": [round(FIRST_ADV_S + k * ADV_PERIOD_MS / 1000.0, 4)
                                 for k in range(int((PEER_CONNECT_S - FIRST_ADV_S) // (ADV_PERIOD_MS / 1000.0)) + 1)
                                 if FIRST_ADV_S + k * ADV_PERIOD_MS / 1000.0 + ADV_MS / 1000.0 <= PEER_CONNECT_S],
        "connection_events_count": int((T_STOP - PEER_CONNECT_S) // (CONN_PERIOD_MS / 1000.0)),
        "cdc_conversions_s": [round(ts - CDC_CONV_MS / 1000.0, 4) for ts in SAMPLE_EVENTS_S]
    },
    "declared_assumptions": {
        "system_idle_a": I_IDLE_A, "cdc_idle_a": I_CDC_IDLE_A, "cdc_convert_a": I_CDC_CONV_A,
        "sample_notify_a": I_NOTIFY_A, "advertising_a": I_ADV_A, "connection_a": I_CONN_A,
        "boot_a": I_BOOT_A, "boot_ms": BOOT_MS, "cdc_convert_ms": CDC_CONV_MS,
        "notify_ms": NOTIFY_MS, "adv_ms": ADV_MS, "conn_ms": CONN_MS,
        "first_advertising_ms": FIRST_ADV_S * 1000,
        "boot_modelled": "once, at the manual admission t=0 (power-on boot); re-connection events do not reboot",
        "reference": "public-interface-facts-20261014/firmware-events.json",
        "origin": "assumption",
        "cdc_idle_policy": "the 2 uA conversion-idle current is declared on from t=0 continuously"
    },
    "segments": segs,
    "pwl_time_value_referred_to_storage_rail_a": pwl,
    "window_charge_1v8_domain_c": charge,
    "window_charge_storage_rail_c": charge * K,
}

json.dump(doc, open(os.path.join(OUT, "load-timeline.json"), "w"), indent=1)

# ---------------- netlist ----------------
def pwl_block(points):
    toks = ["%.9g %.9g" % (t, v) for t, v in points]
    lines, cur = [], ""
    for tk in toks:
        if cur and len(cur) + len(tk) + 1 > 110:
            lines.append(cur)
            cur = "+ " + tk
        else:
            cur = (cur + " " + tk).strip()
    if cur:
        lines.append(cur)
    return "\n".join(lines)

load_pwl = pwl_block(pwl)

net = """* ================================================================
* P01 joint-chain INTERFACE CALIBRATION netlist  (round 3 revision)
* project-chain/chain_joint.cir
* ----------------------------------------------------------------
* Purpose : put the declared nominal mechanical travel, the CS-TENG
*           source, the board power chain and the project-fw-s132
*           firmware event load on ONE strictly increasing timeline,
*           for the power_load_chain / board_firmware_interfaces
*           energy-and-timeline judgement.
* Units   : SI (m, s, V, A, ohm, F, H)
* Round-3 change: the load timeline now follows the ACTUAL radio
*           configuration of project-fw-s132/main.c
*           (APP_ADV_INTERVAL 300 x 0.625 ms = 187.5 ms;
*            MIN/MAX_CONN_INTERVAL = 100 / 200 ms, worst case 100 ms)
*           instead of the policy-only periods 5000 / 3000 ms.
*           The policy-vs-radio mismatch is REPORTED, not hidden, and
*           the firmware source was NOT modified.
* Declared model scope [see project-chain/interface-params.json and
* project-chain/load-timeline.json].
*   - SECE extraction is an AVERAGE ENVELOPE (one-way extraction
*     conductance GSE). The fast SECE switching is NOT resolved.
*   - Rectifier topology, TENG capacitance, bus/storage capacitance,
*     leakage and all load currents are DECLARED ASSUMPTIONS, not
*     datasheet values. Unresolved items are listed in the report.
*   - Decimal separator is a dot; no control block, no external include
*     file, no external library section.
* This file is self-contained.
* ================================================================

.options RELTOL=1e-3 ABSTOL=1e-9 VNTOL=1e-5

* ----------------------------------------------------------------
* 1) declared mechanical interface: contact-separation travel
*    disp = separation node in metres, 0 .. 1 cm, one full
*    separation/contact cycle = 0.2 s (5 Hz). This is the declared
*    nominal mechanical input (1 cm travel, experimental driving
*    condition), NOT a design-specified stroke.
* ----------------------------------------------------------------
Btravel disp 0 V = 0.5*1e-2*(1-COS(6.283185307179586*5*time))

* ----------------------------------------------------------------
* 2) CS-TENG source, driven by the separation node disp.
*    |Voc| is proportional to the separation; the polarity flips when
*    the separation derivative changes sign (smooth sign, eps=1e-6).
* ----------------------------------------------------------------
Bvoc teng_oc 0 V = 361.8*(V(disp)/1e-2)*(SIN(6.283185307179586*5*time)/SQRT(SIN(6.283185307179586*5*time)*SIN(6.283185307179586*5*time)+1e-6))

* TENG series capacitance between the open-circuit node and the
* rectifier AC node
Cteng teng_oc teng_ac 1e-9

* ----------------------------------------------------------------
* 3) rectifier (declared 2-diode with return path) + rectified DC bus
*    D1: teng_ac -> teng_rect   (rectifies the positive swing)
*    D2: 0 -> teng_ac           (returns the negative swing)
* ----------------------------------------------------------------
D1 teng_ac teng_rect DBR
D2 0 teng_ac DBR
.model DBR D(IS=1e-9 N=1.15 RS=1.0 CJO=1e-11 BV=1200 IBV=1e-6)
Cbus teng_rect 0 100e-9

* ----------------------------------------------------------------
* 4) SECE AVERAGE ENVELOPE: one-way extraction from the rectified bus
*    into the storage rail. Current is injected into storage_rail.
*    (fast switching / switch resistance / magnetics NOT resolved)
* ----------------------------------------------------------------
Bsece teng_rect storage_rail I = 5e-5*MAX(V(teng_rect)-V(storage_rail),0)

* ----------------------------------------------------------------
* 5) manual action boundary + storage rail
*    The manual MCU admission switch is the frozen declared human
*    action of this task; it closes at t = 0 of this timeline
*    (manual_switch_close_s = 0.0) and supplies NO energy (ideal
*    switch, Ron = 0.5 ohm). Load is admitted only through it.
* ----------------------------------------------------------------
Vman man_ctl 0 PWL(0 0 1e-9 1)
Sman storage_rail mcu_rail man_ctl 0 SMAN
.model SMAN SW(Ron=0.5 Roff=1e9 Vt=0.5)

* storage rail: declared initial state v(storage_rail) = 4.2 V
Cstore storage_rail 0 220e-6 ic=4.2
Rleak storage_rail 0 4.2e6

* ----------------------------------------------------------------
* 6) declared 1.8 V regulator envelope (operating-range observer).
*    The load current itself is referred to storage_rail below.
* ----------------------------------------------------------------
Bv18 supply_1v8 0 V = 1.8*MIN(1.0,V(storage_rail)/4.0)

* ----------------------------------------------------------------
* 7) firmware event load timeline, referred to the storage rail.
*    Timing: ACTUAL radio configuration of project-fw-s132/main.c
*    (advertising every 187.5 ms; connection every 100 ms = worst
*    case; sample every 5000 ms). Event identity: recorded firmware
*    replay public-interface-facts-20261014/firmware-events.json
*    (4 x sample + 2-byte notify 5b0a at 0.300/5.300/10.300/15.300 s,
*    16001 x 1 ms ticks). Referral I_store = I_1V8*(1.8/4.2)/0.85.
*    PWL time points are strictly increasing (1 us edge).
*    Full machine-readable list: project-chain/load-timeline.json
* ----------------------------------------------------------------
Iload mcu_rail 0 PWL({LOAD})

.tran 100u 16.001 0 100u uic

.end
""".replace("{LOAD}", load_pwl)

open(os.path.join(OUT, "chain_joint.cir"), "w").write(net)
print("pwl points=%d  adv_events=%d  conn_events=%d  charge_store=%.6g C"
      % (len(pwl), len(doc["events_covered"]["advertising_events_s"]),
         doc["events_covered"]["connection_events_count"], doc["window_charge_storage_rail_c"]))
