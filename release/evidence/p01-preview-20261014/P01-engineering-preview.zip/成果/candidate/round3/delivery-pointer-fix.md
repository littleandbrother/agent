# 交付指向修正记录（round-3 元数据核对轮）

- 触发：独立只读回读发现冻结候选 `D-85f03a02…` 指向的 `public-interface-facts-20261014/native-project` 是**上一版 PCB/原工程副本**。
- 事实核对（本文件所有 SHA 均为工作区实测）：
  - 旧副本 `public-interface-facts-20261014/native-project/pcb/PCB1.epcb2` = `5fb5c2a743aa…`（与旧 `public-interface-facts-20261014/PCB1.epcb2` 同哈希）
  - 当前已保存 PCB `public-round3-facts-20261014/native-project/pcb/PCB1.epcb2` = `77d8da54226a6453…`
  - 旧原工程副本 `…eprj3` = `6236aa623c5e…`　→　当前 `…eprj3` = `7e325475627a40c4…`
- 处置原则：**只修交付指向，不改工程**。退出项仅在候选清单中移除，原文件继续留在工作区作历史；本轮 `engineering_source_edits=0`、`solver_runs=0`、`target_builds=0`。

## 封存事实（`public-round3-facts-20261014/FINAL-INDEX.json`，sha256 `5e4cd1e445e568ef…`）

本报告逐字节复核索引声明：索引内 13 个文件全部匹配；7 个门证据文件（`gates[].sha256`）全部匹配。
`public-round3-facts-20261014/` 下另有 4 个未被索引列出但被门/接口复核直接引用的文件
（`schematic-readback.json f1606ccb…`、`pcb-readback.json 2d19f000…`、`PCB1.epcb2 77d8da54…`、`independent-reviews/*.json`、`FINAL-INDEX.json` 自身），
其中前三个的哈希与 `interfaces.json` 的 `native_input_sources` 声明完全一致，故一并进入当前清单。

## 加入当前清单

| 路径 | sha256（前 16） | 角色 |
|------|-----------------|------|
| `public-round3-facts-20261014/FINAL-INDEX.json` | `5e4cd1e445e568ef` | 当前事实封存索引（只读检查端） |
| `public-round3-facts-20261014/native-project/BF-Literature-P01-Native-20261012.eprj3` | `7e325475627a40c4` | 当前原工程 |
| `public-round3-facts-20261014/native-project/pcb/PCB1.epcb2` | `77d8da54226a6453` | 当前 PCB |
| `public-round3-facts-20261014/native-project/sch/Schematic1/P1.esch2` | `7c88660f33e0c31e` | 当前原理图 |
| `public-round3-facts-20261014/native-project/sch/Schematic1/Schematic1.ecfg` | `f1024361204d7112` | 当前原理图配置 |
| `public-round3-facts-20261014/native-project/eprj3-intro.md` | `aa51d38bb0c3cc0f` | 原工程说明 |
| `public-round3-facts-20261014/native-readback.json` | `1b13049d258f403b` | 原生命令回读 + 原生文件哈希 + `engineering_edits=0/solver_runs=0` |
| `public-round3-facts-20261014/schematic-readback.json` | `f1606ccb914b34f0` | 原理图回读（172 引脚/网络） |
| `public-round3-facts-20261014/pcb-readback.json` | `2d19f000b28263c3` | PCB 回读（焊盘/板框） |
| `public-round3-facts-20261014/drc-readback.json` | `de8117f8e72ac443` | 保存后原生 DRC 原始结果（`passed=false`，52+50） |
| `public-round3-facts-20261014/native-parts-readback.csv` | `8f20626b67e04971` | 39 器件 parts 回读 CSV |
| `public-round3-facts-20261014/interfaces.json` | `fc5538ddc252bd87` | 接口级复核（11 项） |
| `public-round3-facts-20261014/PCB1.epcb2` | `77d8da54226a6453` | 当前 PCB 同一对象（复核端 `native_input_sources` 引用） |
| `public-round3-facts-20261014/independent-reviews/{source_domain,schematic_bom_pins,pcb_connectivity_drc,geometry_fit,firmware_event_logic,board_firmware_interfaces,power_load_chain}.json` | 见 `FINAL-INDEX.json` `gates[]` | 七门独立证据 |
| `public-round3-facts-20261014/independent-reviews/{interfaces,joint-model-review}.json` | `97918090c8719b1a` / `6c726665c1b9141a` | 接口与联合模型复核源评审 |
| `public-round3-facts-20261014/manufacturing/export-receipt.json` | `67d8873c0b1a61df` | 制造出口回执（`native_files_unchanged=true`） |
| `public-round3-facts-20261014/manufacturing/P01-round3-Gerber.zip` | `f3dd8d25d7f13e2a` | 当前版制造出口归档（91234 B，14 成员） |

## 退出当前清单（原文件留作历史，未删除）

| 路径 | sha256（前 16） | 退出原因 |
|------|-----------------|----------|
| `public-interface-facts-20261014/PCB1.epcb2` | `5fb5c2a743aa` | 旧 PCB 副本（≠ 当前 `77d8da54…`） |
| `public-interface-facts-20261014/native-project/pcb/PCB1.epcb2` | `5fb5c2a743aa` | 旧 PCB 副本（冻结候选误指向的正是此处） |
| `public-interface-facts-20261014/native-project/BF-Literature-P01-Native-20261012.eprj3` | `6236aa623c5e` | 旧原工程副本（≠ 当前 `7e325475…`） |
| `public-interface-facts-20261014/native-project/sch/Schematic1/P1.esch2` | `7c88660f33e0` | 旧 `native-project` 副本（内容与当前原理图相同，但属旧副本目录，按指示整体退出） |
| `public-interface-facts-20261014/native-project/sch/Schematic1/Schematic1.ecfg` | （旧副本） | 同上 |
| `public-interface-facts-20261014/native-project/eprj3-intro.md` | （旧副本） | 同上 |
| `public-interface-facts-20261014/interfaces.json` | `5a304712597c` | 旧接口复核（基于旧 PCB） |
| `public-interface-facts-20261014/pcb-readback.json` | `4a4d11ca4695` | 旧 PCB 回读（基于旧 PCB） |
| `public-interface-facts-20261014/joint-model-review.json` | `075413031f69` | 旧联合模型复核 |
| `public-interface-facts-20261014/schematic-readback.json` | `2bc55e7a8156` | 旧原理图/PCB 回读，已被 round-3 回读取代 |
| `public-interface-facts-20261014/native-project-readback.json` | `07136285c1a8` | 旧原生回读，描述旧 PCB，已被 `native-readback.json` 取代 |
| `public-interface-facts-20261014/package-job-index.json` | `4abc3d27ae84` | 旧作业索引，仍列已被取代的 round-2 spice 作业 `eng-cf7f8bedba823521`（陈旧绑定指针） |

## 保留

| 路径 | sha256 | 原因 |
|------|--------|------|
| `public-interface-facts-20261014/firmware-events.json` | `e4df51568484f480…` | 被 `firmware_event_logic`、`board_firmware_interfaces`、`source_domain`、`power_load_chain` 四个门直接作为支撑源引用，必须留在清单内 |

## 约束遵守

- 三项原生作业继续 `eng-d6b2ca501db8e7fa` / `eng-6e2bc184592697d6` / `eng-9d45631d57148be4`；未重建、未重跑、未改设计。
- 未运行新工程、未扩展第四轮、未 submit；八门与冻结人工接通边界不变；四项独立要求保持未验证。
- 未删除任何文件；本记录所列“退出”仅表示不再被当前交付清单指向。
