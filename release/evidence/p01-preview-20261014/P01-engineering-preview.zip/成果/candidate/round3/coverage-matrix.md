# P01 首版数字工程覆盖矩阵（round-3，按公开独立只读检查更新）

状态列是**公开独立只读检查的当前状态**，不是自我判定。门定义来自 `contract.json`（八门）+ 任务书四项独立要求。
证据根：`public-round3-facts-20261014/FINAL-INDEX.json`（sha256 `5e4cd1e445e568ef…`）及其 `independent-reviews/`。
显式声明：**数字工程证据 ≠ 整机通过 ≠ 物理验证**。

| # | 门 | 状态 | 独立证据（sha256 前 16） | 未满足/待修项 |
|---|----|------|--------------------------|----------------|
| 1 | `source_domain` 真实源模型适用条件 | UNEVALUABLE | `independent-reviews/source_domain.json` `47318e2c8b62dcc6`；绑定 `eng-9d45631d57148be4` | TENG 端子标定与变电容、SECE 提取参数与变压器映射；链式等效（361.5 V 峰值/5 Hz/1 nF）与论文源域之间的标定仍未建立 |
| 2 | `schematic_bom_pins` 原理图/BOM/器件引脚 | UNEVALUABLE | `independent-reviews/schematic_bom_pins.json` `fb95737f135bed2e`；`native-parts-readback.csv` `8f20626b67e04971` | 器件/引脚/网络对应已 PASS（39 器件、**172 引脚**、差异 0）；仍缺供应商/封装/厂家引脚全审计、T1 绕组参数辨识、GaN 600 V 降额 |
| 3 | `pcb_connectivity_drc` 原生 PCB 连接/布局/DRC | **FAIL** | `independent-reviews/pcb_connectivity_drc.json` `4034af9b6573cb25`；`drc-readback.json` `de8117f8e72ac443` | 当前保存后原生 DRC `passed=false`：**52 Clearance Error + 50 Connection Error**，均未修复 |
| 4 | `geometry_fit` 真实板卡与结构装配 | UNEVALUABLE | `independent-reviews/geometry_fit.json` `96f80d6e849bdf2e`；`interfaces.json` `fc5538ddc252bd87` | 板框 **40.0 × 70.0 mm 一致**、全部器件中心在框内 **PASS**；缺原生器件 3D 高度、PCB→CAD 放置变换、安装孔对应 → 不能判通过（由上一轮自评 FAIL 更正为 UNEVALUABLE） |
| 5 | `firmware_event_logic` 固件事件状态反例 | **PASS** | `independent-reviews/firmware_event_logic.json` `1b25d198c9c4de0b`；`firmware-events.json` `e4df51568484f480`；`eng-6e2bc184592697d6` | —（18 反例通过，源为精确复用；不覆盖无线/功耗/引脚实测） |
| 6 | `board_firmware_interfaces` 板级引脚/总线/固件接口 | UNEVALUABLE | `independent-reviews/board_firmware_interfaces.json` `2ff434e096faa8c5` | SCL=27 / SDA=26、`LF_SRC=0` 已 PASS；PCA10040 UART/按键/LED 初始化对当前原生板未核 |
| 7 | `power_load_chain` 供能—储能—任务完整链 | **FAIL** | `independent-reviews/power_load_chain.json` `4e37d83f50ac3e04`；`independent-reviews/joint-model-review.json` `6c726665c1b9141a`；`eng-9d45631d57148be4` | 轨 4.2 V→0.353 V/16 s，1.8 V 观测在 0.9002 s 跌破标称；待修：初态开关伪影（非法负 MCU 轨 −1.32e6 V @3.2e-10 s）、未标定 SECE/buck 提取支路、固定 4.2 V 折算、policy↔radio 参数不一致 |
| 8 | `delivery_version` 同版本文件与实际作业绑定 | NOT_CHECKED（待最后独立检查） | 本清单 + `delivery/manifest.json` + 三项作业绑定 | 需独立端确认同版绑定；旧绑定因 `STALE_NATIVE_BINDING`/`STALE_REVIEW_INPUT` 被拒，保留为历史 |

## 接口级检查（`public-round3-facts-20261014/interfaces.json` `fc5538ddc252bd87`）

| 检查 | 状态 |
|------|------|
| 原工程身份 | PASS（`6bf7f7fa…`） |
| 原理图↔PCB 器件/引脚/网络对应 | PASS（39 器件 / 172 引脚 / 0 差异） |
| PCB↔CAD 板框尺寸 | PASS（40.0 × 70.0 mm） |
| 器件中心在板框内 | PASS（`outside=[]`） |
| PCB↔CAD 器件高度/安装映射 | UNEVALUABLE（缺 3D 高度、放置变换、孔位对应） |
| 传感器 GPIO 对应 | PASS（SCL 27 / SDA 26） |
| 板级 LF 时钟选择 | PASS（`LF_SRC=0`） |
| 目标 S132 输出电流 | PASS（`eng-6e2bc184592697d6`，S132-7.2.0） |
| 固件事件与实际驱动 | PASS（18） |
| 实际接收端回调/帧/关断 | PASS（6） |
| 全板外设初始化 | UNEVALUABLE（PCA10040 UART/按键/LED 未对当前原生板核） |

## 四项独立要求（不因本轮工作而改变）

| 要求 | 状态 |
|------|------|
| 自动接通 MCU | **未验证**（本任务只做人工接通；t≈0 人工开关闭合是声明边界） |
| 零能量冷启动 | **未验证**（4.2 V 初态由 BF 声明并建账） |
| 标定气体浓度 | **未验证**（不在本阶段范围） |
| 物理验证 | **NOT_TESTED**（无实测） |

## 本轮范围与边界

- `engineering_source_edits=0`、`solver_runs=0`、`target_builds=0`：只修交付指向，不改工程、不重跑未变成功作业。
- 制造出口已存在（`manufacturing/P01-round3-Gerber.zip` `f3dd8d25d7f13e2a`，回执 `67d8873c0b1a61df`），但同版 DRC 为 FAIL，
  **导出成功不等于可制造**。
- 旧的 `public-interface-facts-20261014` 原生 PCB/原工程副本、旧 readback/interfaces/joint-model-review 退出当前清单
  （原文件留作历史），处置明细见 `round3/delivery-pointer-fix.md`；`firmware-events.json` 保留（被 4 个门引用）。
