"""
P01 - self-powered TENG microsystem: parameterised, editable CadQuery reconstruction.

Source basis (see ../docs/source-map.json):
  - Paper P01 (doi 10.1038/s41378-026-01315-z), Fig.1a/Fig.2a/Fig.5a/Fig.6b, Methods, SI Table S2.
  - Active area 10 x 10 cm, acrylic backing 15 x 10 x 2 mm, 0.05 mm PTFE / 0.05 mm PI tribo films,
    copper electrodes, 1 cm contact-separation travel, PCB 4 x 7 cm, gas sensor 400 um glass /
    7 um IDT / 5 mm^2 active / 1.3 um PDMS.
  - Everything not dimensioned in the paper (spring stiffness, bearing model, hole coordinates,
    tolerances, PCB placement) is an EXPLICIT RECONSTRUCTION ASSUMPTION, not the original design.

All dimensions in millimetres. Writes assembly.step (+ per-part STL) into the current working dir.
"""
import json
import cadquery as cq

# ---------------------------------------------------------------- parameters (mm)
P = {
    "plate_l": 150.0, "plate_w": 100.0, "plate_t": 2.0,      # acrylic backing 15x10x0.2 cm
    "active_l": 100.0, "active_w": 100.0,                     # TENG active area 10x10 cm
    "foil_t": 0.05,                                           # copper foil (assumed)
    "ptfe_t": 0.05, "pi_t": 0.05,                             # tribo films
    "gap": 10.0,                                              # 1 cm contact-separation travel
    "guide_d": 8.0, "guide_h": 20.0, "guide_x": 80.0, "guide_y": 35.0,
    "spring_d": 8.0, "spring_h": 10.0, "spring_x": 68.0, "spring_y": 42.0,
    "pcb_l": 40.0, "pcb_w": 70.0, "pcb_t": 1.6,               # PCB 4x7 cm
    "cap_d": 10.0, "cap_h": 12.0,                             # 220 uF envelope
    "sensor_l": 7.0, "sensor_w": 7.0, "sensor_t": 0.4,        # 400 um glass
    "idt_w": 1.5, "idt_n": 20, "idt_gap": 0.007, "idt_fw": 0.007,  # 7 um width/gap IDT
    "conn_l": 10.0, "conn_w": 5.0, "conn_h": 3.0,
}

Z_PLATE_NEG = P["plate_t"] / 2.0                                  # 1.0
Z_CU_NEG = P["plate_t"] + P["foil_t"] / 2.0                       # 2.025
Z_PTFE = P["plate_t"] + P["foil_t"] + P["ptfe_t"] / 2.0           # 2.075
Z_GAP_TOP = Z_PTFE + P["ptfe_t"] / 2.0 + P["gap"]                 # 12.10
Z_PI = Z_GAP_TOP + P["pi_t"] / 2.0                                # 12.125
Z_CU_POS = Z_GAP_TOP + P["pi_t"] + P["foil_t"] / 2.0              # 12.175
Z_PLATE_POS = Z_GAP_TOP + P["pi_t"] + P["foil_t"] + P["plate_t"] / 2.0  # 13.20
Z_MID = (Z_PLATE_NEG + Z_GAP_TOP) / 2.0                           # guide/spring mid-height


def box(l, w, h, center, fillet=0.0):
    wp = cq.Workplane("XY").box(l, w, h)
    maxr = min(l, w, h) / 2.0 - 0.05   # fillet radius must stay below half the thinnest edge
    if fillet > 0 and fillet <= maxr:
        try:
            wp = wp.edges().fillet(fillet)
        except Exception:
            pass
    return wp.translate(center)


def cyl(d, h, center):
    return cq.Workplane("XY").circle(d / 2.0).extrude(h).translate((center[0], center[1], center[2] - h / 2.0))


# ---------------------------------------------------------------- part construction
parts = []  # (name, solid, rgb)

parts.append(("acrylic_backing_neg", box(P["plate_l"], P["plate_w"], P["plate_t"], (0, 0, Z_PLATE_NEG), 0.5), (0.85, 0.90, 0.95)))
parts.append(("copper_neg", box(P["active_l"], P["active_w"], P["foil_t"], (0, 0, Z_CU_NEG)), (0.72, 0.45, 0.20)))
parts.append(("ptfe_neg", box(P["active_l"], P["active_w"], P["ptfe_t"], (0, 0, Z_PTFE)), (0.92, 0.92, 0.92)))
parts.append(("pi_pos", box(P["active_l"], P["active_w"], P["pi_t"], (0, 0, Z_PI)), (0.95, 0.75, 0.20)))
parts.append(("copper_pos", box(P["active_l"], P["active_w"], P["foil_t"], (0, 0, Z_CU_POS)), (0.72, 0.45, 0.20)))
parts.append(("acrylic_backing_pos", box(P["plate_l"], P["plate_w"], P["plate_t"], (0, 0, Z_PLATE_POS), 0.5), (0.85, 0.90, 0.95)))

for i, (sx, sy) in enumerate(((1, 1), (1, -1), (-1, 1), (-1, -1))):
    parts.append((f"bearing_guide_{i}", cyl(P["guide_d"], P["guide_h"], (sx * P["guide_x"], sy * P["guide_y"], Z_MID)), (0.60, 0.60, 0.66)))
    parts.append((f"return_spring_{i}", cyl(P["spring_d"], P["spring_h"], (sx * P["spring_x"], sy * P["spring_y"], Z_MID)), (0.55, 0.55, 0.60)))

parts.append(("pcb_module", box(P["pcb_l"], P["pcb_w"], P["pcb_t"], (0, 95.0, 0.8)), (0.10, 0.35, 0.15)))
parts.append(("storage_cap_220u", cyl(P["cap_d"], P["cap_h"], (35.0, 95.0, 6.0)), (0.30, 0.30, 0.36)))
parts.append(("gas_sensor_substrate", box(P["sensor_l"], P["sensor_w"], P["sensor_t"], (-12.0, 100.0, 1.8)), (0.80, 0.85, 0.90)))
parts.append(("debug_connector", box(P["conn_l"], P["conn_w"], P["conn_h"], (0, 135.0, 1.5)), (0.90, 0.90, 0.92)))

# ---- film-level detail: 7 um interdigitated electrodes on the gas sensor (real CadQuery feature)
z_base = 2.0
count = P["idt_n"]
total_w = count * (P["idt_fw"] + P["idt_gap"]) - P["idt_gap"]
x0 = -12.0 - total_w / 2.0 + P["idt_fw"] / 2.0
bus_y = P["idt_w"] / 2.0 + 0.15
fingers = []
for i in range(count):
    x = x0 + i * (P["idt_fw"] + P["idt_gap"])
    y_end = bus_y if i % 2 == 0 else -bus_y
    fingers.append(box(P["idt_fw"], P["idt_w"], 0.001, (x, y_end / 2.0, z_base + 0.02)))
    parts.append((f"gas_sensor_idt_{i:02d}", box(P["idt_fw"], P["idt_w"], 0.0005, (x, 100.0 + y_end / 2.0, z_base + 0.01)), (0.35, 0.55, 0.75)))

# ---------------------------------------------------------------- assembly + export
assy = cq.Assembly(name="P01_teng_microsystem_reconstruction")
for name, shape, rgb in parts:
    assy.add(shape, name=name, color=cq.Color(rgb[0], rgb[1], rgb[2]))

assy.save("assembly.step")

# per-part STL for the fabrication/print files task
cq.exporters.export(box(P["plate_l"], P["plate_w"], P["plate_t"], (0, 0, 0), 0.5), "acrylic_backing_plate.stl")
moving = cq.Assembly(name="moving_plate")
moving.add(box(P["plate_l"], P["plate_w"], P["plate_t"], (0, 0, Z_PLATE_NEG), 0.5), name="acrylic", color=cq.Color(0.85, 0.9, 0.95))
moving.add(box(P["active_l"], P["active_w"], P["foil_t"], (0, 0, Z_CU_NEG)), name="copper", color=cq.Color(0.72, 0.45, 0.2))
moving.add(box(P["active_l"], P["active_w"], P["ptfe_t"], (0, 0, Z_PTFE)), name="ptfe", color=cq.Color(0.92, 0.92, 0.92))
moving.save("moving_plate.step")

bb = assy.toCompound().BoundingBox()
summary = {
    "units": "mm",
    "parts": len(parts),
    "bbox_mm": {"xlen": round(bb.xlen, 3), "ylen": round(bb.ylen, 3), "zlen": round(bb.zlen, 3)},
    "stack_bottom_z": round(Z_PLATE_NEG, 3),
    "stack_top_z": round(Z_PLATE_POS + P["plate_t"] / 2.0, 3),
    "note": "Envelope reconstruction; film-level IDT fingers modelled at 7 um. Not the original CAD.",
}
with open("cad_summary.json", "w") as fh:
    json.dump(summary, fh, indent=2)
print(json.dumps(summary, indent=2))
