# 尚待修复

- source_domain: 恒定TENG电容、幅度与提取参数缺少实测/结构到端口校准。
- schematic_bom_pins: 完整器件/BOM/引脚/封装与SECE控制、T1模型对应待核对。
- pcb_connectivity_drc: 34间距、60连通错误；D2板外。
- geometry_fit: 实际孔位、器件高度和PCB装配变换待绑定。
- board_firmware_interfaces: I2C/时钟对应；PCA10040 UART、按键/LED初始化待适配。
- power_load_chain: 广播模型5s/实际187.5ms、连接模型3s/实际100–200ms；开关接通前负载、固定4.2V折算和真实SECE/降压模型待修。
- physical: 尚未制作和测量。
