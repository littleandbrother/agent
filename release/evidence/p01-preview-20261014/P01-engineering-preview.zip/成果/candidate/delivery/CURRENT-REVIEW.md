# P01 当前同版工程审查（第二轮公共工具试验）

本版：名义1 cm/5 Hz输入，声明4.2 V初态，人工接通，16.001秒联合计算。工程输入未变（inputs sha256 1a7bd0e73015e794e6143114d1246459d6af7f7bb8a0acc40b0908882c5c331b，49文件），CAD/固件/电路/PCB/接收源码保持原样。

- CAD：复用 eng-d6b2ca501db8e7fa；PCB包络40×70×1.6 mm。
- 固件：复用真实 SDK17.1/S1327.2 构建 eng-6e2bc184592697d6。18项事件检查和6项接收检查通过。
- 联合SPICE：eng-cf7f8bedba823521，160599点；储能4.2→5.178284 V。现有RAW积分：注入1.597342 mJ、负载0.504640 mJ、漏电0.083494 mJ、储能增加1.009209 mJ（仅冻结模型数值，非实测）。
- 采样/接收：0.3、5.3、10.3、15.3秒，共4帧5b0a，解码2651。
- 本地原生EDA：39器件、172引脚对应；原工程文件随包提供。

## 本轮接口核对（bf_design interfaces，input_sha256 463c27bd3588c0598eb32ffab4206a9b82cc6f44f6df44f0ec405b3725829a54）

来源为 project-fw-s132/main.c（sha256 c421f94e687a6b0a1ba4e4f50d08a129f4109a8b519653b4881ea187d4aa12c0）实际宏，以及 public-interface-facts-20261014/firmware-events.json、interfaces.json。

- 实际广播间隔：187.5 ms（main.c:67 `APP_ADV_INTERVAL 300` × 0.625 ms），策略声明 5000 ms（main.c:96）；差 4812.5 ms，未对齐。
- 实际连接间隔：100–200 ms（main.c:69/70 `MSEC_TO_UNITS(100/200, UNIT_1_25_MS)`），策略声明 3000 ms（main.c:97）；差 2900 ms，未对齐。
- 采样周期：策略 5000 ms（main.c:95），与实际事件序列一致。
- 事件序列：sample 与 2字节 notify 成对出现于 300/5300/10300/15300 ms，4采样4通知，载荷 5b0a，解码 2651。
- interfaces.json 检查：原工程 P1/PCB 对应 PASS（39器件172引脚）、板框 40×70 PASS、传感器 GPIO（SCL 27/SDA 26）PASS、LF_SRC=0 PASS、S132 输出电流 PASS、固件事件18项 PASS、接收回帧6项 PASS；D2 在板框外 FAIL；器件高度/装配变换/安装孔 UNEVALUABLE；PCA10040 UART/按键/LED 初始化待适配 UNEVALUABLE。

## 独立验收结果（check-d04ee4156993de023fc7，check.json sha256 479c2e184660d012c5cfacb85da54af2d266c4cde3a3798c15c9ac06f888cc53）

- PASS：firmware_event_logic、delivery_version。
- FAIL：pcb_connectivity_drc（34间距、60连通错误；D2板外）、geometry_fit、power_load_chain。
- UNEVALUABLE：source_domain、schematic_bom_pins、board_firmware_interfaces。
- 状态：digital_engineering_status=REPAIR_REQUIRED，full_product_passed=false，physical=NOT_TESTED。

当前问题：
- source_domain: 恒定TENG电容、幅度与提取参数缺少实测/结构到端口校准。
- schematic_bom_pins: 完整器件/BOM/引脚/封装与SECE控制、T1模型对应待核对。
- pcb_connectivity_drc: 34间距、60连通错误；D2板外。
- geometry_fit: 实际孔位、器件高度和PCB装配变换待绑定。
- board_firmware_interfaces: I2C/时钟对应；PCA10040 UART、按键/LED初始化待适配。
- power_load_chain: 广播模型5s/实际187.5ms、连接模型3s/实际100–200ms；开关接通前负载、固定4.2V折算和真实SECE/降压模型待修。
- physical: 尚未制作和测量。

Pi：现有工程与新联合模型作者、实际执行、候选冻结与提交。Codex：公共执行修复、独立检查、确定性元数据模板。本轮为第二轮公共元数据工具使用试验，只更新交付元数据与审查提交，未新建求解/构建/EDA写入，未重复未变的已通过作业。

八项独立验收与冻结的人工接通边界保持；四项独立要求（自动接通、零能量冷启动、气体浓度标定、物理验证）继续标为未验证。
