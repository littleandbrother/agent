import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
manifest = json.loads((root/'manifest.json').read_text())
for name, expected in manifest.items():
    p = (root/name).resolve()
    assert p.is_relative_to(root) and p.is_file(), name
    assert sha(p) == expected, 'manifest: '+name
seal = json.loads((root/'seal.json').read_text())
for name, expected in seal['sources'].items():
    assert sha(root/'source-snapshot'/name) == expected, 'source: '+name
checked = 0
for p in (root/'records').glob('*/receipt.json'):
    receipt = json.loads(p.read_text())
    if receipt.get('result_sha256'):
        result_path = p.parent/'result.json'
        assert sha(result_path) == receipt['result_sha256'], 'result: '+str(p.parent)
        result = json.loads(result_path.read_text())
        for artifact in result.get('artifacts', []):
            small = p.parent/artifact['name']
            if small.exists(): assert sha(small) == artifact['sha256'], str(small)
    checked += 1
print(json.dumps({'status':'passed','manifest_files':len(manifest),'native_attempts':checked,
                  'scope':'byte integrity and preserved receipts; does not rerun native solvers'}))
