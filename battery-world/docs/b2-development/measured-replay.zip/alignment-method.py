#!/usr/bin/env python3
"""H13 e64/e128 phase-energy ledger with waveform-to-event alignment.

The STLINK hw trigger fires on the first TGI edge (rising or falling), so a
short 2 s window may miss the transaction. This analysis instead expects a
6 s SW-trigger capture: the node self-resets every ~5.2 s, so every window
contains at least one complete transaction. Each transaction is located in the
power trace from the characteristic wake burst, and the STM32 DWT/LPTIM event
timestamps provide the phase boundaries (LPTIM for the STOP2 acquisition
phase, DWT elsewhere).

Usage:
    python3 scripts/h13_phase_energy_align.py --rep-dir measurements/h13_m64_ok6
        --voltage 3.3
"""

from __future__ import annotations

import argparse
import bisect
import csv
import statistics
from pathlib import Path


PHASES = [
    # (begin_event, end_event, label)
    ("ACQ_BEGIN", "ACQ_READ_BEGIN", "acq_fifo"),     # wake + STOP2 (LPTIM wall)
    ("ACQ_READ_BEGIN", "ACQ_READ_END", "acq_read"),
    ("INF64_BEGIN", "INF64_END", "infer64"),
    ("INF128_BEGIN", "INF128_END", "infer128"),
    ("ACQ_MORE_BEGIN", "ACQ_MORE_END", "acq_more"),
    ("ROUTER_BEGIN", "ROUTER_END", "router"),
    ("BLE_BEGIN", "BLE_END", "ble_tx"),
]


def read_events(path: Path) -> list[tuple[str, int, int, int]]:
    rows = []
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            rows.append((row["name"], int(row["cycles"]),
                         int(row["time_us"]), int(row["lptim_abs"])))
    return rows


def read_power(path: Path) -> tuple[list[float], list[float]]:
    times, currents = [], []
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            times.append(float(row["time_s"]))
            currents.append(float(row["current_A"]))
    return times, currents


def event_wall_times(events: list[tuple[str, int, int, int]],
                     lptim_tick_us: float = 1e6 / 1024.0) -> dict[str, float]:
    """Reconstruct event wall times (s) relative to TRANSACTION_BEGIN."""
    if not events:
        return {}
    t_abs_us = [0.0] * len(events)
    stop2_pairs = {"ACQ_BEGIN", "ACQ128_BEGIN", "ACQ_MORE_BEGIN"}
    for i in range(1, len(events)):
        dwt_delta = max(0.0, float(events[i][2] - events[i - 1][2]))
        lptim_delta = max(0.0, float(events[i][3] - events[i - 1][3])) * lptim_tick_us
        if events[i - 1][0] in stop2_pairs:
            duration_us = lptim_delta
        else:
            duration_us = dwt_delta
            if duration_us <= 0.0:
                duration_us = lptim_delta
        t_abs_us[i] = t_abs_us[i - 1] + duration_us
    return {name: t_abs_us[i] / 1e6 for i, (name, _, _, _) in enumerate(events)}


def detect_transactions(times: list[float], currents: list[float],
                        ramp_thresh_a: float = 0.0005,
                        wake_thresh_a: float = 0.004,
                        wake_sustain_s: float = 0.008,
                        idle_before_s: float = 0.040,
                        skip_after_s: float = 0.700) -> list[float]:
    """Find transaction starts: sustained idle -> ramp above 0.5 mA that
    reaches >=4 mA within 30 ms and STAYS >=4 mA for >=8 ms (this rejects the
    ~3 ms nRF advertising pulses). One start per transaction."""
    starts: list[float] = []
    i = 0
    n = len(currents)
    while i < n:
        if currents[i] >= ramp_thresh_a:
            # the whole preceding window must be idle
            k = i - 1
            idle = True
            if k < 0:
                idle = False
            while k >= 0 and times[i] - times[k] < idle_before_s:
                if currents[k] >= ramp_thresh_a:
                    idle = False
                    break
                k -= 1
            if idle:
                # verify this ramp reaches the wake level within 30 ms and
                # stays there (nRF advertising pulses are only ~3 ms)
                j = i
                reached = False
                while j < n and times[j] - times[i] < 0.030:
                    if currents[j] >= wake_thresh_a:
                        reached = True
                        break
                    j += 1
                if reached:
                    j0 = j
                    while j < n and times[j] - times[j0] < wake_sustain_s:
                        if currents[j] < wake_thresh_a:
                            break
                        j += 1
                    if times[j] - times[j0] >= wake_sustain_s * 0.5:
                        starts.append(times[i])
                        i = bisect.bisect_left(times, times[i] + skip_after_s)
                        continue
        i += 1
    return starts


def integrate_segment(times: list[float], currents: list[float],
                      t0: float, t1: float, voltage: float) -> dict:
    lo = bisect.bisect_left(times, t0)
    hi = bisect.bisect_right(times, t1)
    n = hi - lo
    if n < 2:
        return {"duration_ms": (t1 - t0) * 1e3, "mean_current_mA": 0.0,
                "peak_current_mA": 0.0, "energy_mJ": 0.0, "samples": n}
    ts = times[lo:hi]
    cs = currents[lo:hi]
    energy_j = sum(0.5 * (cs[k] + cs[k + 1]) * (ts[k + 1] - ts[k])
                   for k in range(n - 1))
    return {
        "duration_ms": (t1 - t0) * 1e3,
        "mean_current_mA": sum(cs) / n * 1e3,
        "peak_current_mA": max(cs) * 1e3,
        "energy_mJ": energy_j * voltage * 1e3,
        "samples": n,
    }


def process_rep(power_csv: Path, events_csv: Path,
                voltage: float) -> list[dict]:
    times, currents = read_power(power_csv)
    events = read_events(events_csv)
    wall = event_wall_times(events)
    if "TRANSACTION_BEGIN" not in wall:
        return []

    tx_starts = detect_transactions(times, currents)
    rows: list[dict] = []
    for tx0 in tx_starts:
        row = {"rep_tx_start_s": round(tx0, 5)}
        for begin, end, label in PHASES:
            if begin in wall and end in wall:
                seg = integrate_segment(times, currents,
                                        tx0 + wall[begin],
                                        tx0 + wall[end], voltage)
                for k, v in seg.items():
                    row[f"{label}_{k}"] = round(v, 4)
        # mark progressive continuation transactions (second 64-frame segment)
        if "acq_more_energy_mJ" in row and row["acq_more_samples"] >= 2:
            row["continued"] = 1
            # In the progressive build the ROUTER phase brackets the second
            # segment read; exclude that read from the router window so the
            # controller cost is not double-counted with acq_more.
            if all(k in wall for k in ("ROUTER_BEGIN", "ACQ_MORE_BEGIN",
                                       "ACQ_MORE_END", "ROUTER_END")):
                a = integrate_segment(times, currents,
                                      tx0 + wall["ROUTER_BEGIN"],
                                      tx0 + wall["ACQ_MORE_BEGIN"], voltage)
                b = integrate_segment(times, currents,
                                      tx0 + wall["ACQ_MORE_END"],
                                      tx0 + wall["ROUTER_END"], voltage)
                dur_ms = a["duration_ms"] + b["duration_ms"]
                energy_mj = a["energy_mJ"] + b["energy_mJ"]
                mean_ma = (energy_mj / (voltage * (dur_ms / 1e3)) * 1e3
                           if dur_ms > 0 else 0.0)
                row["router_duration_ms"] = round(dur_ms, 4)
                row["router_energy_mJ"] = round(energy_mj, 4)
                row["router_mean_current_mA"] = round(mean_ma, 4)
                row["router_samples"] = a["samples"] + b["samples"]
        else:
            row["continued"] = 0
        # whole transaction: wake start -> TRANSACTION_END
        if "TRANSACTION_END" in wall:
            seg = integrate_segment(times, currents,
                                    tx0, tx0 + wall["TRANSACTION_END"], voltage)
            for k, v in seg.items():
                row[f"txn_{k}"] = round(v, 4)
        # sanity: a correct alignment has the wake+STOP2 mixture clearly below
        # the inference current (e64 ~3.5 vs ~14 mA; e128 ~2.0 vs ~14 mA);
        # main-phase misalignments produce similar/higher means or idle
        # inference phases.
        af_mean = row.get("acq_fifo_mean_current_mA")
        inf_mean = row.get("infer64_mean_current_mA")
        if inf_mean is None:
            inf_mean = row.get("infer128_mean_current_mA")
        if inf_mean is None or not (8.0 <= inf_mean <= 20.0):
            continue
        if af_mean is None or af_mean >= 0.6 * inf_mean:
            continue
        rows.append(row)
    return rows


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--rep-dir", required=True, type=Path)
    ap.add_argument("--voltage", type=float, default=3.3)
    args = ap.parse_args()

    all_rows: list[dict] = []
    for power_csv in sorted(args.rep_dir.glob("power_rep_*.csv")):
        events_csv = power_csv.parent / power_csv.name.replace("power_", "events_")
        if not events_csv.exists():
            continue
        rows = process_rep(power_csv, events_csv, args.voltage)
        for r in rows:
            r["rep"] = power_csv.stem.replace("power_rep_", "")
        all_rows.extend(rows)

    if not all_rows:
        raise SystemExit("no transactions detected")

    out = args.rep_dir / "phase_energy_aligned.csv"
    fieldnames = sorted({k for r in all_rows for k in r})
    with out.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_rows)

    # summary of the phase energies across transactions
    phase_labels = [label for _, _, label in PHASES]
    summary = []
    for label in phase_labels:
        energies = [r[f"{label}_energy_mJ"] for r in all_rows
                    if f"{label}_energy_mJ" in r and r[f"{label}_samples"] >= 2]
        durations = [r[f"{label}_duration_ms"] for r in all_rows
                     if f"{label}_duration_ms" in r and r[f"{label}_samples"] >= 2]
        if energies:
            summary.append({
                "phase": label,
                "n": len(energies),
                "duration_ms_mean": round(statistics.mean(durations), 3),
                "duration_ms_std": round(statistics.stdev(durations), 3),
                "energy_mJ_mean": round(statistics.mean(energies), 4),
                "energy_mJ_std": round(statistics.stdev(energies), 4),
            })
    txn_energies = [r["txn_energy_mJ"] for r in all_rows
                    if "txn_energy_mJ" in r and r["txn_samples"] >= 2]
    if txn_energies:
        summary.append({
            "phase": "transaction_total",
            "n": len(txn_energies),
            "duration_ms_mean": round(
                statistics.mean(r["txn_duration_ms"] for r in all_rows
                                if "txn_duration_ms" in r), 3),
            "duration_ms_std": round(
                statistics.stdev(r["txn_duration_ms"] for r in all_rows
                                 if "txn_duration_ms" in r), 3),
            "energy_mJ_mean": round(statistics.mean(txn_energies), 4),
            "energy_mJ_std": round(statistics.stdev(txn_energies), 4),
        })
    sum_path = args.rep_dir / "phase_energy_aligned_summary.csv"
    with sum_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(summary[0].keys()))
        writer.writeheader()
        writer.writerows(summary)

    print(f"transactions aligned: {len(all_rows)}")
    print(f"detail: {out}")
    print(f"summary: {sum_path}")
    for s in summary:
        print(f"  {s['phase']:>16}: "
              f"E={s['energy_mJ_mean']:8.4f}±{s['energy_mJ_std']:.4f} mJ "
              f"t={s['duration_ms_mean']:8.3f}±{s['duration_ms_std']:.3f} ms "
              f"(n={s['n']})")


if __name__ == "__main__":
    main()
