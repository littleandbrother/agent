#include <stdint.h>

/* Full-width uint32 identity latches: no narrowing/truncation. */
static uint32_t cur_conn;   /* current connection, incl. 0 and >65535 */
static uint32_t cur_op;     /* operation of the pending pair, full uint32 */
static int has_pending;     /* 1 iff an operation is pending on cur_conn */
static int connected;       /* 1 iff an epoch is currently connected */
static int delivery_count;  /* completions observed via matching send_done */

void reset(void){
    cur_conn = 0u;
    cur_op = 0u;
    has_pending = 0;
    connected = 0;          /* connection identity 0 but disconnected */
    delivery_count = 0;
}

void handle(int kind, uint32_t connection, uint32_t operation){
    if (kind == 1) {        /* connect: installs epoch, clears pending work */
        cur_conn = connection;
        connected = 1;
        has_pending = 0;
        cur_op = 0u;
    } else if (kind == 2) { /* disconnect: only for current connection */
        if (connected && connection == cur_conn) {
            connected = 0;
            has_pending = 0;
            cur_op = 0u;
        }
    } else if (kind == 3) { /* request: start/replace op on current connection */
        if (connected && connection == cur_conn) {
            cur_op = operation;
            has_pending = 1;
        }
    } else if (kind == 4) { /* sample_ready: keeps pending, never settles */
        (void)connection;
        (void)operation;
    } else if (kind == 5) { /* send_done: completes the pending pair once */
        if (connected && has_pending &&
            connection == cur_conn && operation == cur_op) {
            delivery_count++;
            has_pending = 0;
            cur_op = 0u;
        }
    } else if (kind == 6) { /* timeout: cancels the current pending pair */
        if (connected && has_pending &&
            connection == cur_conn && operation == cur_op) {
            has_pending = 0;
            cur_op = 0u;
        }
    }
    /* every other/stale event: no-op, state intact */
}

int pending(void){ return has_pending; }
uint32_t connection(void){ return cur_conn; }
uint32_t operation(void){ return cur_op; }
int deliveries(void){ return delivery_count; }
