#include <stdint.h>

/* Frozen ABI state. Identity = exact uint32 equality, including 0 and >65535. */
static uint32_t cur_conn;   /* current connection (uint32, never truncated) */
static uint32_t cur_op;     /* current pending operation (0 when idle)      */
static int      has_pending;
static int      deliveries_n;
static int      is_connected;

void reset(void){
    cur_conn = 0u;
    cur_op = 0u;
    has_pending = 0;
    deliveries_n = 0;
    is_connected = 0;   /* connection 0 but disconnected at init */
}

void handle(int kind, uint32_t connection, uint32_t operation){
    if (kind == 1) {                 /* connect: install epoch, clear pending */
        cur_conn = connection;
        is_connected = 1;
        has_pending = 0;
        cur_op = 0u;
    } else if (kind == 2) {          /* disconnect: only current connection */
        if (is_connected && connection == cur_conn) {
            is_connected = 0;
            has_pending = 0;
            cur_op = 0u;
        }
    } else if (kind == 3) {          /* request: current connection only */
        if (is_connected && connection == cur_conn) {
            cur_op = operation;      /* start or replace, full uint32 */
            has_pending = 1;
        }
    } else if (kind == 4) {          /* sample_ready: keep pending, no settle */
    } else if (kind == 5) {          /* send_done: settle current pending pair */
        if (is_connected && has_pending &&
            connection == cur_conn && operation == cur_op) {
            deliveries_n += 1;
            has_pending = 0;
            cur_op = 0u;
        }
    } else if (kind == 6) {          /* timeout: cancel current pending pair */
        if (is_connected && has_pending &&
            connection == cur_conn && operation == cur_op) {
            has_pending = 0;
            cur_op = 0u;
        }
    }
    /* unknown/unmatched events: no-op, state untouched */
}

int pending(void){ return has_pending; }
uint32_t connection(void){ return cur_conn; }
uint32_t operation(void){ return cur_op; }
int deliveries(void){ return deliveries_n; }
