#include <stdint.h>
static uint32_t c,op;static int p,d,connected;
void reset(void){c=0;op=0;p=0;d=0;connected=0;}
void handle(int k,uint32_t x,uint32_t y){
 if(k==1){c=x;connected=1;p=0;op=0;}
 else if(k==2){if(connected&&x==c){connected=0;p=0;op=0;}}
 else if(k==3){if(connected&&x==c){op=y;p=1;}}
 else if(k==4){if(p&&x==c&&y==op){p=1;}}
 else if(k==5){if(p&&x==c&&y==op){d++;p=0;op=0;}}
 else if(k==6){if(p&&x==c&&y==op){p=0;op=0;}}
}
int pending(void){return p;}uint32_t connection(void){return c;}
uint32_t operation(void){return op;}int deliveries(void){return d;}
