#include <stdint.h>

/* Async event core with exact uint32 (connection, operation) identity.
 * State is latched in full width; callbacks that do not match the
 * current connection / currently pending pair are strict no-ops. */

static uint32_t cur;   /* current connection id (full uint32)      */
static uint32_t pc;    /* pending connection id (full uint32)       */
static uint32_t po;    /* pending operation id  (full uint32)       */
static int conn;       /* 1 = connected epoch installed             */
static int pend;       /* 1 = a request is pending for (pc, po)     */
static int deliv;      /* completed delivery count                  */

void reset(void) {
    cur = 0;
    pc = 0;
    po = 0;
    conn = 0;   /* disconnected; connection() still reads 0 */
    pend = 0;
    deliv = 0;
}

void handle(int kind, uint32_t connection, uint32_t operation) {
    switch (kind) {
    case 1: /* connect: install current connection, clear pending work */
        cur = connection;
        conn = 1;
        pend = 0;
        pc = 0;
        po = 0;
        break;

    case 2: /* disconnect: only for the current connection */
        if (conn && connection == cur) {
            conn = 0;
            pend = 0;
            pc = 0;
            po = 0;
        }
        break;

    case 3: /* request: only on the current connection */
        if (conn && connection == cur) {
            pc = connection;
            po = operation;
            pend = 1;
        }
        break;

    case 4: /* sample_ready: keeps pending; never settles or changes state */
        break;

    case 5: /* send_done: only for the currently pending pair */
        if (conn && pend && connection == pc && operation == po) {
            deliv++;
            pend = 0;
            pc = 0;
            po = 0;
        }
        break;

    case 6: /* timeout: only cancels the currently pending pair */
        if (pend && connection == pc && operation == po) {
            pend = 0;
            pc = 0;
            po = 0;
        }
        break;

    default:
        break;
    }
}

int pending(void)          { return pend; }
uint32_t connection(void)  { return cur; }
uint32_t operation(void)   { return po; }
int deliveries(void)       { return deliv; }
