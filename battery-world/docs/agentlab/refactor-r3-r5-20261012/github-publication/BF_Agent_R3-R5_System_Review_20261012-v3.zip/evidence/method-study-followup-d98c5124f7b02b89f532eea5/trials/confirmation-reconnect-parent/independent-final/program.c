#include <stdint.h>
/* Async event core. All identity is exact uint32; no truncation, no allocation,
   no external calls. Idle: pending=0, operation=0. */
static uint32_t cur_conn;   /* installed current connection epoch */
static uint32_t pend_conn;  /* connection of the pending pair */
static uint32_t pend_op;    /* operation of the pending pair */
static int connected;       /* 1 once a connect epoch is installed */
static int pending_flag;    /* 1 iff an operation is pending */
static int deliveries_count;

void reset(void){
  cur_conn = 0u; pend_conn = 0u; pend_op = 0u;
  connected = 0; pending_flag = 0; deliveries_count = 0;
}

static void clear_pending(void){ pending_flag = 0; pend_conn = 0u; pend_op = 0u; }

void handle(int kind, uint32_t connection, uint32_t operation){
  switch(kind){
    case 1: /* connect: real epoch even for connection==0; clears pending work */
      cur_conn = connection;
      connected = 1;
      clear_pending();
      break;
    case 2: /* disconnect: only for the current connection */
      if(connected && connection == cur_conn){
        connected = 0;
        clear_pending();
      }
      break;
    case 3: /* request: only on the current connection; starts/replaces op */
      if(connected && connection == cur_conn){
        pend_conn = connection;
        pend_op = operation;
        pending_flag = 1;
      }
      break;
    case 4: /* sample_ready: optional ack; never starts or settles work */
      break;
    case 5: /* send_done: settle only the exact currently pending pair */
      if(pending_flag && connection == pend_conn && operation == pend_op){
        clear_pending();
        deliveries_count++;
      }
      break;
    case 6: /* timeout: cancel only the exact currently pending pair */
      if(pending_flag && connection == pend_conn && operation == pend_op){
        clear_pending();
      }
      break;
    default:
      break;
  }
}

int pending(void){ return pending_flag; }
uint32_t connection(void){ return cur_conn; }
uint32_t operation(void){ return pend_op; }
int deliveries(void){ return deliveries_count; }
