#include <stdint.h>
static uint32_t cur, pc, po;
static int conn, pend, deliv;
void reset(void){cur=0;pc=0;po=0;conn=0;pend=0;deliv=0;}
void handle(int k,uint32_t x,uint32_t y){
 switch(k){
  case 1: cur=x; conn=1; pend=0; pc=0; po=0; break;
  case 2: if(conn && x==cur){conn=0; pend=0; pc=0; po=0;} break;
  case 3: if(conn && x==cur){pc=x; po=y; pend=1;} break;
  case 4: break;
  case 5: if(conn && pend && x==pc && y==po){deliv++; pend=0; pc=0; po=0;} break;
  case 6: if(pend && x==pc && y==po){pend=0; pc=0; po=0;} break;
  default: break;
 }
}
int pending(void){return pend;}
uint32_t connection(void){return cur;}
uint32_t operation(void){return po;}
int deliveries(void){return deliv;}
