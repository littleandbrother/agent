#include <stdint.h>
#define W 64
static int state, n, cls_val, have_cls;
static double age, sample_clock, elapsed, buf[W];
static uint32_t pending, done;

void reset(void){
    int i;
    state=0; n=0; cls_val=0; have_cls=0;
    age=0.0; sample_clock=0.0; elapsed=0.0;
    pending=0u; done=0u;
    for(i=0;i<W;i++) buf[i]=0.0;
}
int phase(void){ return state; }
double current_A(void){
    if(state==1) return 0.00041;
    if(state==2) return 0.001596;
    if(state==3) return 0.003659;
    return 0.0000003;
}
static void classify(void){
    int i, k=n, c=0; double s=0.0, m, thr;
    if(k>W) k=W;
    if(k<2){ cls_val=0; have_cls=1; return; }
    for(i=0;i<k;i++) s+=buf[i];
    m=s/(double)k;
    for(i=1;i<k;i++){ if((buf[i]>=m)!=(buf[i-1]>=m)) c++; }
    thr = 120.0*(double)k/256.0;
    cls_val = ((double)c>=thr)?1:0;
    have_cls=1;
}
int step(double dt,double V,uint32_t req,int avail,double sample,uint32_t*out,int*cls){
    (void)avail;
    if(state==0){ if(V>=3.0 && req!=0u && req!=done){ pending=req; state=1; age=0.0; } }
    else if(state==1){ age+=dt; if(age>=0.03){ state=2; n=0; sample_clock=0.0; elapsed=0.0; have_cls=0; } }
    else if(state==2){
        sample_clock+=dt; elapsed+=dt;
        if(sample_clock>=1.0/256.0){ sample_clock-=1.0/256.0;
            if(n<W){ buf[n]=sample; n++; }
            if(n>=W){ classify(); state=3; age=0.0; } }
        if(state==2 && elapsed>=0.4){ classify(); state=3; age=0.0; }
    }
    else if(state==3){ age+=dt; if(age>=0.005){ *out=pending; *cls=have_cls?cls_val:0; done=pending; state=0; return 1; } }
    return 0;
}
