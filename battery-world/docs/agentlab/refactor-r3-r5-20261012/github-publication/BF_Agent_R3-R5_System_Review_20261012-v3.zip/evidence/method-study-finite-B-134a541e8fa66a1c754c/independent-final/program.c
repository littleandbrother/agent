#include <stdint.h>
static int state,n,crossings;
static double age,sample_clock,last;
static uint32_t pending,done;
void reset(void){state=0;n=0;crossings=0;age=0;sample_clock=0;last=0;pending=0;done=0;}
int phase(void){return state;}
double current_A(void){
 if(state==1)return 0.00041;
 if(state==2)return 0.001596;
 if(state==3)return 0.003659;
 return 0.0000003;
}
int step(double dt,double V,uint32_t req,int truth,double sample,uint32_t*out,int*cls){
 (void)truth;
 if(state==0){
  if(V>=3.0&&req!=0&&req!=done){pending=req;state=1;age=0;}
 }
 else if(state==1){
  age+=dt;
  if(age>=0.03){state=2;n=0;crossings=0;sample_clock=0;last=0;}
 }
 else if(state==2){
  sample_clock+=dt;
  if(sample_clock>=1.0/256.0){
   sample_clock-=1.0/256.0;
   if(n>0&&((sample>=0)!=(last>=0)))crossings++;
   last=sample;n++;
   if(n>=4){state=3;age=0;}
  }
 }
 else if(state==3){
  age+=dt;
  if(age>=0.005){
   *out=pending;*cls=0;done=pending;state=0;
   return 1;
  }
 }
 return 0;
}