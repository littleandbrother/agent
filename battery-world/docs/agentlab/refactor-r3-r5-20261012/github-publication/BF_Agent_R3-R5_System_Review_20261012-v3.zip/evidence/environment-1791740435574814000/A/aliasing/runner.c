#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
void reset(void); int step(double,double,uint32_t,int,double,uint32_t*,int*);
double current_A(void); int phase(void);
int main(int argc,char**argv){
 if(argc!=12)return 10;
 FILE*f=fopen(argv[1],"w");if(!f)return 11;
 int ca=atoi(argv[2]);double dt=atof(argv[3]),duration=atof(argv[4]),cap=atof(argv[5]);
 double input=atof(argv[6]),initial=atof(argv[7]),leak=atof(argv[8]),delay=atof(argv[9]);
 int count=atoi(argv[10]),truthshift=atoi(argv[11]);
 double E=initial,last=0;int reset_count=0;reset();
 fputs("t,V,E_J,source_W,load_W,dump_W,state,request_id,tx_id,class,reset\n",f);
 for(int k=0;k<=(int)round(duration/dt);k++){
  double t=k*dt,V=sqrt(2*fmax(E,0)/cap),src=0;
  if(ca==1)src=input*fabs(sin(2*3.141592653589793*30*t));
  else if(t>=delay&&t<delay+.1)src=input/.1;
  uint32_t req=0;int truth=0;double sample=0;
  for(int j=0;j<count;j++){
   double rt=ca==1?2+3*j:0;
   if(t>=rt&&t<rt+(ca==1?.75:1.)){req=(uint32_t)(60001+65537*j);truth=(j+truthshift)%2;
    sample=sin(2*3.141592653589793*(truth?90:30)*(t-rt));}
  }
  if(V<1.8){reset();if(last>=1.8)reset_count++;}
  uint32_t tx=0;int cls=-1;
  int sample_port=phase()==2;
  if(V>=1.8)step(dt,V,req,sample_port,sample_port?sample:0.,&tx,&cls);
  double draw=current_A();
  int state=phase();double modeled=state==1?.00041:state==2?.001596:state==3?.003659:.0000003;
  if(state<0||state>3||!isfinite(draw)||fabs(draw-modeled)>1e-12)return 12;
  double load=V*(draw+leak),raw=E+(src-load)*dt,maximum=.5*cap*3.3*3.3;
  double dump=fmax(0,raw-maximum)/dt;
  fprintf(f,"%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%u,%u,%d,%d\n",
    t,V,E,src,load,dump,phase(),req,tx,cls,reset_count);
  E=fmin(maximum,fmax(0,raw));last=V;
 }
 fclose(f);return 0;
}