#include <stdint.h>
static int state,n,crossings;static double age,sample_clock,last;
static uint32_t pending,done;
void reset(void){state=n=crossings=0;age=sample_clock=last=0;pending=done=0;}
int phase(void){return state;}
double current_A(void){return state==1?.00041:state==2?.001596:state==3?.003659:.0000003;}
int step(double dt,double V,uint32_t req,int truth,double sample,uint32_t*out,int*cls){
 (void)truth;
 if(state==0){if(V>=3.&&req&&req!=done){pending=req;state=1;age=0;}}
 else if(state==1){age+=dt;if(age>=.03){state=2;n=crossings=0;sample_clock=0;last=0;}}
 else if(state==2){sample_clock+=dt;
  if(sample_clock>=1./256){sample_clock-=1./256;if(n&&((sample>=0)!=(last>=0)))crossings++;
   last=sample;n++;if(n>=4){state=3;age=0;}}}
 else if(state==3){age+=dt;if(age>=1.0){*out=pending;*cls=0;done=pending;state=0;return 1;}}
 return 0;
}