#include <stdint.h>
static uint32_t cur_conn, cur_op;
static int pend, deliv, linked;

void reset(void){cur_conn=0u;cur_op=0u;pend=0;deliv=0;linked=0;}

void handle(int kind,uint32_t connection,uint32_t operation){
  switch(kind){
    case 1: /* connect: install exact identity, clear pending work */
      cur_conn=connection; linked=1; pend=0; cur_op=0u; break;
    case 2: /* disconnect: only current connection */
      if(linked && connection==cur_conn){ linked=0; pend=0; cur_op=0u; } break;
    case 3: /* request: only on current connection; starts/replaces op */
      if(linked && connection==cur_conn){ cur_op=operation; pend=1; } break;
    case 4: /* sample_ready: keeps pending request for send_done */
      if(linked && pend && connection==cur_conn && operation==cur_op){ pend=1; } break;
    case 5: /* send_done: completes only current pending pair, once */
      if(linked && pend && connection==cur_conn && operation==cur_op){
        pend=0; cur_op=0u; deliv++; } break;
    case 6: /* timeout: cancels only current pending pair */
      if(linked && pend && connection==cur_conn && operation==cur_op){
        pend=0; cur_op=0u; } break;
    default: break;
  }
}

int pending(void){return pend;}
uint32_t connection(void){return cur_conn;}
uint32_t operation(void){return cur_op;}
int deliveries(void){return deliv;}
