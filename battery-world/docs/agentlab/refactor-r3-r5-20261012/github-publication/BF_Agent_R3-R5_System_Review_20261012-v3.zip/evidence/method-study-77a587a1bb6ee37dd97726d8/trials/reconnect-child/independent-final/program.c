#include <stdint.h>
static uint32_t cur_conn, cur_op;      /* current connection, current operation */
static uint32_t pend_conn, pend_op;    /* latched pending pair (full uint32) */
static int connected, pending_flag, d;

void reset(void){
  cur_conn=0; cur_op=0; pend_conn=0; pend_op=0;
  connected=0; pending_flag=0; d=0;
}

void handle(int k, uint32_t x, uint32_t y){
  if(k==1){                       /* connect: real epoch, even connect(0) */
    connected=1; cur_conn=x; cur_op=0;
    pend_conn=0; pend_op=0; pending_flag=0;
  } else if(k==2){                /* disconnect: only current connection */
    if(connected && x==cur_conn){
      connected=0; cur_op=0;
      pend_conn=0; pend_op=0; pending_flag=0;
    }
  } else if(k==3){                /* request on current connection starts/replaces */
    if(connected && x==cur_conn){
      cur_op=y; pend_conn=x; pend_op=y; pending_flag=1;
    }
  } else if(k==4){                /* sample_ready keeps pending, never settles */
    (void)(pending_flag && x==pend_conn && y==pend_op);
  } else if(k==5){                /* send_done settles only exact pending pair */
    if(pending_flag && x==pend_conn && y==pend_op){
      d++; cur_op=0; pend_conn=0; pend_op=0; pending_flag=0;
    }
  } else if(k==6){                /* timeout cancels only exact pending pair */
    if(pending_flag && x==pend_conn && y==pend_op){
      cur_op=0; pend_conn=0; pend_op=0; pending_flag=0;
    }
  }
}

int pending(void){ return pending_flag; }
uint32_t connection(void){ return cur_conn; }
uint32_t operation(void){ return cur_op; }
int deliveries(void){ return d; }
