#include <stdint.h>
static uint32_t cur, op;
static int pend, deliv, connected;

void reset(void) { cur = 0; op = 0; pend = 0; deliv = 0; connected = 0; }

void handle(int kind, uint32_t connection, uint32_t operation) {
    if (kind == 1) {                 /* connect: real epoch, clears work */
        cur = connection; connected = 1; pend = 0; op = 0;
    } else if (kind == 2) {          /* disconnect: only current */
        if (connected && connection == cur) { connected = 0; pend = 0; op = 0; }
    } else if (kind == 3) {          /* request: current conn only, replaces */
        if (connected && connection == cur) { op = operation; pend = 1; }
    } else if (kind == 4) {          /* sample_ready: keep pending only if matches */
        (void)0;                     /* stale sample_ready is a no-op */
    } else if (kind == 5) {          /* send_done: settle only exact pending pair */
        if (connected && pend && connection == cur && operation == op) {
            deliv++; pend = 0; op = 0;
        }
    } else if (kind == 6) {          /* timeout: cancel only current pending pair */
        if (connected && pend && connection == cur && operation == op) {
            pend = 0; op = 0;
        }
    }
}

int pending(void) { return pend; }
uint32_t connection(void) { return cur; }
uint32_t operation(void) { return op; }
int deliveries(void) { return deliv; }
