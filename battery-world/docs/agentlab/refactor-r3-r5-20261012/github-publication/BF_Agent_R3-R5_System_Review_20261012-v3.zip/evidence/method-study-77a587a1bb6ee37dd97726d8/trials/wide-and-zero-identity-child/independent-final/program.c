#include <stdint.h>
static uint32_t c, op;
static int p, d, conn;

void reset(void){ c=0; op=0; p=0; d=0; conn=0; }

void handle(int k, uint32_t x, uint32_t y){
  if(k==1){            /* connect: install current connection, clear pending */
    c=x; conn=1; p=0; op=0;
  } else if(k==2){     /* disconnect: only for current connection */
    if(conn && x==c){ conn=0; p=0; op=0; }
  } else if(k==3){     /* request: only on current connection, replaces op */
    if(conn && x==c){ op=y; p=1; }
  } else if(k==4){     /* sample_ready: keep current pending pair */
    if(p && x==c && y==op){ p=1; }
  } else if(k==5){     /* send_done: settle only current pending pair */
    if(p && x==c && y==op){ d++; p=0; op=0; }
  } else if(k==6){     /* timeout: cancel only current pending pair */
    if(p && x==c && y==op){ p=0; op=0; }
  }
}

int pending(void){ return p; }
uint32_t connection(void){ return c; }
uint32_t operation(void){ return op; }
int deliveries(void){ return d; }
