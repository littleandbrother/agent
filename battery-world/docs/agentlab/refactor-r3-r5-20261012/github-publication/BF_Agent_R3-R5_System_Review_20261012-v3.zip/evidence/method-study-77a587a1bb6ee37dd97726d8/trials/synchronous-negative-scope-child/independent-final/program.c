#include <stdint.h>

/* Frozen ABI state. Identity is full-width uint32_t; no truncation. */
static uint32_t cur_conn;   /* installed current connection */
static uint32_t cur_op;     /* operation of the pending pair (0 when idle) */
static int has_pending;     /* 1 while a request awaits send_done */
static int is_connected;    /* 0 after reset / disconnect, 1 after connect */
static int n_deliveries;

void reset(void){
    cur_conn = 0u; cur_op = 0u;
    has_pending = 0; is_connected = 0; n_deliveries = 0;
}

void handle(int kind, uint32_t connection, uint32_t operation){
    switch(kind){
    case 1: /* connect: installs current connection, clears pending work */
        cur_conn = connection;
        is_connected = 1;
        has_pending = 0;
        cur_op = 0u;
        break;
    case 2: /* disconnect: only for the current connection */
        if(is_connected && connection == cur_conn){
            is_connected = 0;
            has_pending = 0;
            cur_op = 0u;
        }
        break;
    case 3: /* request: only on current connection, starts/replaces */
        if(is_connected && connection == cur_conn){
            cur_op = operation;
            has_pending = 1;
        }
        break;
    case 4: /* sample_ready: keep pending, nothing to settle */
        break;
    case 5: /* send_done: settle only the current pending pair */
        if(is_connected && has_pending &&
           connection == cur_conn && operation == cur_op){
            n_deliveries++;
            has_pending = 0;
            cur_op = 0u;
        }
        break;
    case 6: /* timeout: cancel only the current pending pair */
        if(is_connected && has_pending &&
           connection == cur_conn && operation == cur_op){
            has_pending = 0;
            cur_op = 0u;
        }
        break;
    default:
        break;
    }
}

int pending(void){ return has_pending; }
uint32_t connection(void){ return cur_conn; }
uint32_t operation(void){ return cur_op; }
int deliveries(void){ return n_deliveries; }
