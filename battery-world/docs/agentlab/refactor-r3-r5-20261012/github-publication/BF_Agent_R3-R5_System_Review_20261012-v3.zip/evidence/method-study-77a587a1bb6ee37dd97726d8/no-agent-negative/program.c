#include <stdint.h>
static uint16_t c,op;static int p,d,connected;
void reset(void){c=op=p=d=connected=0;}
void handle(int k,uint32_t x,uint32_t y){
 if(k==1){c=(uint16_t)x;connected=1;p=0;op=0;}
 else if(k==2){connected=0;p=0;op=0;}
 else if(k==3&&connected&&x==c){op=(uint16_t)y;p=1;}
 else if(k==4){p=1;}
 else if(k==5&&p){d++;p=0;op=0;}
 else if(k==6){p=0;op=0;}
}
int pending(void){return p;}uint32_t connection(void){return c;}
uint32_t operation(void){return op;}int deliveries(void){return d;}
