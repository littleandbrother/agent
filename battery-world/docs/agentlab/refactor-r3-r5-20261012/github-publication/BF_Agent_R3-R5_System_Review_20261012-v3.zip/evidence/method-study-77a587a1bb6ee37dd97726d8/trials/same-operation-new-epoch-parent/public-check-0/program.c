#include <stdint.h>
static uint32_t conn;
static uint32_t pend_conn;
static uint32_t op;
static int connected;
static int has_pending;
static int delivered;

void reset(void){
    conn = 0u; connected = 0; has_pending = 0; pend_conn = 0u; op = 0u; delivered = 0;
}

void handle(int kind, uint32_t x, uint32_t y){
    if (kind == 1) {                 /* connect */
        conn = x; connected = 1;
        has_pending = 0; pend_conn = 0u; op = 0u;
    } else if (kind == 2) {          /* disconnect */
        if (connected && x == conn) {
            connected = 0;
            has_pending = 0; pend_conn = 0u; op = 0u;
        }
    } else if (kind == 3) {          /* request */
        if (connected && x == conn) {
            pend_conn = x; op = y; has_pending = 1;
        }
    } else if (kind == 4) {          /* sample_ready: keep pending, ignore stale */
        /* no state change */
    } else if (kind == 5) {          /* send_done */
        if (has_pending && x == pend_conn && y == op) {
            delivered++;
            has_pending = 0; pend_conn = 0u; op = 0u;
        }
    } else if (kind == 6) {          /* timeout */
        if (has_pending && x == pend_conn && y == op) {
            has_pending = 0; pend_conn = 0u; op = 0u;
        }
    }
}

int pending(void){ return has_pending; }
uint32_t connection(void){ return conn; }
uint32_t operation(void){ return op; }
int deliveries(void){ return delivered; }
