#include <stdint.h>
static uint32_t c,o;static int p,d,connected;
void reset(void){c=o=0;p=d=connected=0;}
void handle(int k,uint32_t x,uint32_t y){
 if(k==1){c=x;connected=1;p=0;o=0;}
 else if(k==2&&connected&&x==c){connected=0;p=0;o=0;}
 else if(k==3&&connected&&x==c){o=y;p=1;}
 else if(k==4&&p&&x==c&&y==o){d++;}
 else if(k==5&&connected&&p&&x==c&&y==o){d++;p=0;o=0;}
 else if(k==6&&connected&&p&&x==c&&y==o){p=0;o=0;}
}
int pending(void){return p;}uint32_t connection(void){return c;}
uint32_t operation(void){return o;}int deliveries(void){return d;}
