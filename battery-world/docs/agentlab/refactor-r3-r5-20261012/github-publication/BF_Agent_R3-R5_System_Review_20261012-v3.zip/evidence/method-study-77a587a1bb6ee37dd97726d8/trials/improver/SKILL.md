---
name: bf-callback-identity
version: H-method-495f8cec8544379ace120d688d38f7554c94b3d1b1ffb5a11b1e9075ea05ea4c
---
当事件驱动 ABI 以 (connection, operation) 标识回调身份、且身份定义为精确 uint32 相等（含 0 与大于 65535 的值）时：任何事件处理前先用全宽 uint32 分别锁存当前 connection、当前 pending 对与 operation，不得降位或截断；request 仅在当前连接上开启/替换操作；sample_ready 只保持 pending 不结算；仅匹配当前 pending (connection,operation) 的 send_done 才结算并 deliveries+1，timeout 只取消当前 pending 对；一切 stale 的 callback/disconnect/timeout 一律 no-op 且不改变状态；connect 安装当前连接并清空 pending（含 connect(0) 作为一次真实连接）；空闲时 pending=0、operation=0。
