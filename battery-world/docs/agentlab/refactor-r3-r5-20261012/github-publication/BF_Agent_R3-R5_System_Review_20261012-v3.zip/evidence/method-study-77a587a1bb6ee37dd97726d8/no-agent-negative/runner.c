#include <stdio.h>
#include <stdint.h>
void reset(void);void handle(int,uint32_t,uint32_t);
int pending(void);uint32_t connection(void);uint32_t operation(void);int deliveries(void);
int main(void){int k;unsigned x,y;reset();while(scanf("%d %u %u",&k,&x,&y)==3){
if(k==0){reset();continue;}handle(k,x,y);printf("%d %u %u %d\n",pending(),connection(),operation(),deliveries());}return 0;}