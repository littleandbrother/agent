#include <stdint.h>

static uint32_t conn;   /* current connection identity (full width) */
static uint32_t pconn;  /* pending pair: connection */
static uint32_t pop;    /* pending pair: operation */
static int connected;
static int p;
static int d;

void reset(void){
    conn = 0; pconn = 0; pop = 0; connected = 0; p = 0; d = 0;
}

void handle(int kind, uint32_t connection, uint32_t operation){
    if (kind == 1) {                 /* connect: installs current, clears pending */
        conn = connection;           /* connect(0) is a real connected epoch */
        connected = 1;
        p = 0; pconn = 0; pop = 0;
    } else if (kind == 2) {          /* disconnect */
        if (connected && connection == conn) {
            connected = 0;
            p = 0; pconn = 0; pop = 0;
        }                            /* stale disconnect: no-op */
    } else if (kind == 3) {          /* request */
        if (connected && connection == conn) {
            pconn = conn;
            pop = operation;         /* full uint32, exact equality */
            p = 1;
        }                            /* wrong/disconnected connection: no-op */
    } else if (kind == 4) {          /* sample_ready: keeps pending, never settles */
        if (p && connection == pconn && operation == pop) {
            /* no state change */
        }                            /* stale sample_ready: no-op */
    } else if (kind == 5) {          /* send_done: settles only exact pending pair */
        if (p && connection == pconn && operation == pop) {
            d++;
            p = 0; pconn = 0; pop = 0;
        }                            /* stale send_done: no-op */
    } else if (kind == 6) {          /* timeout: cancels only exact pending pair */
        if (p && connection == pconn && operation == pop) {
            p = 0; pconn = 0; pop = 0;
        }                            /* stale timeout: no-op */
    }
}

int pending(void){ return p; }
uint32_t connection(void){ return conn; }
uint32_t operation(void){ return pop; }
int deliveries(void){ return d; }
