#include <stdint.h>
/* Async event core for the frozen ABI.
   Events: 1=connect 2=disconnect 3=request 4=sample_ready 5=send_done 6=timeout.
   Exactly one pending (connection, operation) pair at a time; identity is exact
   uint32 equality. Stale callbacks/disconnect/timeout leave state intact. */
static uint32_t conn_id;   /* current connection id (valid while connected) */
static uint32_t op_id;     /* pending operation id (valid while pending) */
static int connected;      /* 1 = a connected epoch is active */
static int pending_flag;   /* 1 = an operation is in flight */
static int delivery_count;

void reset(void){
 conn_id=0; op_id=0; connected=0; pending_flag=0; delivery_count=0;
}
void handle(int kind,uint32_t connection,uint32_t operation){
 switch(kind){
  case 1: /* connect: install connection, clear pending work */
   conn_id=connection; connected=1; pending_flag=0; op_id=0; break;
  case 2: /* disconnect: only the current connection cancels */
   if(connected&&connection==conn_id){connected=0;pending_flag=0;op_id=0;}
   break;
  case 3: /* request: only on the current connection; starts/replaces */
   if(connected&&connection==conn_id){op_id=operation;pending_flag=1;}
   break;
  case 4: /* sample_ready: valid pair keeps the request pending (no state change) */
   break;
  case 5: /* send_done: completes the pending pair exactly once */
   if(connected&&pending_flag&&connection==conn_id&&operation==op_id){
    delivery_count++; pending_flag=0; op_id=0;
   }
   break;
  case 6: /* timeout: cancels the pending pair */
   if(connected&&pending_flag&&connection==conn_id&&operation==op_id){
    pending_flag=0; op_id=0;
   }
   break;
  default: /* unknown/out-of-scope kind: leave state intact */
   break;
 }
}
int pending(void){return pending_flag;}
uint32_t connection(void){return conn_id;}
uint32_t operation(void){return op_id;}
int deliveries(void){return delivery_count;}
