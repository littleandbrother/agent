#include <stdio.h>
/* Deterministic reference controller. Times and current envelopes are in the task.
 * Revised for a 47 uF buffer: the first frame is placed after the storage
 * charge-settling time (~1.2 s at 47 uF), then frames are spaced 4 s apart
 * (>3x the measured burst-recharge time) so all four land by t=14 s. */
int main(void) {
    puts("t_s,duration_s,state,seq,value,crc");
    for (unsigned seq = 1; seq <= 4; ++seq) {
        double start = 2.0 + 4.0 * (seq - 1);
        unsigned value = 2500;
        unsigned crc = (seq ^ value ^ 0xA5) & 255;
        printf("%.6f,0.010000,sample,%u,%u,%u\n", start, seq, value, crc);
        printf("%.6f,0.004000,tx,%u,%u,%u\n", start + 0.011, seq, value, crc);
    }
    return 0;
}
