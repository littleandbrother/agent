#include <stdio.h>
/* Deterministic reference controller (R7 service schedule, unchanged from R6).
 * Times and current envelopes are in the task. Frames sit at 2/6/10/14 s:
 * the first frame is later than the 68 uF charge-settling time (~1.6 s) and the
 * 4 s spacing is >3x the measured burst-recharge time (~1.0-1.2 s). */
int main(void) {
    puts("t_s,duration_s,state,seq,value,crc");
    for (unsigned seq = 1; seq <= 4; ++seq) {
        double start = 2.0 + 4.0 * (seq - 1);
        unsigned value = 2500;
        unsigned crc = (seq ^ value ^ 0xA5) & 255;
        printf("%.6f,0.010000,sample,%u,%u,%u\n", start, seq, value, crc);
        printf("%.6f,0.004000,tx,%u,%u,%u\n", start + 0.011, seq, value, crc);
    }
    return 0;
}
