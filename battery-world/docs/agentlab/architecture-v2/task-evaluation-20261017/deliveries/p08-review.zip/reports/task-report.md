P08 · 一级降压模型复核

复核 P08 原生一级降压模型在六个初始输出电压下的电流衰减时长，与论文 Note S13 对照；从任务定义完成到同版审查交付。

System: SC-7d474cd25fed8ac3056195d36458749facea261ed665ff3baf64310991b2737f
Scope: curve-reproduction
Result: PASS

通过：六点电流衰减时长相对论文 Note S13 的最大偏差 0.5264707728290006%（限值 1%），curve_binding / curve_accuracy / delivery_version 三门 PASS，判定 ADOPT_PASSED。这是模型级复核（原生一级降压 LC 阶段读回），不是硬件验收，也不构成整机通过声明。

## target_and_conditions

目标：复核 P08 原生一级降压模型在 0.5/1/2/4/8/16 V 六个初始输出电压下的电流衰减时长，与论文 Note S13 pp27-28 对照。固定条件（算子绑定，不属设计自由）：current_cutoff = 0.001 A（提取判据：最后一个 |i_L| > 1 mA）；paper_durations = [473,379,272,175,103,56] us（x=0.5/1/2/4/8/16 V）。坐标语义：x 单位 V，y 单位「占论文时长的百分比」，reference.csv 即 100% 基准线。原始波形来源：raw_source_job eng-19eb09030ae354a8，raw_sha256 597413343e2f6869bf82a84ea39440bf7be73ba55ab93063eae95499727daab8，55305 点，原始结果复用（raw_reused=true，new_native_runs=0），本次未启动任何原生仿真、未派发原生作业。

Sources: reference.csv, notes/source-readback.json, notes/requirements.json

## curves_and_error

执行 TX-75d0527b0f316bb7188cddf8cb1e0de802278f52dd1e3951bcef298edd1ae1c8（执行键 EX-8c026a37f905d7bdfe277915dcca17309aedab5f622a8bbe5c1adb6d0691b57f，适配器 tabulated-curve-v1，SUCCEEDED，复用已有原始结果）产出 samples.json，六对同 x 采样点、y 有限：0.5 V 100.526470772829、1.0 V 100.251304392776、2.0 V 100.252692608823、4.0 V 100.148358036183、8.0 V 99.579514697081、16.0 V 100.253525480248，对照 reference.csv 的 100。最大绝对偏差 0.5264707728290006（0.5 V 点，+0.53%），其余 +0.15%…+0.25%，8 V 点 −0.42%，全部远低于 1 的限值；对应原生时长 475.49/379.95/272.69/175.26/102.57/56.14 us 对论文 473/379/272/175/103/56 us。六个电压点齐全、无缺失或外推点，误差为配对采样误差，未做任何插值或轨迹外推。

Sources: observation.csv, curve_accuracy, curve_binding

## conclusion_and_files

结论与文件：curve_accuracy PASS（max_abs_error 0.5264707728290006 ≤ 1），curve_binding PASS（六点同轴，原始波形来源哈希一致），delivery_version PASS（6 个文件、任务定义 TD-de48fa… 绑定本候选 SC-7d474c…），三门与判定 DA-277ffbc1ba857cabb950920667ac0e4917487ffc37fa53c9cc3b7dc7d82810d7 同版。候选文件：observation.csv（sha256 02412f27a71132aa97aeef88232a1fe1e058489d274ef10eff28d20fdb45d8ed）、reference.csv（13d25b542dbff0a3ea2daf885beee9b187063830161b38f84c09104319d2bc01）、notes/source-readback.json（683881e811ef8db727e633f23f5f9d285c822b1bfa5d8b0753575fd6c3367421）、notes/requirements.json、notes/interfaces.json、notes/original-scope.md。原论文整机中尚未覆盖的环节（与冻结来源一致，逐项列出不计入本任务通过范围）：1) TENG 源物理与机械输入——冻结集无 C(x)/V(x) 曲线，能量坍塌与空气击穿不可评估，1500 V 预充为 GDT 阈值的理想化，源未标定；2) GDT 本身——论文自身在仿真中以压控开关替代，双方均无精确 GDT 模型；3) 次级 LTC3588-2（5.0/3.45 V）与级联 LTC3588-1（2.5/1.8 V）两级变换、基准电路与负载——均未建模；4) 0.0257/0.0200 V 至 0.05 V 区间无原生点，首个调节时刻与循环计数为 not_evaluable，0→3.45 V 轨迹不作外推；5) 板级高压：50 um PI 膜与焊盘间距 d12/d13/d23/d14/d25 仅有几何包络与间隙检查，无爬电/绝缘仿真；6) 旋转电极间隙 1.5/2 mm 与滚动气隙 5 mm 未在包络内解决；7) 原生 EDA（原理图/PCB）绑定不可用，固件不适用（论文能量路径无 MCU）；8) 能量与效率数值各保持自身工作点与分母，本次未做效率再评估。以上均为本候选的声明边界，无任一环节被声称通过。

Sources: curve_accuracy, curve_binding, delivery_version, notes/original-scope.md, notes/interfaces.json
