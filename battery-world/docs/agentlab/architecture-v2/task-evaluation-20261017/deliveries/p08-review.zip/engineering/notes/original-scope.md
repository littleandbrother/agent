# P08 primary-stage circuit reconstruction - native read-back report

Paper: `10.1038/s41467-026-78002-0` (multi-stage buck PMC for TENGs), paper_id `P08`.
Native jobs (assembly revision 2, kind `spice`, all re-derived here):

| job | native input | raw | sha256 | points | t_stop |
|---|---|---|---|---|---|
| `eng-19eb09030ae354a8` | Note S13 rolling operating point (0.5-16 V sweep + circuit A full cycle) | `engineering-artifacts/eng-19eb09030ae354a8/project-trace.raw` | `597413343e2f6869bf82a84ea39440bf7be73ba55ab93063eae95499727daab8` | 55305 | 800 us |
| `eng-82f5b127254c5dca` | **new this round** - Note S17 rotary primary (Cin 0.22 nF / 3000 V / 4 series diodes; R0 full cycle from Cout = 0 V, R1-R4 phase-2 rows) | `engineering-artifacts/eng-82f5b127254c5dca/project-trace.raw` | `5e76eaf589278c66166fe68a616eb6065f416c77e5ff92bf228bdad509579f67` | 83502 | 800 us |
| `eng-91df1b20523de2f5` | **new this round** - same rolling phase-2 model with the low-output initial states Note S13 does not sample (Cout0 = 0.05/0.10/0.20/0.30/0.40 V) | `engineering-artifacts/eng-91df1b20523de2f5/project-trace.raw` | `7cbf9009c0b2c8e990625e602c430251726dbca8898a1c7a8024ba87e8c4aaaa` | 60302 | 1600 us |

Every number below is re-derived from those raw files by `analyze.py` and `chain-accounting.py`;
the branch split in section 1.1 is re-derived a second time by `branch-accounting.py` from the
same raw. Outputs: `analysis-spice/metrics.json`, `branch-accounting.json`,
`chain-accounting.json`, `spice-results.csv`.

## 0. Model boundary (explicit, not a whole-system claim)

* Modelled: the **primary LC stage only** - `Cin(440 pF, 1500 V pre-charge) -> HV switch -> L(1 mH, Rint 1.82 ohm) -> freewheel diode string -> Cout(10 mF)`, parameters as stated in SI Note S13 p.27.
* The paper itself replaces the GDT with a *voltage-controlled switch* in its simulation
  (Note S13 p.27); this netlist does the same and uses Note S13's own diode description
  (`Vdiode = 0.83 V`, number of series diodes varied). **No precise GDT model exists in either work.**
* *Not* modelled: the TENG charge-generation physics, its internal capacitance/impedance and the
  mechanical input; the secondary LTC3588 stage; the load. The 1500 V pre-charge is an
  idealisation of the GDT firing threshold, i.e. the source is **not calibrated**.
* Secondary path as the frozen source states it (SI p.36, Figs S22/S24), not as one part:
  the harvested source feeds the primary stage through the GDT, the **LTC3588-2** produces the
  5.0 V and 3.45 V rails directly (path 1.5/2.5/3.0 kV -> 16 V -> 5.0/3.45 V), and for the
  **2.5 V / 1.8 V rails an LTC3588-1 is cascaded after the LTC3588-2** (path 1.5/2.5/3.0 kV ->
  16 V -> 4.1 V -> 2.5/1.8 V; only the -1 accepts 4 V input). Neither chip is represented here
  and no secondary conversion, no reference circuit and no load is simulated.
* Efficiency figures of the source **with the denominator and condition the frozen text gives
  for each one** (F4 repair; an earlier revision wrongly said the paper gives no denominator):

| reported figure | frozen source | denominator / condition it is quoted against |
|---|---|---|
| primary circuit max **90.9% at 16 V** | abstract; Note S3 p.6; Table S3 p.39 | primary stage only; per-firing input energy **495 uJ = 0.5*Cin*V^2**, Cin 440 pF, V 1500 V (Note S13 p.27, Fig S16H-J) |
| **77.3%** primary circuit, rotary device, 18.4 V output | Note S17 p.45 | rotary operating point: GDT frequency 22.1 Hz, **Cin 0.22 nF**, **V_GDT 3000 V** -> stated input power **21.88 mW** = 0.5*Cin*V^2*f (= 990 uJ per firing); four series diodes; the same note says the primary circuit is *below 80% at 16 V* |
| overall **75.6 / 86.5 / 85.28%** at 1.8 / 3.45 / 5.0 V | Table S2 p.38 (five runs each: 75.3-76.3 / 85.9-87.4 / 85.0-85.4%) | whole-system source-to-regulated-output efficiency, two-chip path of SI p.36 (LTC3588-2 alone for 5.0/3.45 V; LTC3588-2 then cascaded LTC3588-1 for 2.5/1.8 V); the same page quotes 75.3% for the 1.8 V rail against 57.6% when only the LTC3588-1 is used |

  What the frozen text still does **not** enumerate is the loss breakdown inside the overall
  efficiency and the measured input energy per firing of the *rotary* device; and our own
  modelled 88.8% at 16 V (section 2) is `E_out / 495 uJ` for a one-diode, ideal-switch primary
  stage of the *contact-separation* device, i.e. a different quantity from the 90.9%/77.3% rows
  above, so it is quoted next to them and **not** as agreement.
* `Rint`, `L`, `Cin`, `Cout`, `Vdiode` are paper-stated model constants, not measured device data.
  The 495 uJ input energy is stated in Note S13 p.27 (Fig S16H-J), not in Table S2.
* No value here is a measurement, a device qualification or a product-pass statement.

## 1. Complete primary cycle (`circuit A`: Cin 1500 V, Cout starts at 0 V, one diode)

| quantity | native | paper | deviation |
|---|---|---|---|
| peak current Imax | 0.9943 A | 0.995 A (Note S13/Eq. 27) | -0.07% |
| time to Imax | 1.0719 us | - | - |
| first ring half-period | 2.1438 us | - (undamped LC predicts 2.084 us) | - |
| diode clamp (switching node min) | -0.855 V | Vdiode 0.83 V | - |
| switch terminal voltage max | 0.0010 V | - | - |
| current at 10 / 100 us | 0.9708 / 0.7542 A | decaying (Fig S16C) | - |
| min current after peak | -3.93e-04 A | - | - |
| V(Cin) at end | -0.399 V | - | - |
| V(Cout) at end (= after ONE firing from 0 V) | 0.0257 V | - | - |

### 1.0 Terminal energy ledger over the whole cycle

Branches and signs (`analyze.py` header): `i_L = i(l_a)`; `i_bsw = G(V(nA1))*(V(nA1)-V(nA2))`
taken from the netlist's own `Bsw_A` equation; `i_d = i_L - i_bsw` from KCL at node nA2
(anode = ground, cathode = nA2, so positive `i_d` = forward conduction).  Each entry is
`integral (v_a - v_b)*i_branch dt` over the stated window, positive = absorbed by the branch.

| term | window | value [uJ] | share of 495 uJ |
|---|---|---|---|
| E_cin_initial_uJ | input, 0.5*Cin*1500^2 (not an integral) | 495 | 100.000% |
| E_R_int_uJ | Rint, inductor branch, full trace | 281.358 | 56.840% |
| E_diode_terminal_uJ | diode branch (KCL), full trace | 210.354 | 42.496% |
| E_switch_terminal_uJ | switch branch (netlist eq.), full trace | 0.013301 | 0.003% |
| E_out_uJ | Cout 0 -> 0.0257 V, full trace | 3.29697 | 0.666% |
| E_cin_residual_uJ | Cin at end, full trace | 3.49937e-05 | 0.000% |
| E_ind_stored_uJ | L at end, full trace | 5.85417e-06 | 0.000% |
| **closure residual** | input minus the six sinks/stores | -0.0227 uJ | **-0.0046%** |

Readings:

* Peak current reproduces Eq. 27 / the paper's 0.995 A to -0.07%; the ring that rises it is the
  `Cin-L` resonance (undamped half-period 2.08 us, simulated 2.14 us).
* The inductor current decays from Imax 0.9943 A to zero at 645.37 us (RL freewheel, one sign), so
  the topology direction claim holds for the *freewheel* branch and the stored energy is
  delivered to the reservoir by then. The residual tail (i_L down to -3.932e-04 A, 0.040% of Imax, node
  ring -0.58..0.62 V) is analysed in 1.1 and is **not** attributed here.
* In **this** model the switch branch absorbs 0.01330 uJ versus 281 uJ (Rint) and 210 uJ (diode),
  i.e. it reproduces Note S13's statement that the switch loss is much smaller than the resistor
  and diode losses. It is a *model-to-model* agreement, not GDT validation.
* One 1500 V firing into a 10 mF reservoir that starts at 0 V delivers only 3.30 uJ (0.67% of
  495 uJ), because at ~0 V the current is burned in Rint (281 uJ) and in the diode branch (210 uJ).
  This corner is **not** the paper's 77.3% primary efficiency (Note S17 p.45, Fig S30G/S31): the
  denominators differ by construction (see the section-0 table). 3.30 uJ / 495 uJ = 0.67% here,
  where 495 uJ is the energy this model fires from Cin; the paper's 77.3% is quoted for the
  *rotary* device at 18.4 V output with 0.22 nF Cin, 4 series diodes, 3000 V and 22.1 Hz, i.e.
  against 21.88 mW input power. Neither number is used to judge the other.

## 1.1 Branch attribution of the same saved trace (switch branch, diode branch, tail)

**Correction of the previous revision (F2/F3).** The earlier text took `i(l_a)` to *be* the
switch-branch current and the diode current. It is neither: at node nA2 Kirchhoff gives
`i_d = i_L - i_bsw`, and `i_bsw` is fixed by the netlist's `Bsw_A` equation. Window definitions
come from the trace itself (current peak 1.0719 us = start of the clamp; zero crossing 645.37 us =
end of the freewheel), not from a measurement of commutation.

| branch | window | branch charge [uC] | terminal energy [uJ] |
|---|---|---|---|
| switch `Bsw_A` (netlist eq. `G(V(nA1))*(V(nA1)-V(nA2))`) | full trace | 0.6545 | 1.330097e-02 |
|   of which transfer phase | 0 - 1.0719 us | - | 4.982869e-04 |
| freewheel diode `Dfw_A` (KCL `i_d = i_L - i_bsw`) | forward-biased 1.07 - 645.36 us | 256.092 | 210.68 |
| the same diode branch | full trace (includes commutation edges) | 256.132 | 210.35 |
| tail | 645.37 - 800 us, i_L < 0 | 0.0166 (returned) | 8.561e-09 (returned) |

Labelled contrast (the proxy used before this repair, `i(l_a)` in place of the branch current):
switch branch would read 5.160994e-04 uJ instead of 1.330097e-02 uJ, and the diode window would read 210.62 uJ
instead of 210.68 uJ. The switch figure changes by ~25x, which is why the substitution mattered.

Two facts that must not be conflated:

* The diode-branch figure above is a **terminal** energy: the KCL current contains the
  junction-capacitance (displacement/recovery) contribution of the model's diode as well as
  conduction, so it is **not** a pure heat-dissipation number. The full-trace value (210.35 uJ) is
  below the forward-window value (210.68 uJ) precisely because the reconstruction includes the
  negative-going displacement current at the commutation instant.
* Cross-check with the paper's own constant-drop convention (Note S13 p.28, `Vdiode = 0.83 V`):
  `0.83 V * 256.092 uC = 212.56 uJ` against the forward-window terminal energy 210.68 uJ, i.e. +0.89%;
  the running drop is a little below 0.83 V once the current decays (mean 0.799 V over the window).

**Tail - attribution UNDETERMINED (F3 repair).** The previous revision asserted categorically
that the tail is *not* reverse diode conduction. Measured facts from the same samples:

| quantity | value |
|---|---|
| i_L minimum in the tail | -3.9319e-04 A (0.040% of Imax) |
| switch-branch current at the end of the trace | -1.0794e-04 A |
| KCL diode-branch current at the end of the trace | -2.6587e-07 A |
| max abs(KCL diode current) anywhere in the tail | 6.494e-05 A (0.0065% of Imax) |
| node voltage range in the tail | -0.584 .. 0.617 V |

What follows from that, and what does not: the tail current is carried by the **switch branch**
of *this* model (the behavioural switch keeps G ~ 5e2 S near V(nA1) ~ -0.4 V), and the
KCL-reconstructed diode current there is <= 0.007% of Imax. But no `i(device)` probe is saved,
so (a) the conduction/displacement split *inside* the diode branch, (b) whether a physical GDT
would leave the same tail, and (c) whether any part of it is reverse conduction, are **not**
identifiable from this raw file. The inductor's negative tail flow, the diode port current and
the internal conduction/displacement components are therefore reported as separate measured
quantities, and the attribution is left **undetermined**. See `UNVERIFIED.md` #12.

## 2. Phase-2 sweep: RL decay charging the reservoir (L pre-charged to 0.995 A)

**Domain (read first).** Every row of this sweep is the paper's *phase-2* model: the inductor is
pre-charged to the paper's Imax = 0.995 A and circuits `B1`-`B8` contain **no switch, no GDT and
no Cin**, so the source here is the pre-charged L, not a TENG or a fired GDT, and the reservoir
starts at Vout0 (its energy 0.5*Cout*Vout0^2 is outside the budget, which is why `E_out` is the
*delivered* energy). In those sub-circuits the diode cathode node has only two branches, so KCL
gives `i_d = -i(l_b*)` exactly and the inductor current *is* the branch current (the figure
below still includes the model diode's junction-capacitance edges).

**The 0.5 V row is not a substitute for the 0 V first extraction of section 1**: it is a
pre-charged-L initial condition (its own `E_RL_initial` = 0.5*L*0.995^2 = 495.0 uJ), whereas the
0 V case is a full Cin transfer in which Rint (281 uJ) and the diode branch (210 uJ) consume
most of the firing and only 3.30 uJ reaches the reservoir. The zero-voltage extraction is
therefore listed on its own (section 4) and is not called a cold start.

| Vout0 [V] | T native [us] | T paper [us] | dev | Imax [A] | E_out [uJ] | E_Rint [uJ] | E_diode [uJ] | E_out/495 uJ | closure |
|---|---|---|---|---|---|---|---|---|---|
| 0.5 | 475.49 | 473 | +0.53% | 0.9950 | 102.81 | 226.21 | 165.99 | 20.8% | 0.0001% |
| 1.0 | 379.95 | 379 | +0.25% | 0.9950 | 168.01 | 189.68 | 137.32 | 33.9% | 0.0001% |
| 2.0 | 272.69 | 272 | +0.25% | 0.9950 | 249.01 | 143.62 | 102.38 | 50.3% | 0.0001% |
| 4.0 | 175.26 | 175 | +0.15% | 0.9950 | 330.12 | 96.84 | 68.05 | 66.7% | 0.0002% |
| 8.0 | 102.57 | 103 | -0.42% | 0.9950 | 395.48 | 58.71 | 40.82 | 79.9% | 0.0003% |
| 16.0 | 56.14 | 56 | +0.25% | 0.9950 | 439.46 | 32.86 | 22.69 | 88.8% | 0.0003% |

The six durations and the `Imax ~ 0.995 A` invariance reproduce Note S13 p.28 to better than
0.6%, and the qualitative trend Note S13 states for Fig S16H-J (diode and Rint loss fall, useful
output rises with Vout) is reproduced quantitatively: E_Rint 226 -> 33 uJ and E_diode 166 -> 23 uJ
while E_out rises 103 -> 439 uJ. Energy closure per variant stays at 0.0001%.

At the 16 V row this model delivers 88.8% of the 495 uJ stored on Cin; the source quotes 90.9%
as the primary-circuit maximum at 16 V and *below 80%* at 16 V for the 4-diode rotary case with
a different Cin (0.22 nF) and a 21.88 mW input (section 0 table). Same order of magnitude, but
these rows use one diode, so this is an observation put next to the paper's numbers, not agreement.

## 3. Series-diode variants (low output voltage, Vout0 = 0.5 V)

| diodes | T [us] | vs 1 diode |
|---|---|---|
| 1 | 475.49 | - |
| 2 | 339.44 | -28.6% |
| 3 | 264.76 | -44.3% |

Direction of the effect matches Note S13. The rotary application uses **4 series diodes** to
stand off 3000 V (Note S17 p.45); that operating point is *not* simulated - only extrapolable.

## 4. Zero-voltage first event and the domain of this analysis (F1 repair)

The only **native** zero-voltage extraction in this workspace is circuit A, listed on its own:

| quantity | value |
|---|---|
| input fired from Cin (0.5*440 pF*1500^2) | 495.0 uJ |
| delivered to Cout in that first event | **3.29697 uJ** |
| Cout voltage after that one event (from 0 V) | 0.02568 V |
| share of the 495 uJ per-firing input | 0.666% |
| called a calibrated cold start? | no |

**Correction of the previous revision.** An earlier version extrapolated a cycle-to-cycle
trajectory and reported *253 cycles* to 3.45 V (plus a 1000-cycle voltage) by evaluating the
native `E_out(Vout)` table at v = 0, which returned the **0.5 V phase-2 row (102.8136 uJ)** and
then iterated it. That is invalid: the 0.5 V row is a different initial condition (pre-charged
L, no switch, no Cin), and it overstates the energy a 0 V reservoir receives by a factor of
~31x. The trajectory, the 253-cycle count and the 1000-cycle figure have been **removed**.

Native coverage of the reservoir voltage actually is:

| Vout0 [V] | native row |
|---|---|
| 0 (one firing, circuit A) | yes - section 1 (3.30 uJ -> 0.0257 V) |
| 0.5 | yes - section 2 |
| 1 | yes - section 2 |
| 2 | yes - section 2 |
| 4 | yes - section 2 |
| 8 | yes - section 2 |
| 16 | yes - section 2 |
| 0.0256787 - 0.5 (between the first event and the lowest sweep row) | **no native point** |

Consequently `cycles_to_3p45V = not_evaluable`: only one native zero-voltage extraction exists (3.296968 uJ -> 0.0257 V); the phase-2 rows start at Vout0 = 0.5 V and come from a pre-charged-L model with no switch and no Cin, so no native point covers (0.0257, 0.5) V and any cycle count would be an extrapolation, not a result.
No cycle count, no extrapolated trajectory and no steady-state claim is made for the
0 -> 3.45 V region; that region stays **not evaluable** from this raw file.

## 5. Source -> primary -> secondary -> load chain accounting (new in this round)

Driver: `chain-accounting.py` -> `chain-accounting.json`, over the same raw files as sections
1-4 plus the two new raw files above. It closes the *link* between source, primary extraction,
reservoir accumulation and the published load end, and marks every link that has no evidence.
Nothing here is a cold start, a source calibration or a product-pass statement.

### 5.1 Source end (paper scalars, cross-checked - no new physics)

| quantity | rolling | rotary |
|---|---|---|
| Cin at the firing voltage | 440 pF (Note S13 p.27) | 0.22 nF (Note S17 p.45) |
| V_GDT | 1500 V | 3000 V |
| **Q per firing = Cin*V** | **0.660 uC** | **0.660 uC** |
| **E per firing = 0.5*Cin*V^2** | 495.0 uJ | 990.0 uJ |
| GDT firing rate | not published (Table S5 3 Hz is a device figure) | 22.1 Hz |
| P_in = E*f | not derivable | **21.879 mW** vs published **21.88 mW** (-0.005%) |
| series diodes | 1 | 4 (to stand off 3000 V) |

Both devices transfer the **same** charge per firing (0.660 uC) although the rotary source energy is
2x. The published rotary input power is reproduced exactly as E_per_firing * f_GDT. Order-of-
magnitude check: sigma 800 uC/m2 (Fig S30D) x 13.1 cm2 (Table S5 p.48) = 1.048 uC of surface
charge vs 0.660 uC per firing (ratio 0.63) - a consistency check, **not** a charge-cycle model.
Source model depth as available in the frozen sources: NOT AVAILABLE: the frozen sources contain no C(x) or V(x) curve, so the source is only the two scalars above; energy collapse / air-breakdown behaviour is UNEVALUABLE.

### 5.2 Primary stage per firing (native)

Rotary operating point, phase-2 model (L pre-charged to Imax = 1.4071 A), Cout 10 mF:

| row | diodes | T [us] | E_out [uJ] | E_Rint [uJ] | E_diode terminal [uJ] | E_out / 990 uJ | closure |
|---|---|---|---|---|---|---|---|
| R1, Vout0 = 18.4 V | 4 | 61.36 | 777.08 | 71.36 | 141.52 (140.19) | **78.5%** | -0.0013% |
| R2, Vout0 = 16 V | 4 | 68.50 | 752.89 | 79.41 | 157.67 (156.20) | **76.0%** | -0.0011% |
| R3, Vout0 = 16 V | 1 | 77.85 | 855.07 | 90.13 | 44.76 (44.35) | **86.4%** | -0.0012% |
| R4, Vout0 = 4 V | 4 | 165.65 | 439.88 | 182.38 | 367.70 (364.60) | **44.4%** | -0.0003% |

Same-denominator comparison with Note S17 p.45 (denominator = per-firing source energy, i.e.
this work's etaPMC definition): the source quotes **77.3%** primary efficiency at 18.4 V and our
phase-2 row gives **78.5%** - 1.2 points apart, same order, but that row omits the switch phase
and the GDT loss, so it is put next to the paper's number, not as agreement. Both qualitative
statements of that note are reproduced in direction: *below 80% at 16 V* (model 76.0% with four
diodes) and *efficiency falls below 5 V* (model 44.4% at 4 V).

First event from an **empty** reservoir at the rotary point (R0, complete cycle, Cin pre-charged):

| quantity | rotary R0 | rolling circuit A (sections 1/4) |
|---|---|---|
| input fired from Cin | 990.0 uJ | 495.0 uJ |
| E delivered to Cout (starts at 0 V) | **1.99261 uJ** | **3.29697 uJ** |
| Cout voltage after the event | 0.01996 V | 0.02568 V |
| share of the per-firing input | 0.201% | 0.666% |
| diode string voltage at Imax | 3.51 V (4 series) | 0.85 V |
| closure | -0.106% | -0.0046% |

The rotary first extraction is **smaller** than the rolling one although its source energy is 2x,
because four series diodes must be forward biased - the mechanism the paper gives for the rotary
primary being more constrained at low output voltage. **Neither row is a cold start**: Cin is
pre-charged in both, which is the paper's own initial condition (Note S13 p.27), and no GDT
self-start model exists in the frozen sources.

### 5.3 External reservoir accumulation (model result, not a cold start)

Paper's own storage relation (Note S18 p.49: E = 0.5*Cout*(Vmax^2 - Vmin^2)) applied to the
native per-firing delivered energy dE(V) - now covered from 0.05 V upwards by the new low-
output raw - i.e. V'^2 = V^2 + 2*dE(V)/Cout:

| Cout | 0.5 V | 1 V | 2 V | 4 V | 8 V | 16 V |
|---|---|---|---|---|---|---|
| 10 mF (Note S13 p.27) | 23 | 50 | 122 | 327 | 984 | **3272** |
| 1 mF (Note S18 p.49) | 4 | 7 | 14 | 35 | 101 | **330** |

The frozen text uses **both** capacitances (10 mF in the LC calculation, 1 mF as "the storage
capacitor"); both are reported because the count depends on the choice. With the new low-output
rows there is no longer a hole between the first event and 0.5 V, so these counts are inside the
covered range; the remaining hole is stated below. Ripple self-consistency: at 16 V one firing
changes a 10 mF reservoir by dV = dE/(Cout*V) = 2.7 mV, far below any switching band, so the
quasi-static accumulation is internally consistent - still **not** a hold-up or transient claim.

**Remaining hole (kept, not filled by extrapolation):** the first event leaves the reservoir at
0.01996 V (rotary) / 0.02568 V (rolling) while the native dE(V) curve starts at 0.05 V, so the region
(0.02568, 0.05) V has no native point; the exact number of *first* firings and any time-to-first-
regulation stay `not_evaluable` (`metrics.json`), and the counts above are the reservoir-filling
model result from the covered range.

### 5.4 Secondary stage and load end (paper scalars; arithmetic cross-checked)

Rolling build (Table S5 p.48 row + measured path efficiency Table S2 p.38): 10.89 mA at 1.85 V over
43.8 cm2 reproduces the paper's own densities - 2.486 A/m2 (paper 2.49) and 4.600 W/m2 (paper 4.60);
P_out = 20.15 mW; at the measured 75.6% path efficiency this implies 26.65 mW input, i.e. a
**conditional** GDT rate of 53.8 Hz at 495 uJ per firing. Whether the rolling device fires that
often