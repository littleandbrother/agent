常规压电节点 · 名义参考链

在声明的振动、初始储能和 20 秒窗口内完成至少 3 次有效采样与接收；比较机械参数、储能或固件调度的修订。

System: SC-f922e8e8b0b9da6909a8268623bedfa5ecbb51a46b218fd8412fd984aef14f4d
Scope: nominal-reference-chain
Result: PASS

保留审查（RETAIN_FOR_REVIEW）：在固定场景 + 声明式初始储能 2.5 V 下，默认参考链四门检查仍全 PASS（复用 TX-84f4ff52，本轮未改 design.json / firmware/main.c）；但新能力的器件级零初态探测在零初态、分立 VIN/VOUT 工况下给出 service_passed=false（启动 18.2096 s，晚于全部 4 帧，0 有效帧），故默认方案作为可自启动系统的交付结论不能写成通过。本轮更正了 notes/default-design.json 中两处连接错误（电感在 SW↔VOUT、整流为器件集成全波桥），并新增 notes/vendor-review.json 记录判断、依据、边界与下一项工程问题；未修改验收定义或场景，未启动新仿真。

## 当前执行的数值摘要

| 项目 | 数值 |
|---|---|
| 储能电容 | 68 µF |
| 负载电源轨 | 2.5 V |
| 负载总电荷 | 327.552 µC |
| 负载总能量 | 818.88 µJ |
| 平均负载功率 | 40.944 µW |
| 转换后可用平均功率 | 152.757 µW |
| 可用功率 / 平均负载 | 3.73087 倍 |
| 第 1 帧采样窗口最低储能电压 | 3.50317 V |
| 第 1 帧发送窗口最低储能电压 | 3.15309 V |
| 第 2 帧采样窗口最低储能电压 | 3.50317 V |
| 第 2 帧发送窗口最低储能电压 | 3.15309 V |
| 第 3 帧采样窗口最低储能电压 | 3.50317 V |
| 第 3 帧发送窗口最低储能电压 | 3.15309 V |
| 第 4 帧采样窗口最低储能电压 | 3.50317 V |
| 第 4 帧发送窗口最低储能电压 | 3.15309 V |
| 采样与发送窗口最小电压余量 | 0.95309 V |
| 储能核算绝对残差 | 0.0354094 µJ |
| 储能核算相对残差 | 0.0155123 % |

## task_and_model

任务与模型：压电梁 + 低功耗感知节点默认参考链，场景固定（30 Hz、4.905 m/s²、20 s、负载轨 2.5 V、初始储能 2.5 V、判定下限 2.2 V、>= 3 帧、采样 10 ms、发送 4 ms），可写文件仅 design.json、firmware/main.c、notes/。模型边界：平均功率耦合、固定 0.5 效率、事件表驱动固定状态电流、单抽象储能节点，无整流/电感/输入电容/UVLO 状态机。事实更正（本轮）：电感接在 SW 与 VOUT 之间（10 µH、Rser 0.4 Ω），不是 SW 与 VIN 之间；整流为器件集成全波桥、压电接 PZ1/PZ2，不再列为待核；D0→VIN2（高）、D1→GND（低）选 2.5 V 档。四个位置必须分开：VIN（输入储能，上升 4.04 V typ / 3.77~4.3 V；返回 2.87 V typ / 2.66~3.08 V，最坏 3.08 V）、VOUT（2.5 V 稳压轨，PGOOD 2.30 V = 0.92 x VOUT）、模型抽象储能节点（storage_f = 68 µF，2.5~3.6 V）、探测用 C_IN 150 µF / C_OUT 68 µF。

Sources: notes/default-design.json, notes/vendor-connection-facts.json, notes/vendor-probe.cir, design.json, firmware/main.c

## mechanics_and_source

机械与源（名义仿真结果，保留不变）：梁 50 x 10 x (0.2+0.2) mm、端部质量 2 g，谐振 31.0868 Hz（对 30 Hz 失谐 +3.6%，仍在共振带内）；端部位移峰值 1.3289 mm = 梁长 2.66% < 5% 线性上限；原生源功率 305.5137 µW、解析 304.2955 µW、相对误差 0.4003% < 1%，源门 PASS。器件级探测的源侧变化（changed_physics）：同一互易梁改由厂商桥/buck 加载，VIN/VOUT 分开、无固定效率级；探测中 VIN 峰值 4.0575 V（对应当前 10 µH + 150 µF 输入网络），只过 typ 启动阈值 4.04 V、未过最坏 4.3 V，故最坏器件的冷启动风险仍未量化。名义模型的 100 kOhm 阻性负载与真实非线性负载的差异已在探测中部分补上，但仍是厂商宏模型、非硅片。

Sources: source_model, notes/vendor-probe-protocol.json, notes/vendor-probe-result.json

## firmware_and_receiver

固件与接收（名义仿真结果）：确定性调度，4 帧在 2/6/10/14 s，先采样 10 ms @1 mA，于 +11 ms 发送 4 ms @8 mA，帧内间隔 1 ms，其余 idle 8 µA；value=2500、crc=(seq^value^0xA5)&255，名义仿真输出 96/99/98/101；接收 [1,2,3,4]、无帧错误，满足 20 s 内 >= 3 帧。器件级探测用的是同一编译事件表，但负载带低电压衰减 I=V(schedule)*limit(V(out)/1.8,0,1)：4 个采样与 4 个发送窗口全部落在 VOUT 上电之前（VOUT 首达 2.3 V 在 18.2096 s，最后事件 14.015 s 结束），8 个窗口全部 powered=false（VOUT 1e-6~4e-5 V），valid_sequences=[]、service_passed=false；序号/载荷/校验仍为 96/99/98/101，说明失败在能量与时序而不在数字契约。两者工况不同，不能互相替代。

Sources: firmware/main.c, receiver_service, notes/vendor-probe-result.json

## energy_and_service

能量与服务：名义工况（声明式预充 2.5 V，抽象单节点）负载总电荷 327.5520 µC = 采样 4 x 10 + 发送 4 x 32 + idle 159.552 µC（8 µA x 19.944 s）；在 2.5 V 负载轨上折算负载能量 818.88 µJ、平均 40.944 µW；可用 152.7568 µW 为负载的 3.7309 倍；储能核算残差 3.5409e-8 J / 0.0155%；抽象节点采样窗口最低 3.50317408 V、发送窗口最低 3.15309003 V，对 2.2 V 下限余量 0.95309 V（该余量只适用于该抽象域）。器件级零初态工况：C_IN=150 µF、C_OUT=68 µF 均 IC=0，求解成功（293282 点），VIN 峰值 4.0575 V、VOUT 峰值 2.5534 V、VOUT 首达 2.3 V 在 18.2096 s，启动后 20 s 窗口只剩 1.7904 s，全部窗口未供电。同一 2.2 V 判据、不同节点与初始条件 => 前者不能外推到后者；也未下调任何下限来改绿。

Sources: power_service, notes/vendor-probe-result.json, notes/vendor-review.json

## conclusion_and_files

结论与文件：本版（revision 20，决定 revision 21）保留审查，交付 18 个文件（新增 notes/vendor-review.json，更新 notes/default-design.json 至 pi-default-delivery-3）。①更正两处事实：电感在 SW↔VOUT（不是 VIN）、整流为器件集成全波桥（不是待核）；②区分工况：名义参考 = 声明式预充 2.5 V + 抽象单节点 + 固定 0.5 效率 + 固定状态电流，四门 PASS；器件探测 = 零初态 + 分立 VIN/VOUT + 集成桥/10 µH 电感 + 无固定效率级，service_passed=false（0 有效帧）；③交付结论：名义参考链结论不变，但器件级可自启动默认方案不可宣称交付，保留审查；④下一项工程问题：零初态下把帧调度改为 PGOOD/电压门控（启动后余 1.7904 s 足以容 3 帧，各约 15 ms）是否足以完成服务，还是必须依赖声明式预充；需新适配器支持电压驱动固件（execution_policy.feedback_iteration 未实现）；候选手段：门控/后移调度（firmware 在设计空间）、降低 C_IN 或提高耦合功率（梁参在设计空间）、或保留声明式预充。未做：未改 design.json / firmware/main.c（复用 TX-84f4ff52）、未改验收定义/场景/下限、未启动新仿真、未把宏模型结果写成实测。器件行为（宏模型准确性、效率曲线、静态电流、最坏 UVLO、MCU/传感器/射频器件级电流、硬件台架）仍未闭合，physical=NOT_TESTED。

Sources: notes/vendor-review.json, notes/default-design.json, notes/vendor-probe-result.json, notes/vendor-probe-protocol.json, delivery_version
